import type { ProfileVFS } from '../vfs/ProfileVFS';
type EmitFn = (event: string, args: unknown[]) => void;
type VFSGetter = () => ProfileVFS | null;
type ProxyUrlGetter = () => string | undefined;
export declare class HttpService {
    private readonly emit;
    private readonly vfsGetter;
    private readonly proxyUrlGetter;
    private readonly proxiedOrigins;
    constructor(emit: EmitFn, vfsGetter: VFSGetter, proxyUrlGetter?: ProxyUrlGetter);
    downloadFile(saveTo: string, url: string): void;
    getHTTP(url: string, headers?: Record<string, string>): void;
    postHTTP(data: string | null, url: string, headers?: Record<string, string>, file?: string): void;
    putHTTP(data: string | null, url: string, headers?: Record<string, string>, file?: string): void;
    deleteHTTP(url: string, headers?: Record<string, string>): void;
    customHTTP(method: string, data: string | null, url: string, headers?: Record<string, string>, file?: string): void;
    private runDownload;
    private readWithProgress;
    private bodyForUpload;
    private runRequest;
    private fetchWithFallback;
}
export {};
