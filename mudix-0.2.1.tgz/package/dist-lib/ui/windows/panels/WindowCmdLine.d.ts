import type { WindowManager } from '../WindowManager';
interface WindowCmdLineProps {
    id: string;
    manager: WindowManager;
    styleSheet?: string;
    /** Latest script-pushed value (clearCmdLine, printCmdLine, appendCmdLine).
     *  Applied to the input one-shot whenever `seedSeq` changes. */
    seedValue?: string;
    seedSeq?: number;
}
/**
 * Per-userwindow command line `<input>`. Backs Mudlet's enableCommandLine /
 * setCmdLineAction / setCmdLineStyleSheet on a userwindow. The component owns
 * the typed value as React state (so script-side seeds via printCmdLine /
 * clearCmdLine can drive it through the seedSeq bump) and registers a probe
 * with WindowManager so getCmdLine([name]) can read the live text.
 *
 * Enter dispatches to the bound Lua callback (setCmdLineAction). When no
 * callback is bound, Enter is a no-op — userwindow command lines don't
 * automatically send to the MUD the way the main command bar does.
 */
export declare function WindowCmdLine({ id, manager, styleSheet, seedValue, seedSeq }: WindowCmdLineProps): import("react/jsx-runtime").JSX.Element;
export {};
