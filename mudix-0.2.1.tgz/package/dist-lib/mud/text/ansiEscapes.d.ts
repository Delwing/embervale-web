/** CSI final bytes are 0x40–0x7E (`@`…`~`). */
export declare function isCsiFinal(c: string): boolean;
export interface EscapeScan {
    /**
     * - `csi`    — `ESC [ <params> <final>` (SGR, cursor moves, erase, …)
     * - `osc`    — `ESC ] <payload> ST` (OSC 8 hyperlinks, window title, …)
     * - `string` — DCS/SOS/PM/APC (`ESC P/X/^/_ … ST`); opaque, always ignored
     * - `esc`    — a short `ESC <intermediates> <final>` escape (charset, RIS, …)
     * - `incomplete` — the sequence runs off the end of `text`
     */
    kind: "csi" | "osc" | "string" | "esc" | "incomplete";
    /** Index one past the end of the sequence (exclusive). For `incomplete`,
     *  equals `text.length`. */
    end: number;
    /** CSI only: the final byte. */
    finalByte?: string;
    /** CSI only: the parameter + intermediate bytes between `ESC [` and the final. */
    params?: string;
    /** OSC only: the payload between `ESC ]` and the ST terminator. */
    oscPayload?: string;
}
/**
 * Scan a single escape sequence beginning at `text[start]` (which must be ESC).
 * Classifies the sequence and reports where it ends so callers can act on the
 * ones they understand and skip the rest. When the sequence is cut off by the
 * end of input the result is `incomplete` — callers either drop it or hold it
 * for the next line.
 */
export declare function scanEscape(text: string, start: number): EscapeScan;
export interface Osc8Link {
    /** The link target. An empty string means "close the current hyperlink". */
    uri: string;
    /** The optional `id=` parameter, used to group multi-run links. */
    id?: string;
}
/**
 * Parse an OSC payload (the bytes between `ESC ]` and the terminator) as an
 * OSC 8 hyperlink. Returns `null` when the payload is some other OSC command
 * (window title `0;…`, clipboard `52;…`, …) or is malformed — callers then
 * treat it the same as any other ignored escape.
 */
export declare function parseOsc8Payload(payload: string): Osc8Link | null;
/**
 * The action a clickable hyperlink performs, derived from its URI scheme. This
 * mirrors Mudlet's OSC 8 schemes — `send:`/`prompt:` drive the game, while the
 * web schemes open externally. The URI comes from an untrusted MUD server, so
 * any other scheme (`javascript:`, `data:`, `file:`, …) is rejected and the
 * link is dropped rather than made clickable.
 */
export type HyperlinkAction = {
    kind: "send";
    command: string;
} | {
    kind: "prompt";
    command: string;
} | {
    kind: "url";
    url: string;
};
/** URI schemes mudix is willing to make clickable from server output. */
export declare const ALLOWED_HYPERLINK_SCHEMES: readonly ["send", "prompt", "http", "https", "ftp"];
export declare function classifyHyperlinkUri(uri: string): HyperlinkAction | null;
export type OscPaletteOp = {
    kind: "set";
    index: number;
    color: string;
} | {
    kind: "reset";
    index: number;
} | {
    kind: "reset-all";
};
/**
 * Parse an XParseColor spec into a `#rrggbb` string, or null if unrecognised.
 * Handles the two forms MUDs use in practice — `rgb:r/g/b` and `#`-hex — and
 * rejects named colours and other X forms (`rgbi:`, `cmyk:`, …).
 */
export declare function parseXColorSpec(spec: string): string | null;
/**
 * Parse an OSC payload as an OSC 4 (set) or OSC 104 (reset) palette command.
 * Returns the ordered list of operations, or null if the payload is neither.
 * Malformed index/spec pairs are skipped rather than aborting the whole list.
 */
export declare function parseOscColorPalette(payload: string): OscPaletteOp[] | null;
