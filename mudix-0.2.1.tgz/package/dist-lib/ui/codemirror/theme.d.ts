import { Compartment } from '@codemirror/state';
import { syntaxHighlighting } from '@codemirror/language';
export declare const mudixCmTheme: import("@codemirror/state").Extension;
export declare const highlightCompartment: Compartment;
export declare function highlightFor(theme: string): ReturnType<typeof syntaxHighlighting>;
