import type { ProfileVFS } from './ProfileVFS';
export declare function vfsUrlPrefix(): string;
/** Register a mounted profile so the service worker can read its files. */
export declare function registerVfs(connectionId: string, vfs: ProfileVFS): void;
/** Drop the mapping and clear cached responses for this connection. */
export declare function unregisterVfs(connectionId: string): void;
/** Tell the SW to drop one cached file (call after writes). */
export declare function invalidateVfsPath(connectionId: string, path: string): void;
/** Build a URL the SW will resolve to bytes from `vfs.readBinaryFile(path)`. */
export declare function vfsUrlFor(connectionId: string, path: string): string;
/**
 * Register the service worker and wait until it controls this page. Safe to
 * call multiple times; resolves to false if the browser doesn't support SWs
 * or registration failed.
 */
export declare function registerVfsServiceWorker(): Promise<boolean>;
