import type { PluginOption } from 'vite';
export default function mudix(): PluginOption[];
