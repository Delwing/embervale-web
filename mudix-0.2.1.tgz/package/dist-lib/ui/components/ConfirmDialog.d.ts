import { type ReactNode } from 'react';
export interface ConfirmButton<T = unknown> {
    label: string;
    value: T;
    variant?: 'primary' | 'secondary' | 'danger' | 'ghost';
    autoFocus?: boolean;
}
export interface ConfirmOptions<T = unknown> {
    title?: string;
    message?: ReactNode;
    /** Buttons rendered in order, left to right. Last button is treated as the default if none specifies `autoFocus`. */
    buttons?: ConfirmButton<T>[];
    /** Returned when the user dismisses via ESC or backdrop click. */
    dismissValue?: T;
    /** Disable backdrop-click and ESC dismissal. */
    blocking?: boolean;
    /** Visual hint that the action is destructive — adds an icon and styling. */
    tone?: 'default' | 'danger';
}
interface DialogProps<T> extends ConfirmOptions<T> {
    onResolve: (value: T | undefined) => void;
}
export declare function ConfirmDialog<T>({ title, message, buttons, dismissValue, blocking, tone, onResolve, }: DialogProps<T>): import("react/jsx-runtime").JSX.Element;
type ConfirmFn = <T = boolean>(options: ConfirmOptions<T>) => Promise<T | undefined>;
export declare function ConfirmProvider({ children }: {
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function useConfirm(): ConfirmFn;
export {};
