import { EventBus } from "../../core/EventBus";
import { AnsiAwareBuffer } from "../text/FormatState";
import { type ChunkProcessor } from "../triggers/ChunkProcessor";
import type { MudClientEvents } from "../events";
export type { MudClientEvents } from "../events";
export { SUPPORTED_SERVER_ENCODINGS } from "../protocol";
export interface MudClientOptions {
    url: string;
    mccpEnabled?: boolean;
    commandEcho?: boolean;
    chunkProcessor?: ChunkProcessor;
    /** Milliseconds to hold a partial trailing line (text after the last `\n`)
     *  before flushing it as a prompt. Mirrors Mudlet's "Network packet timeout"
     *  preference; defaults to 300ms. Once a server has sent IAC GA or IAC EOR
     *  at least once, the client latches into "GA-driver" mode and the partial
     *  tail is flushed by the prompt marker instead of this timer — so the value
     *  only matters as an idle safety net (e.g. a line split across frames whose
     *  remainder never arrives). */
    promptTimeoutMs?: number;
    /** Whether to accept GMCP (telnet option 201) negotiation. Default true.
     *  When false, the client silently ignores IAC WILL/DO GMCP so the server
     *  never sees a positive ack and no GMCP envelopes flow. */
    gmcpEnabled?: boolean;
    /** Whether to accept TERMINAL-TYPE / MTTS (telnet option 24) negotiation.
     *  Default true. When false, IAC DO TTYPE is ignored so the server falls
     *  back to its non-MTTS code path. */
    mttsEnabled?: boolean;
    /** Whether to accept MSDP (telnet option 69) negotiation. Default false.
     *  When false, IAC WILL/DO MSDP is ignored and no MSDP envelopes flow. */
    msdpEnabled?: boolean;
    /** Whether to accept MSSP (telnet option 70) negotiation. Default true
     *  (matching Mudlet). When false, IAC WILL/DO MSSP is ignored and the
     *  server's status subnegotiation never arrives. */
    msspEnabled?: boolean;
    /** Whether to accept CHARSET (telnet option 42, RFC 2066) negotiation.
     *  Default true. When false, IAC WILL/DO CHARSET is ignored and the
     *  session stays on the UTF-8 baseline (so non-ASCII bytes from non-UTF-8
     *  MUDs render as replacement chars). */
    charsetEnabled?: boolean;
    /** Whether to enable MSP (MUD Sound Protocol, telnet option 90). Default
     *  false. When true the client negotiates the option and strips inline
     *  `!!SOUND(...)` / `!!MUSIC(...)` tags from MUD text, dispatching them
     *  as `msp` events. Always parses subnegotiations regardless of this flag
     *  once negotiated, but in-band parsing is gated to avoid eating literal
     *  text on MUDs that don't speak MSP. */
    mspEnabled?: boolean;
    /** Whether to accept MXP (telnet option 91) negotiation. Default true.
     *  When false, IAC WILL/DO MXP is ignored so the server never sees a
     *  positive ack and no in-band MXP markup is parsed (tags pass through as
     *  literal text). The actual tag parsing lives downstream in the scripting
     *  engine, gated on the `mxp.negotiated` event this client emits. */
    mxpEnabled?: boolean;
    /** Whether to answer telnet option 39 in MNES mode (Mud New-Environ
     *  Standard). Default false. When on, the client reports the five MNES core
     *  variables (CHARSET / CLIENT_NAME / CLIENT_VERSION / MTTS / TERMINAL_TYPE),
     *  framed as NEW_ENVIRON_VAR. MNES takes precedence over plain NEW-ENVIRON
     *  when both are enabled — matching Mudlet, which restricts the reported set
     *  to these five whenever MNES is active. */
    mnesEnabled?: boolean;
    /** Whether to answer telnet option 39 in plain NEW-ENVIRON mode (RFC 1572,
     *  "Client Variables Standard"). Default false. When on (and MNES off), the
     *  client reports the five core variables plus an extended capability set
     *  (ANSI, 256_COLORS, TRUECOLOR, UTF-8, TLS, WORD_WRAP, …), framed as
     *  NEW_ENVIRON_USERVAR. Mudlet exposes MNES and NEW-ENVIRON as two separate
     *  toggles over the same telnet option; mudix mirrors that. */
    newEnvironEnabled?: boolean;
    /** Whether the link to the *game server* is TLS-encrypted, reported as the
     *  NEW-ENVIRON `TLS` capability. Defaults to whether `url` is `wss://` — the
     *  correct answer for a direct websocket-mode connection. In proxy (`mud`)
     *  mode the caller passes `false` explicitly, because a `wss://` proxy URL
     *  only secures the browser↔proxy hop while the proxy↔MUD telnet socket is
     *  plaintext (see connectionSecureTransport). */
    secureTransport?: boolean;
    /** Whether to negotiate NAWS / window size (telnet option 31). Default true
     *  (matching Mudlet). When true the client offers IAC WILL NAWS on connect
     *  and, once the server accepts (IAC DO NAWS), reports the main output
     *  area's character grid (columns × rows) and re-sends it on every resize.
     *  When false the client never offers NAWS and ignores IAC DO NAWS. */
    nawsEnabled?: boolean;
    /** Mudlet's "Fix unnecessary linebreaks on GA servers"
     *  (`setConfig("fixUnnecessaryLinebreaks", …)`, host flag
     *  `mUSE_IRE_DRIVER_BUGFIX`). Default false. When true *and* the session is
     *  GA-driven, a single spurious leading newline is stripped from the start
     *  of each GA-terminated data block — the IRE-server bug Mudlet patches in
     *  `cTelnet::gotPrompt`. See LineAssembler. */
    fixUnnecessaryLinebreaks?: boolean;
    /** WebSocket subprotocols to advertise in the opening handshake's
     *  `Sec-WebSocket-Protocol` header (RFC 6455), in preference order — the
     *  server selects at most one. Mutually-exclusive stream *modes*, not layers:
     *  `binary` (raw telnet over binary frames — the mode mudix decodes),
     *  `telnet` (FluffOS's equivalent name), `telnet.mudstandards.org` (the
     *  mudstandards.org proposal). Empty means open a bare socket. Advertising is
     *  a trade-off: some servers (FluffOS) route a *no-subprotocol* upgrade to a
     *  non-MUD handler and never send data, while others (e.g. last-outpost.com)
     *  *reject* an unrecognized subprotocol with HTTP 400 — hence the per-profile
     *  choice. The server's selection is read back from `socket.protocol` on open
     *  and emitted via `client.subprotocol`. */
    subprotocols?: string[];
}
/** The WebSocket subprotocol name for the mudstandards.org "full telnet stream
 *  over binary frames" profile (https://mudstandards.org/websocket/). mudix
 *  already speaks this wire format; advertising the name lets a conforming
 *  server confirm the dialect via the RFC 6455 handshake. */
export declare const MUD_TELNET_SUBPROTOCOL = "telnet.mudstandards.org";
/**
 * The MUD-facing transport: telnet over a WebSocket (direct or via the
 * telnet→WebSocket proxy). Owns the socket lifecycle and the outbound send
 * paths; the protocol concerns are composed from dedicated pieces —
 * {@link TelnetNegotiator} (option negotiation + sysTelnetEvent),
 * {@link SessionCodec}/{@link CharsetHandler} (byte↔char encoding + CHARSET),
 * {@link LineAssembler} (partial-line buffering + prompt flushing),
 * `MccpHandler` (compression), `EchoHandler` (password masking), and the
 * GMCP/MSDP/MSSP subnegotiation streams.
 */
export declare class MudClient {
    private socket;
    private readonly eventBus;
    private readonly chunkProcessor;
    private messageBuffer;
    private readonly gmcpStream;
    private readonly msdpStream;
    private readonly msspStream;
    private readonly telnetOptionHandler;
    private readonly mccpHandler;
    private readonly echoHandler;
    private readonly negotiator;
    /** Byte↔char codec for the session (inbound streaming decoder + outgoing
     *  encoding). Swapped between encodings by the CHARSET handler. */
    private readonly codec;
    private readonly charsetHandler;
    /** Whole-line assembly of the decoded text stream (partial-tail buffering,
     *  GA-driven prompt flushing, the idle-flush safety net). */
    private readonly assembler;
    private readonly url;
    /** Buffers the start of a subnegotiation that arrived without its closing IAC SE. */
    private pendingSubneg;
    /** True once the WebSocket handshake has completed; used to differentiate
     *  "failed to connect" from "connection lost mid-session" in close events. */
    private opened;
    /** True once we've sent the GMCP `Core.Hello` / `Core.Supports.Set`
     *  handshake this session, so a server that re-offers GMCP doesn't make us
     *  announce ourselves twice. Reset on each connect(). */
    private gmcpHelloSent;
    commandEcho: boolean;
    /** Gates the in-band `!!SOUND(...)` / `!!MUSIC(...)` tag parsing — the tag
     *  bytes are legitimate text on non-MSP MUDs. */
    private readonly mspEnabled;
    private readonly mspParser;
    /** WebSocket subprotocols advertised on connect (see MudClientOptions). */
    private readonly subprotocols;
    constructor({ url, mccpEnabled, commandEcho, chunkProcessor, promptTimeoutMs, gmcpEnabled, mttsEnabled, msdpEnabled, msspEnabled, charsetEnabled, mspEnabled, mxpEnabled, mnesEnabled, newEnvironEnabled, secureTransport, nawsEnabled, fixUnnecessaryLinebreaks, subprotocols, }: MudClientOptions, eventBus: EventBus<MudClientEvents>);
    setMccpEnabled(enabled: boolean): void;
    isMccpEnabled(): boolean;
    /** Mudlet `setConfig("fixUnnecessaryLinebreaks", …)`. Takes effect on the
     *  next GA-driven block; never retroactive. */
    setFixUnnecessaryLinebreaks(enabled: boolean): void;
    /** Mudlet `addSupportedTelnetOption(option)`. See TelnetNegotiator. */
    addSupportedTelnetOption(option: number): boolean;
    setPromptTimeoutMs(ms: number): void;
    getPromptTimeoutMs(): number;
    connect(): void;
    disconnect(): void;
    isSocketOpen(): boolean;
    isPasswordMode(): boolean;
    shouldEchoCommand(): boolean;
    send(message: string): void;
    private sendRaw;
    /** Encodes a Latin-1 byte-string to raw bytes and sends it as a binary
     *  WebSocket frame. The proxy worker expects binary, not base64. */
    private sendBytes;
    sendGmcp(path: string, payload?: unknown): void;
    /** Announce ourselves to the server right after GMCP is negotiated, the way
     *  Mudlet does: `Core.Hello` identifies the client (name + version) and
     *  `Core.Supports.Set` lists the GMCP modules we understand. Many servers
     *  won't push any GMCP data (room, char, vitals, …) until they've received
     *  this hello, so without it GMCP effectively does nothing. Latched so a
     *  repeated WILL/DO GMCP doesn't re-announce. Reports the client name as
     *  "MUDIX" — our own identity — matching the TTYPE/MNES handshake. */
    private sendGmcpHandshake;
    /** Route GMCP `Char.Login.*` messages. The server sends `Char.Login.Default
     *  { "type": [...] }` to request login and then *waits* for the client to
     *  supply credentials — withholding the normal text "By what name…" prompt
     *  until it hears back (servers that do this gate on the `Char.Login` module
     *  we advertise in `Core.Supports.Set`). We surface it as `charLogin.request`
     *  so the UI can pop a credentials form; the UI replies via
     *  `sendCharLoginCredentials`, or an empty reply (cancel) to fall back to the
     *  text login (the behaviour Mudlet/Mudlet#7377 is about). `Char.Login.Result`
     *  carries the outcome. Path match is case-insensitive — GMCP module casing
     *  varies between servers. */
    private handleCharLogin;
    /** Send the GMCP `Char.Login.Credentials` reply. With an account, sends
     *  `{ account, password }` (account may be `"account:character"` for games
     *  with both); with no account it sends the empty `{}` form — the spec's
     *  "no credentials, fall back to your next auth method" signal, used when the
     *  user cancels the popup. mudix never stores the password; it only relays it. */
    sendCharLoginCredentials(account?: string, password?: string): void;
    sendGmcpRaw(message: string): void;
    /** Mudlet `sendMSDP(variable, ...values)`. Frames + sends an MSDP
     *  subnegotiation. Returns false when the socket isn't open. */
    sendMSDP(variable: string, values: string[]): boolean;
    /** Mudlet `sendATCP(message)`. Frames `IAC SB ATCP <message> IAC SE` (ATCP =
     *  telnet option 200, GMCP's predecessor) and sends it raw. Returns false
     *  when the socket isn't open. */
    sendATCP(message: string): boolean;
    /** Mudlet `sendTelnetChannel102(msg)`. Frames `IAC SB 102 <msg> IAC SE`
     *  (the zMUD generic out-of-band channel) and sends it raw. Returns false
     *  when the socket isn't open. */
    sendTelnetChannel102(msg: string): boolean;
    /** Frame a raw `IAC SB <opt> <payload> IAC SE` subnegotiation and send it
     *  with no encoding conversion (each char → one byte), like the other
     *  telnet negotiations. Shared by sendATCP / sendTelnetChannel102. */
    private sendSubnegotiation;
    /** Mudlet `getServerEncoding()`. The IANA name of the decoder currently
     *  applied to the inbound stream — 'utf-8' until CHARSET negotiation (or an
     *  explicit setServerEncoding) swaps it. */
    getServerEncoding(): string;
    /** Mudlet `setServerEncoding(name)`. Switch the inbound decoder to `name`
     *  (any value from getServerEncodingsList()). Returns false — leaving the
     *  current encoding untouched — when the name isn't one we can decode. */
    setServerEncoding(name: string): boolean;
    /** Route an `IAC SB MSP ... IAC SE` body to the MSP parser and dispatch
     *  any parsed commands as `msp` events. Always runs when an MSP subneg
     *  arrives — once the server has bothered to wrap a tag, we trust it. */
    private handleMspSubneg;
    /** Report the main output window's character grid (columns × rows) for NAWS.
     *  The session calls this on every output-area resize. See TelnetNegotiator. */
    setWindowSize(cols: number, rows: number): void;
    /** Mudlet `sendSocket(data)`. Sends literal bytes over the socket with no
     *  telnet/encoding processing (each char becomes one byte). Returns false
     *  when the socket isn't open. */
    sendSocket(data: string): boolean;
    /** Mudlet `feedTelnet(data)`. Injects raw bytes into the inbound pipeline
     *  as if they had arrived from the server — they pass through telnet
     *  stripping, ANSI parsing, the trigger pipeline, and rendering. `data` is
     *  treated as a Latin-1 byte-string (matching incoming-frame handling). */
    feedTelnet(data: string): void;
    output(text?: string | AnsiAwareBuffer, type?: string, timestamp?: number): void;
    /** Push a line directly into the message buffer for trigger processing + rendering via flushLines. */
    pushLine(text: string, type: string): void;
    private processIncomingData;
    flushMessageBuffer(): void;
}
