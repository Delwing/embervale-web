import type { AliasNode } from '../../storage/schema';
import { PatternEngine } from '../PatternEngine';
export type { AliasNode };
export declare class AliasEngine extends PatternEngine<AliasNode> {
    /** Returns true and fires the first matching temp alias. Stops at first match. */
    processTemp(input: string): boolean;
    /** Returns the first matching perm alias, or null. `matchedText` is the
     *  portion of `input` the regex actually matched (Mudlet's `matches[1]`),
     *  which differs from the whole input for an unanchored pattern. */
    matchPerm(input: string): {
        alias: AliasNode;
        matchedText: string;
        captures: string[];
    } | null;
}
