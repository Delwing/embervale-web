import { type BufferWordIndex } from './bufferWords';
import type { CmdLineMenuRegistry } from './CmdLineMenuRegistry';
interface CommandBarProps {
    command: string;
    onCommandChange: (command: string) => void;
    passwordMode?: boolean;
    commandInputRef: React.RefObject<HTMLInputElement | HTMLTextAreaElement | null>;
    onSubmit: () => void;
    cmdLineMenu: CmdLineMenuRegistry;
    /** Tab-completion suggestions added via Mudlet's addCmdLineSuggestion API.
     *  Merged ahead of command history (dedup, case-insensitive). */
    suggestions?: string[];
    /** Recency-ordered words seen in output, for argument-word Tab completion. */
    bufferWords?: BufferWordIndex | null;
}
export declare function CommandBar({ command, onCommandChange, passwordMode, commandInputRef, onSubmit, cmdLineMenu, suggestions, bufferWords }: CommandBarProps): import("react/jsx-runtime").JSX.Element;
export {};
