import type { ModalBounds } from '../storage/schema';
interface ResizableModalProps {
    title: string;
    onClose: () => void;
    savedBounds?: ModalBounds | null;
    onBoundsChange?: (bounds: ModalBounds) => void;
    minW?: number;
    minH?: number;
    defaultW: number;
    defaultH: number;
    headerExtra?: React.ReactNode;
    className?: string;
    bodyClassName?: string;
    children: React.ReactNode;
}
export declare function ResizableModal({ title, onClose, savedBounds, onBoundsChange, minW, minH, defaultW, defaultH, headerExtra, className, bodyClassName, children, }: ResizableModalProps): import("react/jsx-runtime").JSX.Element;
export {};
