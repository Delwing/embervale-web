type Params<T> = [T] extends [void] ? [] : [T] extends [any[]] ? T : [T];
type Handler<T> = (...args: Params<T>) => void;
type EventOptions = {
    once?: boolean;
    signal?: AbortSignal;
};
export declare class EventBus<Events extends Record<PropertyKey, any>> {
    private listeners;
    on<K extends keyof Events>(event: K, listener: Handler<Events[K]>, options?: EventOptions | boolean): () => void;
    off<K extends keyof Events>(event: K, listener: Handler<Events[K]>): void;
    emit<K extends keyof Events>(event: K, ...args: Params<Events[K]>): number;
    clear(event?: keyof Events): void;
    listenerCount(event: keyof Events): number;
}
export {};
