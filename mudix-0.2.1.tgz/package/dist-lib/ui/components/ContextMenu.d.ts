import './ContextMenu.css';
interface ContextMenuProps {
    x: number;
    y: number;
    onClose: () => void;
    children: React.ReactNode;
}
export declare function ContextMenu({ x, y, onClose, children }: ContextMenuProps): import("react").ReactPortal;
export {};
