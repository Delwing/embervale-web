import type { ProfileSettings } from '../storage/schema';
import { type MudletImportResult } from './mudletXmlImport';
import { type MudletVariablePackage } from './mudletVariables';
/**
 * Map a `<Host>` element to a partial ProfileSettings. Only keys actually
 * present in the XML are set, so the result can be merged over existing/default
 * settings without clobbering anything Mudlet didn't specify.
 */
export declare function parseMudletHost(host: Element): Partial<ProfileSettings>;
/** The connection identity a Mudlet `<Host>` carries: the profile name and the
 *  MUD address (`<url>` host + `<port>`). Used to seed a new mudix connection. */
export interface MudletProfileIdentity {
    name?: string;
    host?: string;
    port?: number;
}
/** Read `<name>`/`<url>`/`<port>` (direct children of `<Host>`). */
export declare function parseMudletHostIdentity(host: Element): MudletProfileIdentity;
/**
 * Write the modeled ProfileSettings back onto an existing `<Host>` element,
 * in place — only the fields present in `s` are touched, so unmodeled Host
 * fields (and the whole rest of the profile) are preserved. The inverse of
 * {@link parseMudletHost}. The display-font family is only written for a *system*
 * font (Mudlet can't resolve a url/vfs font name); the size is always synced, and
 * the rest of the QFont spec is preserved.
 */
export declare function applyProfileSettingsToHost(host: Element, s: Partial<ProfileSettings>): void;
/** Names from `<Host><mInstalledPackages>` — the packages Mudlet considers
 *  installed for this profile. Mudlet tracks these so package managers (mpkg) and
 *  `getPackageInfo`/`getInstalledPackages` work; mudix registers a manifest per
 *  entry on import. */
export declare function parseInstalledPackages(host: Element): string[];
/** Everything a full Mudlet profile XML carries that mudix can import. */
export interface MudletProfileImport {
    /** From `<Host>` — the profile name + MUD address for the connection record. */
    connection: MudletProfileIdentity;
    /** From `<HostPackage><Host>` — partial so it merges over defaults. */
    settings: Partial<ProfileSettings>;
    /** From the Trigger/Alias/Script/Timer/Key/Action packages. */
    automation: MudletImportResult;
    /** From `<VariablePackage>` — the saved-variables tree + hidden list. */
    variables: MudletVariablePackage;
    /** Names from `<mInstalledPackages>` — registered as package manifests on import. */
    installedPackages: string[];
    /** From `<mInstalledModules>` — modules reference an XML file at an absolute
     *  local path *outside* the profile, which a browser can't read. The import
     *  flow surfaces these for the user to upload or drop. */
    modules: MudletModuleRef[];
}
/** One `<mInstalledModules>` entry: a module the profile loads from an external
 *  XML file on the user's disk. */
export interface MudletModuleRef {
    key: string;
    filepath: string;
    /** Mudlet `globalSave` flag — sync the module back on save. */
    globalSave: boolean;
    priority: number;
}
/** Parse the repeated `<mInstalledModules>` blocks under `<Host>`. */
export declare function parseInstalledModules(host: Element): MudletModuleRef[];
/**
 * Parse a complete Mudlet profile XML (a `current/*.xml`) into the things mudix
 * can apply: the connection identity, profile settings, automation trees, and
 * saved variables. `<VariablePackage>` variable names become the seed of the
 * profile's save-list when applied. Throws on malformed XML.
 */
export declare function parseMudletProfile(xml: string): MudletProfileImport;
