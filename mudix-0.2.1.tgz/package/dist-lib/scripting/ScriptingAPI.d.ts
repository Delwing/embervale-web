import type { MudSession, ScriptLogSource } from '../mud/MudSession';
import type { AliasEngine } from '../mud/aliases/AliasEngine';
import type { TriggerEngine } from '../mud/triggers/TriggerEngine';
import type { TimerEngine } from '../mud/timers/TimerEngine';
import type { KeyEngine } from '../mud/keybindings/KeyEngine';
import type { WindowHandle, WindowOpenOptions } from '../ui/windows/types';
import type { LabelManager, LabelCreateOptions, LabelMouseEvent, LabelWheelEvent } from '../ui/labels/LabelManager';
import type { CommandLineManager } from '../ui/cmdline/CommandLineManager';
import type { ScrollBoxManager } from '../ui/scrollbox/ScrollBoxManager';
import { TextEditManager } from '../ui/textedit/TextEditManager';
import { AnsiAwareBuffer, type FormatStateSnapshot, type FormatHyperlink } from '../mud/text/FormatState';
import { StopwatchManager } from './StopwatchManager';
declare class ScriptingWindowsAPI {
    private readonly session;
    constructor(session: MudSession);
    open(id: string, options?: WindowOpenOptions): WindowHandle;
    write(id: string, text: string): void;
    clear(id: string): void;
    setTitle(id: string, title?: string): boolean;
    focus(id: string): void;
    hide(id: string): void;
    show(id: string): boolean;
    close(id: string): void;
    has(id: string): boolean;
    isVisible(id: string): boolean;
    isMiniConsole(id: string): boolean;
    move(id: string, x: number, y: number): void;
    bringToFront(id: string): void;
    sendToBack(id: string): void;
    resize(id: string, width: number, height: number): void;
    setFontSize(id: string, size: number): boolean;
    getFontSize(id: string): number | null;
    setFont(id: string, family: string): boolean;
    getFont(id: string): string | null;
    setBackgroundColor(id: string, r: number, g: number, b: number, a?: number): boolean;
    getBackgroundColor(id: string): {
        r: number;
        g: number;
        b: number;
        a: number;
    } | null;
    element(id: string): HTMLElement | null;
    enableCommandLine(id: string): boolean;
    disableCommandLine(id: string): boolean;
    setCmdLineStyleSheet(id: string, css: string): boolean;
    setCmdLineAction(id: string, cb: ((text: string) => void) | null): boolean;
    clearCmdLine(id: string): boolean;
    printCmdLine(id: string, text: string): boolean;
    appendCmdLine(id: string, text: string): boolean;
    getCmdLineValue(id: string): string;
}
declare class ScriptingLabelsAPI {
    private readonly manager;
    private readonly cssRewriter;
    constructor(manager: LabelManager, cssRewriter: () => ((css: string) => string) | null);
    create(name: string, opts: LabelCreateOptions): boolean;
    has(name: string): boolean;
    destroy(name: string): boolean;
    move(name: string, x: number, y: number): boolean;
    resize(name: string, width: number, height: number): boolean;
    show(name: string): boolean;
    hide(name: string): boolean;
    setHtml(name: string, html: string): boolean;
    setBackgroundColor(name: string, r: number, g: number, b: number, a?: number): boolean;
    getBackgroundColor(name: string): {
        r: number;
        g: number;
        b: number;
        a: number;
    } | null;
    setStyleSheet(name: string, css: string): boolean;
    getStyleSheet(name: string): string | undefined;
    setLinkStyle(name: string, color: string, visitedColor: string, underline: boolean): boolean;
    resetLinkStyle(name: string): boolean;
    getSizeHint(name: string): {
        width: number;
        height: number;
    } | null;
    setClickCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseUpCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setDoubleClickCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseMoveCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseEnterCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseLeaveCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setWheelCallback(name: string, fn: ((e: LabelWheelEvent) => void) | undefined): boolean;
    setTooltip(name: string, text: string | undefined): boolean;
    setClickThrough(name: string, value: boolean): boolean;
    setCursor(name: string, cursor: string | undefined): boolean;
    raise(name: string): boolean;
    lower(name: string): boolean;
}
export interface InstallOutcome {
    ok: boolean;
    error: string | null;
}
export declare class ScriptingAPI {
    private readonly session;
    private readonly connectionId;
    /** OSC 8 selection-group + visited-link state for this connection. */
    private readonly oscLinks;
    readonly windows: ScriptingWindowsAPI;
    readonly labels: ScriptingLabelsAPI;
    readonly cmdLines: CommandLineManager;
    readonly scrollBoxes: ScrollBoxManager;
    readonly textEdits: TextEditManager;
    readonly aliases: AliasEngine;
    readonly triggers: TriggerEngine;
    profileName: string;
    /** When true, errors routed through {@link printError} are also echoed into
     *  the main output window (Mudlet's "Show errors in main console"). Wired
     *  from ProfileSettings.showErrorsInMainWindow in ProfileSession. */
    showErrorsInMainWindow: boolean;
    readonly timers: TimerEngine;
    readonly keys: KeyEngine;
    /** Mudlet-compatible stopwatch registry (createStopWatch & friends).
     *  Persistent watches survive reloads via localStorage keyed by connection. */
    readonly stopwatches: StopwatchManager;
    /** Cross-tab view of open/connected profiles — backs getProfiles(). */
    private readonly presence;
    /** Teardown for the session subscriptions wired in the constructor. */
    private readonly apiUnsubs;
    private readonly mainConsole;
    private inTriggerProcessing;
    private echoDeferred;
    private isDeferringEcho;
    private echoOnMatchedLine;
    private executeScript;
    private expandAliasCallback;
    private sendRequestDispatcher;
    private connectDispatcher;
    private feedDispatcher;
    private packageInstaller;
    private packageUninstaller;
    private packagesGetter;
    private moduleInstaller;
    private moduleUninstaller;
    private moduleSyncer;
    private moduleReloader;
    private moduleSyncSetter;
    private moduleSyncGetter;
    private modulePrioritySetter;
    private modulePriorityGetter;
    private modulesGetter;
    private moduleInfoGetter;
    private moduleInfoSetter;
    private modulePathGetter;
    private packageInfoGetter;
    private packageInfoSetter;
    private cssRewriter;
    private scriptToggler;
    private triggerToggler;
    private triggerStayOpenSetter;
    private timerToggler;
    private aliasToggler;
    private keyToggler;
    private existsCallback;
    private isActiveCallback;
    private ancestorsCallback;
    private findItemsCallback;
    private isAncestorsActiveCallback;
    private profileStatsCallback;
    private permScriptCallback;
    private permRegexTriggerCallback;
    private permSubstringTriggerCallback;
    private permBeginOfLineStringTriggerCallback;
    private permExactMatchTriggerCallback;
    private permPromptTriggerCallback;
    private permAliasCallback;
    private permTimerCallback;
    private permKeyCallback;
    private tempButtonCallback;
    private tempButtonToolbarCallback;
    private buttonStateSetter;
    private buttonStateGetter;
    private buttonStyleSheetSetter;
    private toolBarToggler;
    /** Mudlet `startLogging(state)`. Forwarded to ProfileSession, which owns
     *  the SessionLogger instance (created/torn-down on this hook). */
    private loggingToggler;
    /** Mudlet `appendLog(text)`. Forwarded to the active SessionLogger (wired by
     *  ProfileSession, which owns the logger lifecycle). */
    private logAppender;
    /** Mudlet `closeMudlet()`. mudix maps it to "close the active profile":
     *  disconnect, then return to the connection screen. Wired by ProfileSession. */
    private closeProfileCallback;
    /** Mudlet `resetProfile()` — reload the whole profile (fresh Lua VM, UI
     *  cleared, scripts re-run). Wired by ScriptingEngine; deferred internally. */
    private resetProfileCallback;
    /** Mudlet `exportAreaImage(areaID, filePath[, zLevel])` — render an area to a
     *  PNG in the profile VFS. Wired by ScriptingEngine (which owns the VFS). */
    private exportAreaImageCallback;
    private setScriptCallback;
    private scriptGetter;
    private killByNameCallback;
    private selection;
    private clipboard;
    private clipboardText;
    private buffers;
    constructor(session: MudSession, aliasEngine: AliasEngine, triggerEngine: TriggerEngine, timerEngine: TimerEngine, keyEngine: KeyEngine, connectionId: string);
    connect(url: string): void;
    /** Dial through the engine's load gate when wired (deferring a connect made
     *  during initial load), else connect the session directly. */
    private dialConnect;
    disconnect(): void;
    send(text: string, echo?: boolean): void;
    sendGmcp(message: string): void;
    /** Mudlet `sendMSDP(variable, ...values)`. Frames an MSDP subnegotiation
     *  (`IAC SB MSDP MSDP_VAR <var> [MSDP_VAL <val>]... IAC SE`) and sends it. */
    sendMSDP(variable: string, values: string[]): boolean;
    /** Mudlet `sendSocket(data)`. Sends a literal byte-string over the socket
     *  with no telnet/encoding processing (each char is one byte). */
    sendSocket(data: string): boolean;
    /** Mudlet `feedTelnet(data)`. Injects raw server bytes into the inbound
     *  pipeline as if received from the MUD (telnet stripping → ANSI →
     *  triggers → render). */
    feedTelnet(data: string): void;
    /** Mudlet `receiveMSP(text)`. Parses an MSP payload (`!!SOUND(...)` /
     *  `!!MUSIC(...)` tags) as if the server had sent it and dispatches the
     *  resulting sound/music commands through the normal `msp` event path
     *  (SoundManager). Returns true when at least one command was parsed. */
    receiveMSP(payload: string): boolean;
    /** Mudlet `sendATCP(message)`. Frames + sends an ATCP (telnet 200)
     *  subnegotiation; false when the socket isn't open. */
    sendATCP(message: string): boolean;
    /** Mudlet `sendTelnetChannel102(msg)`. Frames + sends a zMUD channel-102
     *  (telnet 102) subnegotiation; false when the socket isn't open. */
    sendTelnetChannel102(msg: string): boolean;
    /** Mudlet `reconnect()`. Disconnect and redial the last-connected URL;
     *  false when no connection has been made this session. */
    reconnect(): boolean;
    /** Mudlet `getServerEncoding()`. IANA name of the decoder applied to the
     *  inbound stream (default "utf-8"). */
    getServerEncoding(): string;
    /** Mudlet `setServerEncoding(name)`. Switch the server stream decoder to
     *  `name` (one of getServerEncodingsList()); false when unsupported or no
     *  connection is active. */
    setServerEncoding(name: string): boolean;
    /** Mudlet `getServerEncodingsList()`. The encodings mudix can decode. */
    getServerEncodingsList(): string[];
    /** Mudlet `getCharacterName()`. mudix uses one character per profile, so
     *  this returns the active profile name (same value as getProfileName());
     *  empty string when unset. */
    getCharacterName(): string;
    /**
     * Mudlet `getProfiles()`. A record keyed by profile name, one entry per
     * configured connection, each `{ host, port, loaded, connected, description }`:
     *  - `host`/`port` — the MUD's address (mud-mode: stored host/port; ws-mode:
     *    parsed from the endpoint URL), available for every profile.
     *  - `loaded` — the profile is open (in some tab) and editable. Cross-tab via
     *    the Web Lock each open profile holds.
     *  - `connected` — the profile is connected to its game. Own tab: live; other
     *    tabs: their last-announced state (BroadcastChannel presence). Always
     *    false for a profile that isn't loaded.
     *  - `description` — the connection record's free-text description.
     * On a duplicate profile name, last-wins (a Lua table can't hold dup keys).
     */
    getProfiles(): Record<string, {
        host: string;
        port: number;
        loaded: boolean;
        connected: boolean;
        description: string;
    }>;
    /** Mudlet `getMudletInfo()`. Echoes a short diagnostic block to the main
     *  window. mudix is a browser client with no Qt build, so it reports the
     *  web-client equivalents (profile, server encoding, platform). */
    getMudletInfo(): void;
    /** Mudlet `loadProfile(name) → bool`. Opens the named profile and connects
     *  to it. Each profile lives in its own browser tab (the per-profile lock
     *  keeps it to one tab), so this opens a NEW tab at `?profile=<id>&connect=1`
     *  rather than switching the current one — the calling profile stays open
     *  alongside, mirroring Mudlet's multi-profile model. Returns false for an
     *  unknown name, when targeting the profile already open in this tab, or when
     *  the browser blocks the popup. NOTE: `window.open` needs a user gesture, so
     *  this works from a key/button/alias but a browser may block it from a
     *  trigger (no Mudlet equivalent to that limitation). */
    loadProfile(name: string): boolean;
    /** Mudlet `getCommandSeparator()`. Returns the profile's command separator
     *  (the string that splits one Enter into multiple commands). Defaults to
     *  `;;` when the profile hasn't customised it. */
    getCommandSeparator(): string;
    /** The persisted catch-all config bag for the active profile (never null). */
    private configBag;
    /** Shallow-merge a single key into the persisted config bag. */
    private patchConfigBag;
    private getProtocol;
    private setProtocol;
    private getMapperField;
    private setMapperField;
    /** Mudlet `getConfig(key)`. Returns the option's value, or `undefined`
     *  (→ Lua nil) for an unknown key. The no-arg / table forms are handled by
     *  the Lua wrapper in Other.lua, which calls this once per key. */
    getConfig(key: string): unknown;
    /** Mudlet `setConfig(key, value)`. Returns true when the key is known and
     *  writable, false for unknown or read-only keys. */
    setConfig(key: string, value: unknown): boolean;
    /** Mudlet `getProfileInformation()`. Returns the profile's free-text
     *  description, or "" when unset. (mudix is single-profile, so the optional
     *  profile-name argument is ignored.) */
    getProfileInformation(): string;
    /** Mudlet `setProfileInformation(text)`. Stores the profile's free-text
     *  description on the connection record (also editable from the connection
     *  screen). Always succeeds for the active profile. */
    setProfileInformation(text: string): boolean;
    /** Mudlet `clearProfileInformation()`. Resets the profile description to
     *  an empty string. */
    clearProfileInformation(): boolean;
    /** Mudlet `getProfileIcon()`. Returns the stored icon as a `data:` URI, or
     *  "" when the profile has no custom icon (the connection screen then shows
     *  the auto-generated name tile). */
    getProfileIcon(): string;
    /** Mudlet `setProfileIcon(path)`. The LuaRuntime binding reads the VFS image
     *  and inlines it as a `data:` URI before calling here, so this method only
     *  stores the already-resolved icon string. Returns false for an empty
     *  value. */
    setProfileIcon(icon: string): boolean;
    /** Mudlet `resetProfileIcon()`. Clears the custom icon so the connection
     *  screen falls back to the auto-generated name tile. */
    resetProfileIcon(): boolean;
    /** Mudlet `holdingModifiers(number)`. True when exactly the given set of
     *  keyboard modifiers (Qt::KeyboardModifier bitmask, as in
     *  `mudlet.keymodifier`) is currently held — exact equality, matching
     *  Mudlet. */
    holdingModifiers(modifiers: number): boolean;
    setSendRequestDispatcher(fn: ((text: string) => boolean) | null): void;
    setConnectDispatcher(fn: ((url: string) => void) | null): void;
    setFeedDispatcher(fn: ((groups: {
        text: string;
        type: string;
    }[]) => void) | null): void;
    setPackageInstaller(fn: ((path: string) => InstallOutcome) | null): void;
    setPackageUninstaller(fn: ((name: string) => boolean) | null): void;
    setPackagesGetter(fn: (() => string[]) | null): void;
    getPackages(): string[];
    setModuleInstaller(fn: ((path: string) => InstallOutcome) | null): void;
    setModuleUninstaller(fn: ((name: string) => boolean) | null): void;
    setModuleSyncer(fn: ((name: string) => Promise<void>) | null): void;
    setModuleReloader(fn: ((name: string) => boolean) | null): void;
    setModuleSyncSetter(fn: ((name: string, sync: boolean) => void) | null): void;
    setModuleSyncGetter(fn: ((name: string) => boolean) | null): void;
    setModulePrioritySetter(fn: ((name: string, priority: number) => boolean) | null): void;
    setModulePriorityGetter(fn: ((name: string) => number) | null): void;
    setModulesGetter(fn: (() => string[]) | null): void;
    setModuleInfoGetter(fn: ((name: string) => Record<string, unknown> | null) | null): void;
    setModuleInfoSetter(fn: ((name: string, key: string, value: string) => boolean) | null): void;
    setModulePathGetter(fn: ((name: string) => string | null) | null): void;
    setPackageInfoGetter(fn: ((name: string) => Record<string, string>) | null): void;
    setPackageInfoSetter(fn: ((name: string, key: string, value: string) => boolean) | null): void;
    installModule(path: string): InstallOutcome;
    uninstallModule(name: string): boolean;
    syncModule(name: string): Promise<void>;
    reloadModule(name: string): boolean;
    enableModuleSync(name: string): void;
    disableModuleSync(name: string): void;
    getModuleSync(name: string): boolean;
    setModulePriority(name: string, priority: number): boolean;
    getModulePriority(name: string): number;
    getModules(): string[];
    getModuleInfo(name: string): Record<string, unknown> | null;
    /** Mudlet `setModuleInfo(name, key, value)`. Stores a custom info field on a
     *  module (visible via getModuleInfo). Always true. */
    setModuleInfo(name: string, key: string, value: string): boolean;
    getModulePath(name: string): string | null;
    /** Mudlet `getPackageInfo(name)`. Merged info table — the package manifest's
     *  standard fields overlaid with anything set via setPackageInfo. Empty when
     *  the package isn't installed and nothing was set. */
    getPackageInfo(name: string): Record<string, string>;
    /** Mudlet `setPackageInfo(name, key, value)`. Stores a custom info field on a
     *  package (visible via getPackageInfo). Always true. */
    setPackageInfo(name: string, key: string, value: string): boolean;
    setScriptToggler(fn: ((name: string, enabled: boolean) => boolean) | null): void;
    setScriptGetter(fn: ((name: string, pos: number) => {
        code: string;
        count: number;
    } | null) | null): void;
    setTriggerToggler(fn: ((name: string, enabled: boolean) => boolean) | null): void;
    setTriggerStayOpenSetter(fn: ((name: string, lines: number) => boolean) | null): void;
    /**
     * Mudlet `setTriggerStayOpen(name, lines)`. Keeps the named trigger's chain
     * open for `lines` more lines of input for the current run only — it adjusts
     * transient chain state, not the persisted trigger's fire-length. 0 closes
     * the chain after the current line; positive values extend or shorten an
     * already-running chain.
     */
    setTriggerStayOpen(name: string, lines: number): boolean;
    setTimerToggler(fn: ((name: string, enabled: boolean) => boolean) | null): void;
    setAliasToggler(fn: ((name: string, enabled: boolean) => boolean) | null): void;
    setKeyToggler(fn: ((name: string, enabled: boolean) => boolean) | null): void;
    setExistsCallback(fn: ((nameOrId: string | number, type: string) => number) | null): void;
    setIsActiveCallback(fn: ((nameOrId: string | number, type: string, checkAncestors: boolean) => number) | null): void;
    setAncestorsCallback(fn: ((id: number, type: string) => Array<{
        id: number;
        name: string;
        node: string;
        isActive: boolean;
    }> | null) | null): void;
    setFindItemsCallback(fn: ((name: string, type: string, exact: boolean, caseSensitive: boolean) => number[]) | null): void;
    setIsAncestorsActiveCallback(fn: ((id: number, type: string) => boolean | null) | null): void;
    setProfileStatsCallback(fn: (() => Record<string, unknown>) | null): void;
    setPermScriptCallback(fn: ((name: string, parent: string, code: string) => number) | null): void;
    setPermRegexTriggerCallback(fn: ((name: string, parent: string, regexes: string[], code: string) => number) | null): void;
    setPermSubstringTriggerCallback(fn: ((name: string, parent: string, patterns: string[], code: string) => number) | null): void;
    setPermBeginOfLineStringTriggerCallback(fn: ((name: string, parent: string, patterns: string[], code: string) => number) | null): void;
    setPermExactMatchTriggerCallback(fn: ((name: string, parent: string, patterns: string[], code: string) => number) | null): void;
    setPermPromptTriggerCallback(fn: ((name: string, parent: string, code: string) => number) | null): void;
    setPermAliasCallback(fn: ((name: string, parent: string, pattern: string, code: string) => number) | null): void;
    setPermTimerCallback(fn: ((name: string, parent: string, delay: number, code: string) => number) | null): void;
    setPermKeyCallback(fn: ((name: string, parent: string, modifier: number, key: string, code: string) => number) | null): void;
    setTempButtonCallback(fn: ((toolbar: string, name: string, code: string, orientation: number) => number) | null): void;
    setTempButtonToolbarCallback(fn: ((name: string, orientation: number, location: number) => number) | null): void;
    setButtonStateSetter(fn: ((name: string, state: boolean) => boolean) | null): void;
    setButtonStateGetter(fn: ((name: string) => boolean | null) | null): void;
    setButtonStyleSheetSetter(fn: ((name: string, css: string) => boolean) | null): void;
    setToolBarToggler(fn: ((name: string, show: boolean) => boolean) | null): void;
    setSetScriptCallback(fn: ((name: string, code: string, pos: number) => number) | null): void;
    /** Hook for ProfileSession to start/stop the per-connection SessionLogger.
     *  Mudlet `startLogging(true|false)` toggles whether new output lines are
     *  recorded; the on/off transition is synchronous. */
    setLoggingToggler(fn: ((enabled: boolean) => boolean) | null): void;
    /** Mudlet `startLogging(state)`. Returns true on success, false when
     *  the toggle isn't wired up yet (e.g. before ProfileSession mounts). */
    startLogging(enabled: boolean): boolean;
    /** Hook for ProfileSession to forward appendLog text to the live logger. */
    setLogAppender(fn: ((text: string) => void) | null): void;
    /** Mudlet `appendLog(text)`. Appends a line to the current session log.
     *  No-op (returns false) when logging isn't active. */
    appendLog(text: string): boolean;
    /** Hook for ProfileSession to close the active profile (return to the
     *  connection screen). */
    setCloseProfileCallback(fn: (() => void) | null): void;
    /** Mudlet `closeMudlet()`. mudix maps it to closing the active profile:
     *  disconnect, then return to the connection screen. */
    closeMudlet(): void;
    setResetProfileCallback(fn: (() => void) | null): void;
    /** Mudlet `resetProfile()` — reload the entire profile as if just opened:
     *  clear every UI surface, recreate the Lua runtime, and re-run all scripts.
     *  The actual work is deferred by the engine (it closes the Lua VM that is
     *  currently executing this call), so this returns immediately. */
    resetProfile(): void;
    setExportAreaImageCallback(fn: ((areaId: number, filePath: string, zLevel?: number) => {
        path: string;
    } | {
        error: string;
    }) | null): void;
    /** Mudlet `exportAreaImage(areaID, filePath[, zLevel])` — render the area to a
     *  PNG file in the profile VFS. Returns `[true, absolutePath]` on success or
     *  `[false, errorMessage]` (e.g. the mapper isn't open, or the area is
     *  unknown). The 0-indexed array is unpacked into Mudlet's multi-return by
     *  Bridge.lua. */
    exportAreaImage(areaId: number, filePath: string, zLevel?: number): [boolean, string];
    setKillByNameCallback(fn: ((kind: 'timer' | 'alias' | 'trigger' | 'key', name: string) => boolean) | null): void;
    killByName(kind: 'timer' | 'alias' | 'trigger' | 'key', name: string): boolean;
    setCssRewriter(fn: ((css: string) => string) | null): void;
    installPackage(path: string): InstallOutcome;
    uninstallPackage(name: string): boolean;
    enableScript(name: string): boolean;
    disableScript(name: string): boolean;
    enableTrigger(name: string): boolean;
    disableTrigger(name: string): boolean;
    enableTimer(name: string): boolean;
    disableTimer(name: string): boolean;
    enableAlias(name: string): boolean;
    disableAlias(name: string): boolean;
    enableKey(name: string): boolean;
    disableKey(name: string): boolean;
    /**
     * Mudlet `getOS()` — the platform name scripts branch on. Mudlet returns
     * the native OS ("windows"/"mac"/"linux"/…); in the browser we report the
     * underlying OS sniffed from the user agent so platform-specific scripts
     * (e.g. mac vs. windows keybinding hints, the bundled accessibility
     * stylesheet) behave sensibly. "unknown" when it can't be determined.
     */
    getOS(): string;
    /**
     * Full Mudlet `getOS()` return tuple, ordered as the C++ pushes it:
     * `osName, osVersion, [osType], processor` — where the Linux branch inserts
     * an extra `osType` (the distribution type) before the processor, so Linux
     * yields 4 values and every other platform 3. The Lua-side `getOS()` wrapper
     * (Bridge.lua) unpacks this 0-indexed array into the multi-return.
     *
     * In the browser none of these come from QSysInfo, so each is sniffed from
     * `navigator` and falls back to a non-empty `"unknown"` (Mudlet's contract,
     * and the busted spec, require non-empty strings).
     */
    getOSInfo(): string[];
    /** Best-effort OS version string from the user agent; "unknown" if absent. */
    private getOSVersion;
    /** Processor string in Mudlet's format ("x86 (64-bit)", "arm64", …). */
    private getOSProcessor;
    /**
     * Mudlet `getWindowsCodepage()` — on native Windows this reads the active
     * ANSI code page (ACP) from the registry as a string; the bundled
     * utf8_filenames.lua consults it (when getOS() == "windows") to decide
     * whether to transcode filenames from UTF-8 to a legacy ANSI page. The
     * browser VFS is always UTF-8, whose code page number is 65001, so we report
     * that on every platform. utf8_filenames keys its mapping table by legacy
     * ANSI page numbers (1250/1252/932/…), none of which is 65001 — so reporting
     * 65001 makes it correctly skip transcoding rather than corrupt UTF-8 paths.
     */
    getWindowsCodepage(): string;
    exists(nameOrId: string | number, type: string): number;
    /**
     * Mudlet `isActive(name|id, type [, checkAncestors])` — count of *active*
     * items matching the name (or 1/0 for an id). An item is active when its own
     * enabled flag is set; with `checkAncestors` (default false) every ancestor
     * group must be enabled too. Type strings mirror `exists`.
     */
    isActive(nameOrId: string | number, type: string, checkAncestors?: boolean): number;
    /** Mudlet `ancestors(id, type)`. Ancestor chain (parent→root) of the item,
     *  or null when no item of that type has the id. */
    ancestors(id: number, type: string): Array<{
        id: number;
        name: string;
        node: string;
        isActive: boolean;
    }> | null;
    /** Mudlet `findItems(name, type [, exact [, caseSensitive]])`. Numeric ids of
     *  matching items/groups. Empty when none match or the type is unknown. */
    findItems(name: string, type: string, exact?: boolean, caseSensitive?: boolean): number[];
    /** Mudlet `isAncestorsActive(id, type)`. True when every ancestor group is
     *  enabled; null when no item of that type has the id. */
    isAncestorsActive(id: number, type: string): boolean | null;
    /** Mudlet `getProfileStats()`. Per-family total/active counts (+ trigger
     *  patterns). See ScriptingEngine.getProfileStats for mudix's caveats. */
    getProfileStats(): Record<string, unknown>;
    permScript(name: string, parent: string, code: string): number;
    permRegexTrigger(name: string, parent: string, regexes: string[], code: string): number;
    /** Mudlet `permSubstringTrigger(name, parent, patterns, luaCode)`. Same
     *  shape as permRegexTrigger but each pattern uses substring matching
     *  (`String.prototype.includes` semantics, like the temp variant). An
     *  empty patterns array creates a trigger group. Returns the new id, or
     *  -1 if `parent` is given but no trigger group of that name exists. */
    permSubstringTrigger(name: string, parent: string, patterns: string[], code: string): number;
    /** Mudlet `permBeginOfLineStringTrigger(name, parent, patterns, luaCode)`.
     *  Same shape as permSubstringTrigger but each pattern matches only when it
     *  appears at the start of the line (`String.prototype.startsWith`, like the
     *  `tempBeginOfLineTrigger` variant). An empty patterns array creates a
     *  trigger group. Returns the new id, or -1 if `parent` is given but no
     *  trigger group of that name exists. */
    permBeginOfLineStringTrigger(name: string, parent: string, patterns: string[], code: string): number;
    /** Mudlet `permExactMatchTrigger(name, parent, patterns, luaCode)`. Same
     *  shape as permSubstringTrigger but each pattern matches only on full-line
     *  equality. An empty patterns array creates a trigger group. Returns the
     *  new id, or -1 if `parent` is given but no trigger group of that name
     *  exists. */
    permExactMatchTrigger(name: string, parent: string, patterns: string[], code: string): number;
    /** Mudlet `permPromptTrigger(name, parent, luaCode)`. Creates a persistent
     *  trigger that fires on every server prompt line (GA/EOR), with no text
     *  pattern. Returns the new id, or -1 if `parent` is given but no trigger
     *  group of that name exists. */
    permPromptTrigger(name: string, parent: string, code: string): number;
    /** Mudlet `permAlias(name, parent, regex, luaCode)`. Creates a persistent
     *  alias under the named parent group (empty = root). Returns the new
     *  alias id, or -1 when `parent` is non-empty but no alias group of that
     *  name exists. */
    permAlias(name: string, parent: string, pattern: string, code: string): number;
    /** Mudlet `permTimer(name, parent, seconds, luaCode)`. Creates a
     *  persistent one-shot timer under the parent group (empty = root).
     *  Returns the new timer id, or -1 when `parent` is non-empty but no
     *  timer group of that name exists. */
    permTimer(name: string, parent: string, delay: number, code: string): number;
    /** Mudlet `permKey(name, parent, modifier, keycode, luaCode)`. Persists a
     *  keybinding under the named parent group (empty = root). Returns the new
     *  id, or -1 when `parent` is non-empty but no key group of that name
     *  exists. `modifier` is the Qt keyboard-modifier int (1=shift, 2=ctrl,
     *  4=alt, 8=meta) — -1 means "no modifier" (Mudlet's convention; used by
     *  `permGroup("name","key")`). */
    permKey(name: string, parent: string, modifier: number, key: string, code: string): number;
    private readonly warnedReservedTempKeys;
    /**
     * Warn (once per unique combo + call site, for this runtime) when a script
     * binds a browser-reserved key via `tempKey`. The profile-load scan covers
     * permanent keybindings, but temp keys are created at runtime and never hit
     * the store, so the check has to happen here at registration time. `key` is a
     * DOM `KeyboardEvent.code`; `modifiers` the {ctrl,shift,alt,meta} subset;
     * `source` is the caller's "script:line" captured by the Lua wrapper.
     */
    warnReservedTempKey(key: string, modifiers: string[], source?: string): void;
    /** Mudlet `tempButton(toolbarName, name, code [, orientation])`. Appends a
     *  transient button under an existing toolbar group; returns the new id, or
     *  -1 when the toolbar doesn't exist. `orientation` is Mudlet's int form
     *  (0=horizontal/1=vertical) — accepted for compat, applied to the
     *  button row inside the toolbar grid. */
    tempButton(toolbar: string, name: string, code: string, orientation: number): number;
    /** Mudlet `tempButtonToolbar(name [, orientation [, location]])`. Creates
     *  a transient toolbar (ButtonNode group). `location` int: 0=top, 1=bottom,
     *  2=left, 3=right, 4=floating. Returns the new id or -1 on duplicate
     *  name. */
    tempButtonToolbar(name: string, orientation: number, location: number): number;
    /** Mudlet `setButtonState(name, state)`. Sets the pressed state of a
     *  two-state (push-down) button by name. Returns false when not found. */
    setButtonState(name: string, state: boolean): boolean;
    /** Mudlet `getButtonState(name)`. Reads the pressed state of a two-state
     *  button. Returns nil when not found. */
    getButtonState(name: string): boolean | null;
    /** Mudlet `setButtonStyleSheet(name, css)`. Stores a CSS string on the
     *  ButtonNode; the renderer applies it inline. Returns false when not
     *  found. */
    setButtonStyleSheet(name: string, css: string): boolean;
    /** Mudlet `showToolBar(name)` / `hideToolBar(name)`. Toggles the toolbar's
     *  effective enabled flag — the existing button bar already gates render
     *  on `isEffectivelyEnabled`, so flipping the group's `enabled` field is
     *  the show/hide hook. Returns true on success, false when not found. */
    setToolBarVisibility(name: string, show: boolean): boolean;
    setScript(name: string, code: string, pos: number): number;
    /** Mudlet `getScript(name [, pos]) → code, count`. Returns the source of the
     *  pos-th (1-indexed) script named `name` and how many scripts share that
     *  name. Returns null when none exist (Bridge.lua surfaces "", 0). */
    getScript(name: string, pos: number): {
        code: string;
        count: number;
    } | null;
    echo(text: string): void;
    echoToWindow(win: string, text: string): void;
    /**
     * Mudlet `echoLink([win,] text, cmd, hint, [useCurrentFormat])`. With
     * `useCurrentFormat=false` (the default), the link is rendered with
     * Mudlet's built-in style: blue foreground + underline. With
     * `useCurrentFormat=true`, the current pen state on the resolved console
     * is preserved.
     */
    echoLink(text: string, cmd: string, tooltip: string, win?: string, useCurrentFormat?: boolean): void;
    /**
     * Build a {@link FormatHyperlink} whose right-click handler opens a context
     * menu listing `cmds` (labelled by `hints`, falling back to the command
     * text). Shared by `echoPopup`/`insertPopup`/`setPopup` — those three differ
     * only in whether the styled span is appended, inserted at the cursor, or
     * applied to the current selection.
     */
    private buildPopupHyperlink;
    /**
     * Build a {@link FormatHyperlink} for an MXP `<SEND>`/`<A>` link. Unlike the
     * popup/link APIs above (whose actions run Lua via `executeScript`), MXP link
     * targets are MUD commands or URLs:
     *  - `kind === 'url'` → left-click opens the URL in a new browser tab.
     *  - `kind === 'command'` → left-click sends the command to the MUD (echoed
     *    like a typed command).
     *  - `promptCmds` (a `cmd1|cmd2|…` list) → right-click shows a popup menu of
     *    the commands, each sending to the MUD.
     * Used by ScriptingEngine when rendering MXP-parsed lines.
     */
    createMxpHyperlink(kind: 'command' | 'url', payload: string, hint?: string, promptCmds?: string[], promptHints?: string[]): FormatHyperlink;
    /** Execute an OSC 8 link URI — a primary action or a menu item. The scheme
     *  decides the behaviour (send / prompt / open URL); anything else is a
     *  no-op (it was already rejected at parse time). */
    private runHyperlinkUri;
    /**
     * Build a {@link FormatHyperlink} for an OSC 8 link URI. The scheme decides
     * the behaviour, mirroring Mudlet: `send:` fires the command immediately,
     * `prompt:` drops it into the command bar for editing, and the web schemes
     * open externally. Returns `undefined` for a disallowed scheme so the link
     * is dropped (the text renders without a click handler).
     */
    createOsc8Hyperlink(uri: string, link?: FormatHyperlink): FormatHyperlink | undefined;
    echoPopup(text: string, cmds: string[], hints: string[], win?: string, useCurrentFormat?: boolean): void;
    /**
     * Mudlet `insertPopup([window,] text, {commands}, {hints})`. Like
     * `insertText`/`insertLink`, but the inserted span carries a right-click
     * popup menu of `cmds`. Inserts at the cursor on the current line and
     * preserves the surrounding pen state; degrades to `echoPopup` when no
     * backing buffer is available (empty console / sub-window without a buffer).
     */
    insertPopup(text: string, cmds: string[], hints: string[], win?: string, useCurrentFormat?: boolean): void;
    /**
     * Mudlet `setPopup([window,] {commands}, {hints})`. Attaches a right-click
     * popup menu to the current selection — preserves the selection's existing
     * colors/attributes (like `setLink`, unlike the homogenizing color setters).
     * `commands` are Lua code strings run when the matching menu entry is
     * chosen. Returns false when there is no selection (or it belongs to a
     * different window).
     */
    setPopup(cmds: string[], hints: string[], win?: string): boolean;
    setExecuteScript(fn: ((code: string) => void) | null): void;
    setExpandAlias(fn: ((text: string, echo: boolean) => void) | null): void;
    expandAlias(text: string, echo: boolean): void;
    setFgColor(r: number, g: number, b: number, win?: string): void;
    setBgColor(r: number, g: number, b: number, a?: number, win?: string): void;
    setBold(v: boolean, win?: string): void;
    setItalic(v: boolean, win?: string): void;
    setUnderline(v: boolean, win?: string): void;
    setStrikethrough(v: boolean, win?: string): void;
    /** Mudlet `setOverline([window,] bool)`. Renders a line above the text
     *  (CSS `text-decoration: overline`, ANSI SGR 53). Mirrors the other style
     *  setters: applies to the active selection when one matches, and updates
     *  the resolved console's pen for subsequent echo. */
    setOverline(v: boolean, win?: string): void;
    /**
     * Mudlet `setReverse([window,] bool)`. Toggles reverse-video — the renderer
     * swaps the fg/bg pair when `inverse` is set (see Console rendering). Mirrors
     * the other style setters: applies to the active selection when one matches,
     * and updates the resolved console's pen for subsequent echo.
     */
    setReverse(v: boolean, win?: string): void;
    /**
     * Mudlet `setTextFormat(windowName, r1, g1, b1, r2, g2, b2, bold, underline,
     * italics, [strikeout], [overline], [reverse], [blinkMode]) → bool`. Sets
     * the full pen state in one call. r1/g1/b1 is BACKGROUND, r2/g2/b2 is
     * FOREGROUND (a Mudlet quirk — preserved here for parity). `blinkMode` is
     * "none" / "slow" / "fast". Returns false when the named window doesn't
     * resolve. Mirrors setFgColor & friends: the pen is updated on the resolved
     * console AND applied to the current selection when one is active on it.
     */
    setTextFormat(windowName: string | undefined, bg: {
        r: number;
        g: number;
        b: number;
    }, fg: {
        r: number;
        g: number;
        b: number;
    }, bold: boolean, underline: boolean, italics: boolean, strikeout: boolean, overline: boolean, reverse: boolean, blinkMode: 'none' | 'slow' | 'fast'): boolean;
    fg(name: string, win?: string): void;
    bg(name: string, win?: string): void;
    resetFormat(windowName?: string): void;
    selectString(str: string, occurrence: number, windowName?: string): number;
    /**
     * Mudlet `selectSection([window,] from, length) → bool`. `from` is 0-indexed.
     * Negative `from` is rejected (Mudlet behavior); zero/negative lengths
     * register a no-op selection but still report success in Mudlet — we match
     * that, but reject when the resolved buffer doesn't exist.
     */
    selectSection(from: number, length: number, windowName?: string): boolean;
    /**
     * Mudlet `selectCurrentLine([window])`. Selects the entire cursor line —
     * equivalent to `selectSection(0, #getCurrentLine())`. Returns false when
     * the named window doesn't exist; true otherwise (the main window always
     * exists, even with no history yet).
     */
    selectCurrentLine(windowName?: string): boolean;
    /**
     * Mudlet `deselect([windowName])`. With a window name, only clears the
     * selection if it belongs to that window — selections in other consoles
     * remain intact. Without an arg, clears unconditionally.
     */
    deselect(windowName?: string): void;
    /**
     * Mudlet `getSelection([windowName])`. Returns the currently selected text
     * along with its 0-based start column and length on the active line. Returns
     * null when no selection is set, or when `windowName` is given and doesn't
     * match the selection's window — the Lua wrapper translates null into
     * Mudlet's `false, "no selection"` 2-tuple.
     */
    getSelection(windowName?: string): {
        text: string;
        start: number;
        length: number;
    } | null;
    /**
     * Mudlet `getFgColor([window])` / `getBgColor([window])`. Reads the fg/bg
     * color at the current selection's start position (Mudlet's P_begin). Each
     * console tracks its own selection in Mudlet; mudix has a single global
     * selection, so when `window` is given it must match the selection's
     * owning window — otherwise we treat it as "no selection in that window"
     * and return null (Mudlet's "no values" shape, surfaced as nil/nil/nil in
     * Lua via the Bridge wrapper).
     *
     * Mudlet returns 0 values when the cursor sits past the end of the line;
     * we mirror that for an empty buffer or a selection whose start is at/
     * past the buffer length. For valid positions where the segment carries
     * no explicit color, we resolve to the profile's default text/background
     * (matching Mudlet's behavior that every TChar carries baked-in colors).
     */
    getFgColor(windowName?: string): [number, number, number] | null;
    getBgColor(windowName?: string): [number, number, number] | null;
    /**
     * Mudlet `isAnsiFgColor(ansiColor)` / `isAnsiBgColor(ansiColor)`. True when
     * the foreground/background color at the current selection's start equals
     * ANSI/xterm color index `ansiColor` (0..7 normal, 8..15 bright, 16..255 the
     * xterm-256 palette). mudix stores rendered RGB rather than the original
     * ANSI index, so the comparison is against the palette entry's RGB — exact
     * for the 256 standard slots. Returns false when there's no selection (or it
     * belongs to another window) or `ansiColor` is out of range.
     */
    isAnsiFgColor(ansiColor: number): boolean;
    isAnsiBgColor(ansiColor: number): boolean;
    private matchesAnsiColor;
    private readSelectionColor;
    /**
     * Resolve the rgb of `channel` for the character at `pos` in `buf`, falling
     * back to the profile's configured default when the run carries no explicit
     * colour. Shared by getFgColor/getBgColor (selection) and getTextFormat
     * (selection or cursor).
     */
    private readColorAt;
    /**
     * Mudlet `getTextFormat([windowName]) → table | nil, errMsg`. Reads the full
     * set of display attributes of the character at the current selection's start
     * position (Mudlet's "char under cursor or selection"). Mirrors getFgColor /
     * getBgColor: requires an active selection that, when `windowName` is given,
     * belongs to that window, and whose start is within the buffer — otherwise
     * returns null (surfaced as nil + reason by the Bridge wrapper).
     *
     * `foreground`/`background` resolve through the same logic as getFgColor /
     * getBgColor (falling back to the profile defaults for unstyled segments).
     * `overline`, `concealed`, and `alternateFont` have no equivalent in mudix's
     * FormatState, so they report Mudlet's "off" values (false / 0) for parity.
     */
    getTextFormat(windowName?: string): {
        bold: boolean;
        italic: boolean;
        underline: boolean;
        strikeout: boolean;
        reverse: boolean;
        overline: boolean;
        concealed: boolean;
        alternateFont: number;
        blinking: 'none' | 'slow' | 'fast';
        foreground: [number, number, number];
        background: [number, number, number];
    } | null;
    applyFormatToSelection(state: FormatStateSnapshot): void;
    /**
     * Mudlet `setLink([windowName], command, hint)`. Applies a clickable
     * hyperlink to the current selection — preserves existing colors/attributes
     * on each segment (unlike setFgColor & friends which homogenize). `command`
     * is the Lua code run on click; the Bridge.lua wrapper converts function
     * arguments into a `__mudix_call_link(id)` string before reaching here.
     * Returns false if there is no selection (or it doesn't belong to `win`).
     */
    setLink(cmd: string, tooltip: string, win?: string): boolean;
    /**
     * Called before trigger processing for each incoming line. Pushes the
     * matching line into mainConsole.history so cursor-driven APIs see it as
     * a regular addressable line (Mudlet's TBuffer holds the matching line
     * during trigger processing — the cursor is just an (x,y) into that
     * single buffer). The cursor is automatically positioned on the new line
     * at column 0 by Console.appendLine. Also enables echo deferral so
     * trigger-emitted echoes appear after the rendered line.
     */
    beginLine(buffer: AnsiAwareBuffer, isPrompt?: boolean): void;
    /**
     * Called after all triggers for a line have run (but before render).
     * Drops the trigger-active flag; echo deferral stays on until
     * flushDeferredEcho() is called.
     */
    endLine(): void;
    /**
     * Mudlet `tempColorTrigger(fg, bg)` colour-scan helper. Walks the
     * just-appended line buffer (the one beginLine() seeded mainConsole with)
     * and returns true if any segment carries the requested ANSI palette
     * indices. `wantFg`/`wantBg` accept -1 as "any colour"; non-indexed
     * (RGB) segments never match a positive index, matching Mudlet's
     * palette-only semantics.
     */
    currentLineMatchesColor(wantFg: number, wantBg: number): boolean;
    /**
     * Flush echo output collected during the just-processed line's trigger run.
     * Called once per line (right after that line is rendered) so a trigger's
     * `echo`/`cecho` lands immediately after the line it fired on — matching
     * Mudlet, where the trigger cursor sits on the matching line and echoed text
     * is inserted there, not piled at the end of the whole flush batch.
     *
     * Emits the completed echo lines, then promotes any trailing partial (an
     * echo without a closing newline, e.g. `cecho("\n text")`) into its own
     * line via `completePartialLine` — which preserves history so later lines in
     * the batch keep correct line numbers, unlike the old wholesale `clear()`.
     */
    flushDeferredEcho(): void;
    /**
     * Feed `text` through the trigger pipeline as if it arrived from the MUD.
     * Routes complete lines through ScriptingEngine.processFlushBatch (same
     * code path as network-driven flushLines) so trigger ordering, ANSI carry,
     * and deferred-echo placement match exactly.
     */
    feedTriggers(text: string): void;
    /**
     * Mudlet `getCurrentLine([window])`. Returns the text on the cursor's
     * current line, or `null` when the named window doesn't exist — the Lua
     * binding turns that into Mudlet's `(nil, errMsg)` 2-tuple. Falls back to
     * an empty string for the main window (always present, may have no line yet).
     */
    getCurrentLine(windowName?: string): string | null;
    getLineNumber(windowName?: string): number;
    getLineCount(windowName?: string): number;
    getLastLineNumber(windowName?: string): number;
    disableScrollBar(windowName?: string): void;
    enableScrollBar(windowName?: string): void;
    disableHorizontalScrollBar(windowName?: string): void;
    enableHorizontalScrollBar(windowName?: string): void;
    disableScrolling(windowName?: string): boolean;
    enableScrolling(windowName?: string): boolean;
    /** Mudlet getScroll — 0-indexed buffer line at the top of the viewport. In
     *  tail mode reports the last line (Mudlet's mCursorY behaviour at end). */
    getScroll(windowName?: string): number;
    /** Mudlet scrollTo. With no line (or a line past end), resume tail mode.
     *  Negative line counts back from the buffer end. */
    scrollTo(windowName: string | undefined, lineNumber: number | undefined): boolean;
    getLines(from: number, to: number, windowName?: string): string[];
    /**
     * Mudlet `getTimestamp([window,] lineNumber)` — the wall-clock time the line
     * entered the buffer, formatted "HH:MM:SS.mmm" (Mudlet's "hh:mm:ss.zzz").
     * `lineNumber` is 1-based to match `getLines`; omit it for the current
     * cursor line. Returns null when the window or line doesn't exist — the Lua
     * binding maps that to Mudlet's `(nil, errMsg)` shape.
     */
    getTimestamp(lineNumber?: number, windowName?: string): string | null;
    /**
     * Mudlet `wrapLine([window,] lineNumber)`. Re-displays the line at
     * `lineNumber` (0-indexed, like getLineNumber/getLineCount), re-interpreting
     * its embedded `\n` and re-wrapping to the current width. Returns false when
     * the window or line doesn't exist.
     */
    wrapLine(lineNumber: number, windowName?: string): boolean;
    /**
     * Mudlet `getConsoleBufferSize([consoleName])` → (linesLimit, batchSize).
     * Returns `null` when the named console doesn't exist so the Lua binding can
     * hand back nil.
     */
    getConsoleBufferSize(windowName?: string): [number, number] | null;
    /**
     * Mudlet `setConsoleBufferSize([consoleName], linesLimit, sizeOfBatchDeletion)`.
     * Sets the scrollback cap (and the round-tripped batch-deletion size).
     * Returns false when the named console doesn't exist.
     */
    setConsoleBufferSize(windowName: string | undefined, linesLimit: number, batchSize?: number): boolean;
    getColumnNumber(windowName?: string): number;
    /** Mudlet `isPrompt()` — reports the per-line prompt flag at the current
     *  cursor position. Lines pushed via beginLine carry the flag, so
     *  moveCursor + isPrompt can inspect historical lines, not just the most
     *  recent one. Defaults to false for the main window when no history exists. */
    isPrompt(windowName?: string): boolean;
    /**
     * Mudlet getColumnCount. Reports the displayable column capacity of the
     * rendered output area — how many monospace characters fit horizontally.
     * Unaffected by setWindowWrap; that controls where lines wrap when text is
     * appended to the buffer, not the screen width. Returning the wrap value
     * would break the canonical Mudlet idiom
     *   setWindowWrap(name, getColumnCount(name) - 1)
     * called from a sysUserWindowResizeEvent handler, where each resize would
     * otherwise feed the stored wrap back in and decrement it by one.
     *
     * Fallback path: scripts that just called openUserWindow + resizeWindow
     * commonly busy-loop on getColumnCount in the same JS turn — React can't
     * render the new panel until the loop yields, so a pure DOM measurement
     * stays at 0 forever and the loop hangs. When the window exists but the
     * element hasn't mounted (or measures zero), derive an estimate from the
     * window's logical pixel width and the active font's cell width, so the
     * reported column count tracks resizeWindow even before layout commits.
     */
    getColumnCount(windowName?: string): number;
    /**
     * Mudlet getRowCount(name). Reports the displayable row capacity of the
     * named window (or "main") — how many text lines fit vertically in the
     * rendered area. Mirrors getColumnCount: measures the live element, and
     * falls back to a font-derived estimate from the stored window height when
     * the panel hasn't mounted yet (so resize+busy-loop scripts don't hang).
     */
    getRowCount(windowName?: string): number;
    /**
     * Mudlet setWindowWrap(name, charsPerLine). Sets the visual wrap width
     * (in monospace columns) for the named window or "main". 0 clears the
     * setting. Returns false when the named window does not exist; main always
     * succeeds (persisted on the active profile).
     */
    setWindowWrap(name: string, wrapAt: number): boolean;
    /**
     * Mudlet `getWindowWrap(name) → cols`. Reports the visual wrap width set by
     * setWindowWrap (0 when unset). For "main" reads the profile's stored
     * override; for a named window reads the WindowManager hint. Returns -1 when
     * the named window does not exist (Mudlet's invalid-window sentinel).
     */
    getWindowWrap(name: string): number;
    /**
     * Mudlet `setWindowWrapIndent(name, indent)`. Sets the indent (in
     * characters) applied to newline-started lines in the named window or
     * "main". Returns false when the named window does not exist.
     */
    setWindowWrapIndent(name: string, indent: number): boolean;
    /**
     * Mudlet `setWindowWrapHangingIndent(name, indent)`. Sets the indent (in
     * characters) applied to wrapped continuation lines in the named window or
     * "main". Returns false when the named window does not exist.
     */
    setWindowWrapHangingIndent(name: string, indent: number): boolean;
    /**
     * Mudlet `setMapWindowTitle(title)`. Sets the dockable map panel's tab
     * title; an empty string resets it to the default ("Map"). Returns false
     * when the map widget isn't open.
     */
    setMapWindowTitle(title: string): boolean;
    /**
     * Mudlet `insertText([window,] text)`. Inserts `text` at the cursor on
     * the cursor's current line — works the same way during trigger processing
     * (cursor is on the just-appended matching line) and outside (cursor is
     * wherever moveCursor put it). Falls back to an end-of-buffer echo only
     * when the cursor isn't on a valid line yet (empty buffer / sub-window
     * without a backing buffer).
     */
    insertText(text: string, windowName?: string): void;
    /**
     * Mudlet `insertLink([window,] text, cmd, hint, [useCurrentFormat])`.
     * Like `insertText` but the inserted span is a clickable link bound to
     * `cmd`. With `useCurrentFormat=false` (the default) the link inherits
     * Mudlet's built-in style — blue foreground + underline — layered on top
     * of the current pen state. If no buffer is available (empty console,
     * sub-window without backing buffer) the call degrades to `echoLink` so
     * the text isn't lost.
     */
    insertLink(text: string, cmd: string, tooltip: string, windowName?: string, useCurrentFormat?: boolean): void;
    /**
     * Mudlet `moveCursorUp([window,] [lines=1,] [keepHorizontal=false]) → bool`.
     * `keepHorizontal=true` preserves the column across the vertical move; the
     * default (false) resets the column to 0.
     */
    moveCursorUp(windowName?: string, lines?: number, keepHorizontal?: boolean): boolean;
    moveCursorDown(windowName?: string, lines?: number, keepHorizontal?: boolean): boolean;
    /**
     * Mudlet `moveCursor([window,] x, y) → bool`. The cursor is just an (x,y)
     * into the central buffer — works the same way during trigger processing
     * and outside, because the matching line is pushed into Console.history
     * before triggers fire (Mudlet has the same model: matching line is the
     * last line in TBuffer; cursor.y is its index). Returns true on a
     * successful move.
     */
    moveCursor(windowName: string | undefined, x: number, y: number): boolean;
    moveCursorEnd(windowName?: string): void;
    clearWindow(name?: string): void;
    /**
     * Mudlet `createMiniConsole([parent,] name, x, y, width, height)`. Creates
     * a positioned text panel inside the given parent (defaults to `main`), or
     * repositions it if it already exists (Mudlet 3.0+ semantics). When parent
     * is a userwindow, the miniconsole renders inside that parent's viewport
     * at parent-relative coordinates and follows parent moves/resizes.
     * Returns true on success.
     */
    createMiniConsole(name: string, x: number, y: number, width: number, height: number, parent?: string): boolean;
    /**
     * Mudlet `deleteMiniConsole(name)`. Destroys a mini-console created by
     * createMiniConsole, freeing its registry/buffer/console state. Restricted
     * to mini-consoles (mirrors Mudlet's CONSOLE-only check) — returns false
     * for the main window, dockable panels, or an unknown name.
     */
    deleteMiniConsole(name: string): boolean;
    /**
     * MXP `<FRAME>` (Mudlet 4.21). Maps an MXP frame onto a mini-console — the
     * browser has no OS-level child/floating windows, so internal, external and
     * floating frames all become overlay mini-consoles. `attrs` keys are
     * upper-cased (see `MxpFrameCommand`). `ACTION=close` deletes the frame;
     * anything else opens it (or repositions it if it already exists). Geometry
     * (`LEFT`/`TOP`/`WIDTH`/`HEIGHT`) accepts pixels, `N%` of the main window, or
     * `Nc` character cells.
     */
    mxpFrame(name: string, attrs: Record<string, string>): void;
    /**
     * Write an MXP `<DEST>` redirected line into a frame's mini-console. Returns
     * false when no mini-console of that name exists (the caller then renders the
     * text inline in the main window, matching Mudlet). `eof` clears the frame
     * first — the status-frame "replace contents" idiom.
     */
    mxpWriteToFrame(name: string, buffer: AnsiAwareBuffer, eof: boolean): boolean;
    /** Parse an MXP geometry dimension: `N%` → fraction of `ref`, `Nc` → N
     *  character cells (approximate), bare number → pixels. null when absent. */
    private parseMxpDim;
    /**
     * Mudlet `createBuffer(name)`. Registers a named off-screen console for
     * formatting and storing rich text — like a miniconsole, but never shown
     * on screen (no dock panel). echo/cecho/format/selection target it by name;
     * `copy` + `appendBuffer` move formatted text in and out. Idempotent and a
     * no-op when the name is taken by `main` or an existing on-screen window.
     */
    createBuffer(name: string): void;
    /** True when `name` is an off-screen buffer created via createBuffer. */
    isBuffer(name: string): boolean;
    /**
     * Mudlet `copy([window])`. Copies the current selection of the resolved
     * console — including all formatting — into the session clipboard, a single
     * rich-text buffer shared with `paste`/`appendBuffer` (Mudlet's host-global
     * mClipboard). No-op when there's no selection, or when `window` is given
     * but doesn't own the active selection.
     */
    copy(windowName?: string): void;
    /**
     * Mudlet `appendBuffer([window])`. Appends the clipboard's rich text (from
     * the last `copy()`) as a new line at the end of the named console's buffer.
     * No-op until something has been copied. Mirrors TConsole::appendBuffer.
     */
    appendBuffer(windowName?: string): void;
    /**
     * Mudlet `paste([window])`. Inserts the clipboard at the cursor's current
     * column when the cursor sits above the last line; otherwise appends it as
     * a new line at the end (TConsole::paste semantics). No-op without a prior
     * copy().
     */
    paste(windowName?: string): void;
    /**
     * Mudlet `createMapper([parent,] x, y, width, height)`. Creates a positioned
     * mapper widget inside the given parent (defaults to `main`), or repositions
     * it if it already exists. Singleton: Mudlet allows only one in-console
     * mapper at a time, so we reuse a fixed id (`mapper`) — distinct from the
     * dockable map widget opened by `openMapWidget` (id `map`). Both render the
     * same MapStore and stay in sync. Returns true on success.
     */
    createMapper(x: number, y: number, width: number, height: number, parent?: string): boolean;
    /**
     * Mudlet `replace([win,] with, [keepcolor])`. Default (`keepcolor=false`)
     * applies the resolved console's current pen state (set via
     * setFgColor/setBgColor/etc.) to the replacement text. With
     * `keepcolor=true`, the replacement inherits the selection's existing
     * format — same as our previous behavior.
     */
    replace(newText: string, windowName?: string, keepColor?: boolean): void;
    /**
     * Mudlet `deleteLine([window])`. Marks the cursor's current buffer as
     * deleted. When that buffer is the matching line of an in-flight trigger,
     * the renderer skips emitting it; when it's a rendered history line,
     * Console.deleteLine removes it from the DOM.
     */
    deleteLine(windowName?: string): void;
    appendCmdLine(text: string): void;
    printCmdLine(text: string): void;
    clearCmdLine(): void;
    /**
     * Mudlet selectCmdLineText([commandLine]). Selects (highlights) all text in
     * the command bar so the next keystroke overtypes it. mudix has a single
     * main command bar; a named overlay command-line arg is accepted for
     * compatibility but only "main"/omitted is acted upon. The actual DOM
     * selection happens in ProfileSession, which owns the input ref.
     */
    selectCmdLineText(name?: string): void;
    /**
     * Mudlet setCommandBackgroundColor([windowName], r, g, b, [transparency]).
     * Recolors the command bar's background. mudix only has the main command
     * bar, so a non-"main" windowName is ignored. `a` is Mudlet's 0..255 alpha;
     * the CommandBar reads the `inputBackground` profile field as a CSS color.
     */
    setCommandBackgroundColor(r: number, g: number, b: number, a?: number, name?: string): boolean;
    /** Mudlet setCommandForegroundColor — recolors the command bar text. */
    setCommandForegroundColor(r: number, g: number, b: number, a?: number, name?: string): boolean;
    private cmdLineProvider;
    setCmdLineProvider(fn: (() => string) | null): void;
    getCmdLine(): string;
    private cmdLineSuggestions;
    addCmdLineSuggestion(suggestion: string): void;
    removeCmdLineSuggestion(suggestion: string): void;
    clearCmdLineSuggestions(): void;
    getCmdLineSuggestions(): string[];
    private emitCmdLineSuggestions;
    /**
     * Mudlet `openUrl(url) → bool`. Opens a URL in a new browser tab. Special
     * case: a `file:` prefix (as in `openUrl("file:" .. getMudletHomeDir())`)
     * routes to the in-app VFS file browser at the given path, since web pages
     * can't navigate to `file:` URLs.
     */
    openUrl(url: string): boolean;
    private cmdLineAction;
    setCmdLineAction(fn: ((text: string) => void) | null): void;
    /** Engine-side accessor: returns the currently registered action, or null. */
    getCmdLineAction(): ((text: string) => void) | null;
    private eventRaiser;
    setEventRaiser(fn: ((event: string, args: unknown[]) => void) | null): void;
    setAppStyleSheet(css: string, tag?: string): boolean;
    setUserWindowStyleSheet(name: string, css: string): boolean;
    /**
     * Mudlet `setProfileStyleSheet(stylesheet)`. Installs (or replaces) a
     * profile-wide CSS block. In Mudlet this themes the whole profile's
     * widgets; the browser analogue is a single `<style>` tag in document.head,
     * keyed separately from setAppStyleSheet's blocks so the two don't clobber
     * each other. Raises sysAppStyleSheetChange (tag "profile") for parity with
     * the app-level setter. Always returns true.
     */
    setProfileStyleSheet(css: string): boolean;
    /**
     * Mudlet `setClipboardText(textContent)`. Updates the session text
     * clipboard and best-effort writes it to the OS clipboard via
     * navigator.clipboard (which may reject without a user gesture or in an
     * insecure context — the in-process mirror is authoritative regardless).
     * Always returns true.
     */
    setClipboardText(text: string): boolean;
    /**
     * Mudlet `getClipboardText()`. Returns the session text clipboard. Because
     * the OS clipboard can only be read asynchronously in the browser, we kick
     * off a best-effort refresh (so a subsequent call reflects an external copy)
     * and return the current mirror synchronously, matching Mudlet's signature.
     */
    getClipboardText(): string;
    centerView(roomId: number): boolean;
    /**
     * Mudlet `getMapZoom([areaID])`. mudix renders one area at a time through a
     * single shared 2D view, so `areaID` has no per-area analogue — the current
     * view's zoom is returned regardless. The value is Mudlet-compatible: the
     * number of map units visible across the viewport's shorter edge. Returns
     * false when no map panel is mounted (the Lua binding turns that into nil).
     */
    getMapZoom(_areaID?: number): number | false;
    /**
     * Mudlet `setMapZoom(zoom [, areaID])`. `zoom` is the number of map units to
     * fit across the viewport's shorter edge (larger = more map shown / zoomed
     * out); like Mudlet it must be at least 3.0. Returns false for an invalid
     * zoom or when no map panel is mounted to receive it.
     */
    setMapZoom(zoom: number, _areaID?: number): boolean;
    /** Mudlet `updateMap()` — force the map to re-read MapStore and redraw. */
    updateMap(): void;
    getRoomIDbyHash(hash: string): number | undefined;
    get map(): import("../map/MapStore").MapStore;
    get cmdLineMenu(): import("../ui/CmdLineMenuRegistry").CmdLineMenuRegistry;
    get mouseEvents(): import("../ui/MouseEventRegistry").MouseEventRegistry;
    get sounds(): import("../ui/sound/SoundManager").SoundManager;
    get videos(): import("../ui/video/VideoManager").VideoManager;
    /** Mudlet `setMapBackgroundColor(r, g, b)`. Persists into the profile
     *  mapper settings so MapPanel picks it up on its next render pass. */
    setMapBackgroundColor(r: number, g: number, b: number): boolean;
    /** Mudlet `setMapRoomSize(size)`. Maps to renderer.settings.roomSize via
     *  the profile mapper field. Returns false for non-positive values. */
    setMapRoomSize(size: number): boolean;
    /** Mudlet `getMapRoomSize()`. Reads the active room-size value. Falls back
     *  to the MAPPER_DEFAULTS.roomSize when unset. */
    getMapRoomSize(): number;
    /**
     * Mudlet `loadMap([location])`. Persists the bytes (when given) to the
     * connection's binary-map IndexedDB slot and re-renders any open MapPanel.
     * The Lua binding in LuaRuntime reads the VFS path before calling here so
     * this method only deals in already-decoded bytes. Returns true unless the
     * panel reported a parse failure for the given buffer.
     */
    loadMap(buf?: Uint8Array): boolean;
    /**
     * Mudlet `saveMap([location])`. Serialises the current MapStore to the
     * Mudlet binary `.dat` format and persists it to the connection's default
     * IndexedDB slot (so it survives reload). Returns the bytes so the Lua
     * binding can also write them to a VFS path when one is supplied. Returns
     * null when serialisation fails.
     */
    saveMap(): Uint8Array | null;
    /** Mudlet `saveJsonMap(path)` backbone — serialises the current MapStore
     *  as JSON. The Lua binding writes the result to the supplied VFS path. */
    saveJsonMap(): string;
    /** Mudlet `loadJsonMap(path)` backbone — parse a JSON payload previously
     *  produced by saveJsonMap and reload the map. Returns false when the
     *  JSON is malformed or doesn't match the MudletMap shape. */
    loadJsonMap(json: string): boolean;
    /** Mudlet `addSupportedTelnetOption(option)`. Forwarded to the session
     *  client so the next IAC WILL/DO from the server can be auto-accepted. */
    addSupportedTelnetOption(option: number): boolean;
    /**
     * Mudlet `saveWindowLayout()` — capture the current layout (window hints
     * + dock area extents) into a per-connection snapshot in the persisted
     * app store. A later `loadWindowLayout()` re-applies the captured state.
     * Returns true on success, false when no connectionId is bound.
     */
    saveWindowLayout(): boolean;
    /**
     * Mudlet `loadWindowLayout()` — restore the most recently saved snapshot
     * for this connection. Re-applies geometry, dock state, font/colour, and
     * visibility to live windows; opens windows that the snapshot had visible
     * but are not currently mounted. Returns false when no snapshot exists.
     */
    loadWindowLayout(): boolean;
    /**
     * Mudlet `getTime()` — current local time as a record. The Bridge.lua wrapper
     * picks fields off this object for the `{year, month, day, hour, min, sec,
     * msec}` table form, and uses `wday` (0=Sun..6=Sat) to format `ddd`/`dddd`
     * tokens when the script asks for a formatted string.
     */
    getTime(): {
        year: number;
        month: number;
        day: number;
        hour: number;
        min: number;
        sec: number;
        msec: number;
        wday: number;
    };
    /**
     * Mudlet `getNetworkLatency()` — round-trip time of the most recent
     * keep-alive ping. Returns the last measured value (in ms) for as long as
     * the connection is up; -1 when no measurement has been made yet (mirrors
     * Mudlet's "not yet measured" sentinel — better than a fake 0 which would
     * read as "instant" in scripts charting latency).
     */
    getNetworkLatency(): number;
    private lastPingMs;
    getMainWindowSize(): [number, number];
    /**
     * Mudlet `hasFocus([window])` → bool. Reports whether the named console (or
     * the main command bar / output area when omitted) currently holds keyboard
     * focus. mudix maps "main"/omitted to the command input, and a named window
     * to its registered overlay element. Returns false when nothing matches.
     */
    hasFocus(windowName?: string): boolean;
    /**
     * Mudlet `alert([seconds])`. Mudlet flashes the taskbar entry to grab the
     * user's attention; browsers have no taskbar-flash API, so we flash the
     * document title (alternating with a "● " bell prefix) for `seconds`
     * (default 10, Mudlet's default), and skip the flash entirely while the tab
     * is already focused — matching Mudlet, which no-ops when the window is
     * active.
     */
    alert(seconds?: number): void;
    /**
     * Mudlet `getMainConsoleWidth()` — pixel width of the main console's text
     * area. Mudlet computes `averageCharWidth * (wrapAt + 1)`; we mirror that
     * with a canvas-measured monospace cell for the profile's output font, and
     * resolve the wrap column from the profile's `outputWrapAt` override (the
     * value `setWindowWrap("main", n)` writes), falling back to the live
     * measured column count when no explicit wrap is set.
     */
    getMainConsoleWidth(): number;
    /**
     * Mudlet `getConnectionInfo()` → `host, port, connected`. Mudlet reports the
     * MUD's telnet host/port; mudix reads them off the active connection config.
     * For a `mud`-mode connection those are the stored host/port; for a raw
     * `websocket` connection we parse them out of the endpoint URL (port falls
     * back to the ws/wss default). `connected` reflects the live session status.
     */
    getConnectionInfo(): {
        host: string;
        port: number;
        connected: boolean;
    };
    /**
     * Mudlet `connectToServer(host, port [, save])`. mudix tunnels MUD traffic
     * through a WebSocket proxy, so this builds the same `proxy?host=&port=` URL
     * the connection screen uses and (re)connects the live session. With `save`,
     * the host/port are persisted onto the active connection (switching it to
     * mud-mode) so they survive a reload — the analogue of Mudlet's profile
     * write. Returns false for an out-of-range port.
     */
    connectToServer(host: string, port?: number, save?: boolean): boolean;
    /**
     * Mudlet `getLabelSizeHint(name)` → `width, height` (the label's preferred
     * content size). Returns null when no such label — the Lua binding maps that
     * to Mudlet's `(nil, errMsg)` shape.
     */
    getLabelSizeHint(name: string): {
        width: number;
        height: number;
    } | null;
    /**
     * Mudlet `announce(text [, processing])` — push `text` to assistive tech.
     * Mudlet raises a Qt accessibility announcement; the browser equivalent is
     * an ARIA live region. `processing` maps to live-region politeness exactly
     * as Mudlet does: `importantall`/`importantmostrecent` → `assertive`, every
     * other value → `polite`. Two persistent off-screen regions are reused so
     * repeated calls don't pile up DOM nodes. The text is cleared then re-set on
     * a microtask so screen readers re-announce even identical consecutive
     * messages (a live region that doesn't change is not spoken again).
     */
    announce(text: string, processing?: string): void;
    /**
     * Mudlet `showNotification(title [, content [, expiryInSeconds]])` → true.
     * Mudlet pops a system tray notification; the browser equivalent is the Web
     * Notifications API. `content` defaults to `title` (matching Mudlet). `expiry`
     * (when given, ≥1s) auto-closes the notification.
     *
     * Gated on the user having opted in via Settings (`client.notificationsEnabled`),
     * which is also where the browser permission prompt is raised — so we never
     * trigger a permission pop-up from a script call here, and silently no-op
     * unless the user enabled notifications AND the browser granted permission.
     * Mudlet always returns true regardless of whether anything is shown, so we
     * match that — the return value reflects "the call was accepted", not "a
     * notification appeared".
     */
    showNotification(title: string, content?: string, expirySeconds?: number): boolean;
    /**
     * Mudlet getMousePosition() → x, y in main-console-local pixels. Tracked
     * passively via document-level pointermove/mousedown — before any input
     * has been seen returns 0,0. When the cursor is outside the main viewport
     * the result is negative or past the viewport bounds (same as Qt's
     * mapFromGlobal). Falls back to viewport coords if the main element
     * isn't mounted.
     */
    getMousePosition(): [number, number];
    /**
     * Mudlet getUserWindowSize(name). Returns the rendered [width, height] of a
     * userwindow / miniconsole in pixels. Reports the live element box when the
     * panel is mounted (so docked panels reflect their actual on-screen size),
     * otherwise falls back to the stored window hint. Returns [0, 0] when the
     * window doesn't exist.
     */
    getUserWindowSize(name: string): [number, number];
    /**
     * Mudlet setFontSize. Without `win` (or "main"), persists the size on the
     * active profile so the main output picks it up. With a window name, sets
     * the per-window output font size on WindowManager (saved into the hint).
     */
    setFontSize(size: number, win?: string): boolean;
    /**
     * Mudlet setMiniConsoleFontSize. Strictly targets miniconsoles (created via
     * createMiniConsole / createConsole) — userwindows and labels are rejected
     * the same way Mudlet's CONSOLE-only lookup rejects them.
     */
    setMiniConsoleFontSize(name: string, size: number): boolean;
    /**
     * Mudlet getFontSize. Returns the configured font size in pixels for the
     * main window (when no name passed) or for a specific window. Returns null
     * if a named window doesn't exist or has no override.
     */
    getFontSize(win?: string): number | null;
    /**
     * Mudlet setBackgroundColor. With no name (or "main") sets the main window
     * background; otherwise dispatches to the matching label or userwindow/
     * miniconsole. Channels are 0..255; alpha defaults to 255.
     */
    setBackgroundColor(name: string | undefined, r: number, g: number, b: number, a?: number): boolean;
    /**
     * Mudlet getBackgroundColor. Without a name (or "main") returns the main
     * window background; otherwise looks up the named window/miniconsole. Labels
     * fall through here too — their fill color is reported. Returns null when
     * the name doesn't resolve to anything; callers (Lua wrapper) translate that
     * to a 4-tuple of zeros.
     */
    getBackgroundColor(name?: string): {
        r: number;
        g: number;
        b: number;
        a: number;
    } | null;
    /**
     * Mudlet `setBackgroundImage`. Dispatcher across labels, miniconsoles /
     * userwindows, and the main window — matches Mudlet's overload set:
     *
     *   setBackgroundImage(labelName, imageLocation)           → label
     *   setBackgroundImage(imageLocation, [mode])              → main console
     *   setBackgroundImage(windowName, imageLocation, [mode])  → miniconsole / userwindow
     *
     * Disambiguation matches Mudlet's C++ semantics — label lookup wins when
     * the named widget is a label; otherwise the call is treated as a console
     * form. `mode` arrives already coerced to a number by the GUIUtils.lua
     * wrapper (string mode like "center" → 2 via `mudlet.BgImageMode`). For
     * label form `imageLocation` is a VFS path, resolved through the same
     * rewriter that powers setLabelStyleSheet so package-bundled images work
     * without scripts knowing about the vfs:// scheme.
     */
    setBackgroundImage(a: string, b?: string | number, c?: number): boolean;
    /**
     * Mudlet `resetBackgroundImage([windowName])`. Without a name (or "main")
     * clears the main window background image; otherwise looks up the named
     * label or window and clears its image. Returns true on success.
     */
    resetBackgroundImage(name?: string): boolean;
    /**
     * Mudlet `setLabelCustomCursor(labelName, cursorPath, [hotX, hotY])`. Points
     * the label's mouse cursor at a custom image. The path is run through the
     * VFS-aware URL resolver (same as setBackgroundImage) so package-relative
     * paths resolve, then composed into a CSS `cursor: url(...) hotX hotY, auto`
     * value. hotX/hotY are the cursor hotspot in pixels (default 0,0). Returns
     * false when the label doesn't exist.
     */
    setLabelCustomCursor(name: string, path: string, hotX?: number, hotY?: number): boolean;
    private applyBackgroundImage;
    /** Runs `path` through the active VFS-aware CSS rewriter so package paths
     *  (e.g. `MyPackage/bg.png`) resolve to vfs:// URLs the renderer can load.
     *  Absolute http(s):/data:/blob: URIs pass through untouched. */
    private resolveImageUrl;
    setBorderTop(size: number): void;
    setBorderBottom(size: number): void;
    setBorderLeft(size: number): void;
    setBorderRight(size: number): void;
    /**
     * Mudlet setBorderSizes — CSS-shorthand-style overloads:
     *   1 arg  → uniform                 (all = a)
     *   2 args → (vertical, horizontal)  (top=bottom=a, left=right=b)
     *   3 args → (top, horizontal, bot)  (left=right=b)
     *   4 args → CSS top/right/bottom/left
     * Other arities no-op (matches Mudlet's silent reject).
     */
    setBorderSizes(a?: number, b?: number, c?: number, d?: number): void;
    getBorderTop(): number;
    getBorderBottom(): number;
    getBorderLeft(): number;
    getBorderRight(): number;
    getBorderSizes(): {
        top: number;
        right: number;
        bottom: number;
        left: number;
    };
    /** Mudlet setBorderColor. Channels are 0..255; alpha defaults to 255. */
    setBorderColor(r: number, g: number, b: number, a?: number): void;
    /** Mudlet resetBorderColor — clears the override so the border tracks the page background again. */
    resetBorderColor(): void;
    /** Mudlet getBorderColor — RGB of the main console frame border. Returns the
     *  explicit setBorderColor override when set; otherwise the main window
     *  background (which the border visually inherits), falling back to black. */
    getBorderColor(): [number, number, number];
    /** Mudlet `getProcessMemoryUsage()` → process RSS in Kb. The browser sandbox
     *  exposes no whole-process RSS, so this returns the JS heap currently in use
     *  (`performance.memory`, Chromium only) as the closest analogue, or 0 when
     *  the API is unavailable (Firefox/Safari). */
    getProcessMemoryUsage(): number;
    /** Mudlet `getSubsystemMemoryStats()` → a diagnostic table of heap metrics
     *  plus per-subsystem counts. Browser-adapted: heap figures come from
     *  `performance.memory` (Chromium; 0 elsewhere); the Lua GC figure
     *  (`luaMemoryKb`) is added by the Bridge.lua wrapper via
     *  `collectgarbage("count")`. Counts are best-effort snapshots. */
    getSubsystemMemoryStats(): Record<string, number>;
    private patchBorders;
    private applyBorders;
    private normalizeBorder;
    /**
     * Mudlet setFont. Without `win` (or "main"), updates the active profile's
     * outputFont so the App-level applyOutputFont effect re-applies the
     * --font-output CSS variable.
     * With a window name, sets the per-window override on WindowManager.
     * Empty `family` clears the override (main → unset, window → inherit).
     */
    setFont(family: string, win?: string): boolean;
    /**
     * Mudlet getFont. Returns the configured font family for the main window
     * (or empty string if none set) or for a specific window. Returns null if
     * the named window doesn't exist.
     */
    getFont(win?: string): string | null;
    /**
     * Mudlet `calcFontSize(window_or_fontsize [, fontname])` — returns the
     * `[width, height]` of an average character cell in pixels. Two overloads:
     *
     *   • `calcFontSize(size [, family])` — measure `family` (or the main
     *     output font when omitted) at `size` px.
     *   • `calcFontSize("WindowName")` — measure the named window/miniconsole
     *     using its configured font+size. Use `"main"` for the main output.
     *
     * Returns `null` when the size is invalid or the named window doesn't
     * exist; the Lua wrapper turns that into Mudlet's `(nil, errMsg)` shape.
     */
    calcFontSize(arg: number | string, fontName?: string): [number, number] | null;
    /**
     * Mudlet `getAvailableFonts()` — set-style table whose keys are font
     * family names usable from scripts. The browser cannot enumerate the
     * system font list without an explicit Local Font Access permission, so
     * this is a best-effort union of what we *do* know:
     *   - Universal web-safe families that work everywhere.
     *   - Every family the FontFaceSet has materialized (URL- or VFS-loaded
     *     fonts go in here once the browser has registered the @font-face).
     *   - The profile's currently configured output font, if any.
     *   - Locally installed system fonts, but only when the user has already
     *     granted Local Font Access in this browser profile — we never prompt
     *     from inside this getter. A silent prime kicks off here so the next
     *     call sees the result.
     */
    getAvailableFonts(): Record<string, boolean>;
    /** Flush any buffered partial lines to the main output and all open windows. Called after each event dispatch. */
    flushOutput(): void;
    /** @deprecated use echo() */
    print(text: string): void;
    printError(text: string, source?: ScriptLogSource): void;
    destroy(): void;
    private getConsole;
    /**
     * Whether `windowName` is addressable for text/selection ops. True for the
     * main window, any on-screen window, and off-screen buffers (createBuffer) —
     * all of which back a Console. Used by the read/select methods instead of a
     * bare `windows.has`, which is false for buffers (they have no panel).
     */
    private consoleExists;
    /** Returns the Console for a window, creating and registering one on demand. */
    private outputConsole;
    private drainWindowConsole;
    private resolveBuffer;
    private selectionMatches;
    private applyStateToSelection;
    private drainMain;
}
export {};
