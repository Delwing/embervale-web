/**
 * CHARSET (RFC 2066, telnet option 42) negotiation and the session's byte→char
 * codec. The `SessionCodec` owns the streaming inbound decoder and the outgoing
 * encoding; the `CharsetHandler` drives the REQUEST/ACCEPTED/REJECTED exchange
 * against it. Extracted from MudClient so the wire protocol lives alongside the
 * other per-option modules in `src/mud/protocol/`.
 */
/**
 * Map a wire-format charset name (case-insensitive, with various dash/underscore
 * spellings) onto an IANA label that `TextDecoder` accepts. Returns null for
 * encodings we don't support — most legacy MUD codepages aren't reachable from
 * the browser TextDecoder API and would need a polyfill not worth shipping.
 *
 * Coverage is deliberately narrow: UTF-8 (the universal modern answer), the
 * Latin-N family, the Cyrillic KOI8 variants, and the Windows-125x codepages.
 * That covers every Polish, Russian, and Western European MUD seen in practice.
 */
export declare function normalizeCharsetName(raw: string): string | null;
/** Wire-format names of every charset mudix can decode, surfaced to Lua scripts
 *  via `getServerEncodingsList()`. Every entry round-trips through
 *  {@link normalizeCharsetName}, so any name here is a valid `setServerEncoding`
 *  argument. ("ASCII" maps to the UTF-8 decoder, which handles it byte-for-byte.) */
export declare const SUPPORTED_SERVER_ENCODINGS: readonly string[];
/**
 * Parse an `IAC SB CHARSET REQUEST ...` subnegotiation body (leading byte is
 * the option code 42, then subcommand byte 1, then optional `[TTABLE]<ver>`
 * prefix, then a separator byte, then separator-delimited IANA names). Returns
 * the best match against {@link CHARSET_PRIORITY} with both the original wire
 * spelling (echoed back in the ACCEPTED reply per RFC 2066) and the normalized
 * IANA label suitable for `new TextDecoder(...)`. Returns null if no offered
 * name is supported.
 */
export declare function pickCharsetFromRequest(subneg: string): {
    original: string;
    normalized: string;
} | null;
/**
 * The session's byte→char codec. Owns the streaming inbound `TextDecoder`
 * (holding trailing partial multi-byte chars across WebSocket frames) and the
 * matching outgoing encoding. Starts at UTF-8 — correct for ASCII and modern
 * MUDs — and switches when a CHARSET exchange (or an explicit
 * `setServerEncoding`) agrees on something else.
 */
export declare class SessionCodec {
    private decoder;
    private currentEncoding;
    /** The IANA name of the decoder currently applied to the inbound stream. */
    get encoding(): string;
    /** Back to the UTF-8 baseline with a fresh decoder (call on connect). */
    reset(): void;
    /** Swap the streaming decoder to a new encoding label (an IANA name the
     *  TextDecoder constructor accepts: 'utf-8', 'iso-8859-2', ...). Any partial
     *  multi-byte sequence buffered in the previous decoder is discarded —
     *  fine because CHARSET typically negotiates before any real content
     *  arrives. Returns false (leaving the current decoder untouched) when the
     *  browser refuses the label. */
    trySetEncoding(encoding: string): boolean;
    /** Converts a Latin-1 byte-string into decoded text under the current
     *  encoding, buffering any trailing partial multi-byte sequence for the
     *  next frame. */
    decode(byteString: string): string;
    /** Convert a user-typed JS string (UTF-16) into the Latin-1 byte-string the
     *  socket layer expects, using the currently negotiated outgoing encoding.
     *  For UTF-8 we run it through TextEncoder so multi-byte chars survive;
     *  for other encodings we fall back to a per-char `& 0xff` truncation,
     *  which is lossless for ASCII and acceptable for Latin-1-family inputs.
     *  TextEncoder has no API for non-UTF-8 outputs, so a full per-encoding
     *  outbound table isn't worth the bytes given how rare non-UTF-8 MUDs are. */
    encodeOutgoing(text: string): string;
}
export interface CharsetHandlerHooks {
    sendRaw(data: string): void;
    /** Fired when an encoding switch takes effect. The argument is the
     *  wire-spelling name (e.g. "UTF-8") so listeners can surface it. */
    onNegotiated(displayName: string): void;
}
/**
 * Drives the CHARSET REQUEST/ACCEPTED/REJECTED exchange against a
 * {@link SessionCodec}. Negotiation methods are gated on `enabled` (the
 * per-profile CHARSET toggle); `setServerEncoding` is not — it's the explicit
 * Mudlet API call, honored regardless.
 */
export declare class CharsetHandler {
    private readonly codec;
    private readonly enabled;
    private readonly hooks;
    constructor(codec: SessionCodec, enabled: boolean, hooks: CharsetHandlerHooks);
    /** Send `IAC SB CHARSET REQUEST ;UTF-8;ISO-8859-2;ISO-8859-1 IAC SE` —
     *  advertising the encodings we can decode, in preference order. Each name
     *  is prefixed by the separator (`;`) per RFC 2066 (the separator comes
     *  before each charset, not between them). The server replies ACCEPTED
     *  <name> or REJECTED; handleSubneg() processes either. */
    sendRequest(): void;
    /** Route an `IAC SB CHARSET ... IAC SE` subnegotiation body (leading byte
     *  is the option code, 42). Handles REQUEST (server lists charsets, we
     *  ACCEPT one or REJECT), ACCEPTED (server picked one of ours — switch
     *  codec), and REJECTED (server didn't like any of ours — stay put).
     *  TTABLE-* subcommands are silently ignored; almost no MUD uses them. */
    handleSubneg(subneg: string): void;
    /** Mudlet `setServerEncoding(name)`. Switch the inbound decoder to `name`
     *  (any value from getServerEncodingsList()). Returns false — leaving the
     *  current encoding untouched — when the name isn't one we can decode. */
    setServerEncoding(name: string): boolean;
    private setEncoding;
}
