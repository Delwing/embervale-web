import type { DiffResult, SideKind } from '../scripting/vfs/folderSync';
interface MergeConflictModalProps {
    /** Diff between the currently-mounted profile (local/IDB) and the linked folder. */
    diff: DiffResult;
    /** Display name shown in headers, e.g. the folder.name. */
    folderName: string;
    /** Cancel the link operation entirely. */
    onCancel: () => void;
    /**
     * User confirmed. `resolutions` maps each conflicting path to the winning
     * side. The caller copies winners into the folder (folder is the next
     * mount's source of truth). Files in onlyLocal are unioned in automatically.
     */
    onApply: (resolutions: Map<string, SideKind>) => void;
}
export declare function MergeConflictModal({ diff, folderName, onCancel, onApply }: MergeConflictModalProps): import("react/jsx-runtime").JSX.Element;
export {};
