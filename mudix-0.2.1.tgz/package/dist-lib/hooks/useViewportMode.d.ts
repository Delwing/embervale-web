/**
 * Responsive breakpoints (px). Kept in sync with the `--bp-*` tokens and the
 * `@media` blocks in App.css — change them in both places.
 *   mobile  : width ≤ 600            (phones — single-column layout branch)
 *   tablet  : 601 ≤ width ≤ 900      (fluid modals, desktop-ish layout)
 *   desktop : width > 900            (full dock/float UX)
 */
export declare const MOBILE_MAX_WIDTH = 600;
export declare const TABLET_MAX_WIDTH = 900;
export type ViewportMode = 'mobile' | 'tablet' | 'desktop';
/** Current responsive mode, re-rendering the caller when it changes. */
export declare function useViewportMode(): ViewportMode;
/** Convenience: true on phone-sized viewports (the single-column layout branch). */
export declare function useIsMobile(): boolean;
