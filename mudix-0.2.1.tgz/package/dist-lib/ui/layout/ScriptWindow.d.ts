import type { DockSide, DragState } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface ScriptWindowProps {
    id: string;
    title: string;
    kind: 'text' | 'html' | 'map';
    visible: boolean;
    x: number;
    y: number;
    width: number;
    height: number;
    zIndex: number;
    manager: WindowManager;
    /** Miniconsoles render bare: no titlebar, no border, no drag, no resize.
     *  Position and size are script-controlled. */
    isMiniConsole?: boolean;
    /** When true, dragging the titlebar still moves the window but never
     *  enters a dock zone — mirrors Mudlet's openUserWindow(..., autoDock=false). */
    lockFloating?: boolean;
    onFocus: () => void;
    onMoved: (x: number, y: number) => void;
    onResized: (w: number, h: number) => void;
    onDock: (side: DockSide, slotIndex: number, stackTargetId?: string, splitTargetId?: string, splitBefore?: boolean) => void;
    onDragStateChange: (ds: DragState | null) => void;
    onTitlebarContextMenu: (e: React.MouseEvent) => void;
    onHide: () => void;
}
export declare function ScriptWindow({ id, title, visible, x, y, width, height, zIndex, manager, isMiniConsole, lockFloating, onFocus, onMoved, onResized, onDock, onDragStateChange, onTitlebarContextMenu, onHide, }: ScriptWindowProps): import("react/jsx-runtime").JSX.Element;
export {};
