import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
interface Props {
    content: string;
    filename: string;
    path: string;
    vfs: ProfileVFS;
    onDirtyChange?: (dirty: boolean) => void;
    onSaved?: () => void;
    gotoLine?: {
        line: number;
        revision: number;
    } | null;
}
export declare function JsonPreview({ content, filename, path, vfs, onDirtyChange, onSaved, gotoLine }: Props): import("react/jsx-runtime").JSX.Element;
export {};
