import { type MudletProfileBundle } from './mudletProfileImport';
/** The per-connection store slices a bundle maps to. Pure — no side effects, so
 *  it's unit-testable; `importMudletProfile` applies it. Automation is imported
 *  profile-owned (as authored in Mudlet), not package-tagged. */
export declare function bundleToConnectionData(bundle: MudletProfileBundle, installedAt: string): {
    scripts: import("../storage/schema").ScriptNode[];
    aliases: import("../storage/schema").AliasNode[];
    triggers: import("..").TriggerNode[];
    timers: import("../storage/schema").TimerNode[];
    keybindings: import("../storage/schema").KeyNode[];
    buttons: import("../storage/schema").ButtonNode[];
    packages: import("../storage/schema").PackageManifest[];
    profile: Partial<import("../storage").ProfileSettings>;
    variables: {
        saveList: string[];
        values: import("./mudletVariables").MudletVariable[];
    };
};
/**
 * Create a new mudix profile from a Mudlet profile bundle. Returns the new
 * connection id. The profile opens offline like any other; its data is durable
 * in the new VFS (`.mudix/profile.json`) and map store before this resolves.
 */
export declare function importMudletProfile(bundle: MudletProfileBundle): Promise<string>;
/** Recursively read a picked directory into {path -> bytes} + {path -> mtime}
 *  maps for buildMudletProfileBundle. The directory's own name isn't included in
 *  the keys, so a picked profile folder yields `current/…`, `map/…` at the root.
 *  The mtimes let the bundle pick the most-recently-saved XML the way Mudlet does. */
export declare function readDirectoryHandle(root: FileSystemDirectoryHandle): Promise<{
    files: Record<string, Uint8Array>;
    mtimes: Record<string, number>;
}>;
/** Build a bundle from a picked directory handle (mtime-aware newest-save pick). */
export declare function bundleFromDirectory(dir: FileSystemDirectoryHandle): Promise<MudletProfileBundle>;
/** Import a Mudlet profile from a picked directory handle (no unresolved-module
 *  handling — callers that need the upload/remove flow should use bundleFromDirectory
 *  + resolveModulesFromTree first). */
export declare function importMudletProfileFromDirectory(dir: FileSystemDirectoryHandle): Promise<string>;
/**
 * Link a Mudlet profile *directory* as a new mudix profile (Link mode): the
 * folder stays the source of truth — its `current/*.xml` is re-read on every
 * open — rather than being copied in. Reads the connection identity from the
 * newest save, registers the connection, persists the folder handle so the VFS
 * mounts it, and copies the current map. Returns the new connection id.
 */
export declare function linkMudletFolder(dir: FileSystemDirectoryHandle): Promise<string>;
