/**
 * Keyboard navigation and activation for output hyperlinks — OSC 8, MXP, and
 * scripted links alike (Mudlet's Ctrl+] / Ctrl+[ plus Enter/Space activation).
 *
 * Ctrl+] focuses the next clickable link in the output, Ctrl+[ the previous,
 * wrapping at the ends. With nothing focused, Ctrl+] starts at the first link
 * and Ctrl+[ at the last. Links are made focusable (`tabIndex = -1`) by the
 * renderer, so they take focus programmatically without joining the Tab order.
 *
 * With a link focused: Enter/Space activates it (same as a left-click — fires
 * the send/prompt/url action, reveals a spoiler, toggles selection, arms
 * visibility); the Menu key or Shift+F10 opens its context menu. Mirrors
 * Mudlet's TTextEdit key handling.
 */
/**
 * One representative element per logical link under `root`, in document order.
 * A multicolour link is rendered as several spans (one per colour run) sharing
 * a `data-link-group` key — only the first run of each group is a navigation
 * stop, so Ctrl+]/Ctrl+[ moves link-to-link, not run-to-run. Concealed (hidden)
 * links are skipped.
 */
export declare function navigableLinks(root: ParentNode): HTMLElement[];
/** Move focus to the link `dir` steps from the currently-focused one (wrapping).
 *  Returns the newly-focused link, or null when there are no links. */
export declare function focusAdjacentLink(root: ParentNode, dir: 1 | -1): HTMLElement | null;
/** Handle a keydown for link navigation/activation. Returns true when it acted. */
export declare function handleLinkNavKeydown(e: KeyboardEvent, root: ParentNode): boolean;
/** Install the link navigation/activation key listener for `root`. Returns a remover. */
export declare function installLinkNavigation(root: ParentNode): () => void;
