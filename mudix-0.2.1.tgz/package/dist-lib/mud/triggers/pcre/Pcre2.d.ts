export type Pcre2MatchGroup = {
    start: number;
    end: number;
    match: string;
    name?: string;
    group?: number;
};
export type Pcre2Match = {
    length: number;
    [k: number]: Pcre2MatchGroup;
    [k: string]: Pcre2MatchGroup | number;
};
/** Drop the cached line so the next match re-encodes. Used after teardown or
 *  when callers want to be sure a stale buffer can't be reused. */
export declare function resetLineBuffer(): void;
export default class Pcre2 {
    private codePtr;
    private matchData;
    private readonly nametable;
    static init(): Promise<void>;
    constructor(pattern: string, flags?: string);
    destroy(): void;
    match(subject: string, start?: number): Pcre2Match | null;
    matchAll(subject: string): Pcre2Match[];
    private getLastError;
}
