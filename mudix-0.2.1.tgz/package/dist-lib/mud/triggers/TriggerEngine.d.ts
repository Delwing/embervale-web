import type { TriggerNode } from '../../storage/schema';
export type { TriggerNode };
type Capture = string | undefined;
type TempFn = (matches: Capture[], spans?: {
    captureSpans: CaptureSpan[];
    namedSpans?: Record<string, CaptureSpan>;
    matchSpan?: CaptureSpan;
}, namedGroups?: Record<string, string>) => void;
/**
 * Result of matching a trigger pattern against a line.
 *
 * `captureSpans` and `namedSpans` describe where each capture sits in the
 * source line — needed by `selectCaptureGroup` so it can re-select the
 * actual occurrence rather than picking the first textual match. Spans line
 * up positionally with `captures` (so `captureSpans[0]` is the position of
 * `captures[0]`, i.e. capture group 1). Both are optional because non-PCRE
 * matchers (substring/exactMatch/etc.) don't produce capture-group spans.
 */
type CaptureSpan = {
    start: number;
    length: number;
};
/**
 * What `matchPerm`/`processAndTrigger` hand back to the engine. Adds the
 * trigger node and the AND-trigger-only `multimatches` array on top of the
 * raw `MatchResult`.
 */
export type TriggerMatch = {
    trigger: TriggerNode;
    captures: Capture[];
    matchedText: string;
    multimatches?: Capture[][];
    namedGroups?: Record<string, string>;
    captureSpans?: CaptureSpan[];
    namedSpans?: Record<string, CaptureSpan>;
    matchStart?: number;
};
export declare class TriggerEngine {
    private readonly temp;
    private nextId;
    private inProcessTemp;
    private permCompiled;
    private allById;
    private regCounter;
    private permReg;
    private unified;
    private orderDirty;
    private cache;
    private lineCounter;
    private readonly chainOpenUntil;
    private hasChildren;
    private andStates;
    private filterActiveText;
    private filterActiveOffset;
    /** Resolves once PCRE wasm is initialized and patterns can be compiled. */
    static ready(): Promise<void>;
    /** Number of live session-scoped temp triggers (Mudlet `getProfileStats` temp count). */
    get tempCount(): number;
    /**
     * Register a temp trigger. `kind` selects the match strategy:
     *   - `'regex'`     — PCRE, same syntax as permanent triggers (Mudlet
     *                     `tempRegexTrigger`). The callback receives
     *                     `[fullMatch, capture1, capture2, ...]`; unmatched
     *                     optional groups surface as empty strings.
     *   - `'substring'` — literal `String.prototype.includes` (Mudlet
     *                     `tempTrigger`). The callback receives `[pattern]`
     *                     so capture-group access against the substring is a
     *                     no-op rather than a metacharacter trap.
     *   - `'startOfLine'`— literal `String.prototype.startsWith` (Mudlet
     *                     `tempBeginOfLineTrigger`). Not anchored regex —
     *                     just a prefix check, which is why it's cheap.
     *                     Callback receives `[pattern]`.
     *   - `'exactMatch'`— full-line equality (Mudlet
     *                     `tempExactMatchTrigger`). Callback receives `[line]`.
     *   - `'prompt'`    — fires on every line the server flags as a prompt
     *                     (Mudlet `tempPromptTrigger`); `pattern` is ignored.
     *                     Callback receives `[line]`.
     * Invalid regex patterns return a no-op disposer so callers don't need
     * to special-case compile failures.
     */
    addTemp(pattern: string, fn: TempFn, kind?: 'regex' | 'substring' | 'startOfLine' | 'exactMatch' | 'prompt'): () => void;
    /**
     * Mudlet `tempLineTrigger(from, howMany, fn)`. A position-based trigger with
     * no pattern: it fires `fn([lineText])` on `howMany` consecutive lines,
     * starting `from` lines ahead (`from = 1` → the next line). It self-expires
     * after the last fire. When created from within a handler, the line on which
     * it was created is skipped (see `inProcessTemp`/`skipFirst`) so `from`
     * counts from the next line in every creation context. Returns a disposer
     * for early cancellation.
     */
    addTempLine(from: number, howMany: number, fn: TempFn): () => void;
    loadPerm(items: TriggerNode[]): void;
    /** Fresh compile for an item not present in the cache. Returns a CachedEntry
     * with `compiled: null` when no patterns produced a usable matcher — that
     * negative result is cached so we don't retry on every loadPerm. */
    private compileItem;
    processTemp(line: string, isPrompt?: boolean): void;
    /** Match + fire a single temp trigger against `line`. Self-expiring `line`
     *  triggers delete themselves (and dirty the unified order) when spent. */
    private fireTempEntry;
    matchPerm(line: string, isPrompt?: boolean): TriggerMatch[];
    /**
     * Match one permanent compiled entry against `line`, appending any matches
     * to `out`. Updates chain/AND/filter state exactly as the old inline loop
     * did. `seen` dedupes a single OR/group item within one line pass; it is
     * shared across all entries processed for that line.
     */
    private matchPermEntry;
    /**
     * Mudlet-faithful single pass: walk the one ordered list of permanent and
     * temporary triggers (see the ordering notes on the fields) and, for each
     * node in turn, match + act on it before moving to the next. Permanent
     * matches are handed to `exec` inline (the caller runs the trigger's
     * command/code); temporary triggers fire their own callback. Because a
     * runtime temp sorts after the permanent triggers that existed when it was
     * created, a permanent trigger on a line runs before a temp that also
     * matches it — which is exactly the order Mudlet produces.
     *
     * The processing list is snapshotted up front (like Mudlet's
     * `copyOfNodeList`), so triggers created mid-pass don't fire on the current
     * line, and `inProcessTemp` is saved/restored to stay correct under the
     * re-entrancy a handler can cause via `feedTriggers`.
     */
    process(line: string, isPrompt: boolean, exec: (match: TriggerMatch) => void): void;
    /** Rebuild the merged, path-sorted processing list from the current
     *  permanent entries and temporary triggers. Called lazily from process()
     *  when either source changed. */
    private rebuildOrder;
    /** The registration-seq path from the root ancestor down to `item`. */
    private permPath;
    setLuaEval(fn: ((code: string, line: string) => boolean) | null): void;
    /**
     * Wire the buffer-aware colour check used by `colorTrigger` patterns. The
     * matcher receives the parsed `(fg, bg)` indices and asks the registered
     * callback whether the line just appended to the main console carries any
     * segment with those colours. ScriptingEngine sets this to delegate to
     * `ScriptingAPI.currentLineMatchesColor`. Passing `null` disables every
     * colour trigger (e.g. during runtime teardown).
     */
    setColorMatcher(fn: ((fg: number, bg: number) => boolean) | null): void;
    destroy(): void;
    private processAndTrigger;
    /**
     * Record a chain-head match: open the chain for `fireLength` more lines and,
     * if the trigger is also a filter, stash the captured/matched text so
     * descendants see it as their effective input.
     */
    private openChain;
    /**
     * Mudlet `setTriggerStayOpen(name, lines)`: keep the named chain head(s)
     * open for `lines` more lines of input, starting from the line currently
     * being processed. This is transient runtime state — it mutates only the
     * `chainOpenUntil` window, never the persisted `fireLength` on the node, so
     * the trigger's stored definition is untouched and the override expires
     * naturally as input scrolls past.
     *
     * `matchPerm` post-increments `lineCounter`, so during a trigger's script
     * the line just matched is `lineCounter - 1`; the window math then mirrors
     * `openChain` exactly. Negative counts clamp to 0 (open for the current
     * line only). `ids` are resolved by name by the caller.
     */
    setStayOpen(ids: string[], lines: number): void;
    /**
     * Returns the effective line to match against for `item`.
     * If a filter-trigger ancestor has active filter text, that text is used instead.
     * Innermost filter wins.
     */
    private getEffectiveLine;
    /** The offset within the ORIGINAL line at which `item`'s effective (filtered)
     *  input begins — 0 unless it sits under a filter ancestor. Mirrors
     *  getEffectiveLine: the innermost filter ancestor's recorded offset. */
    private getEffectiveOffset;
    /** Return a copy of `r` with every span (matchStart, captureSpans, namedSpans)
     *  shifted by `offset` — used to re-base a filtered descendant's spans onto
     *  the original line so selectCaptureGroup/selectString hit the right column.
     *  Zero-length (unmatched-group) placeholders keep length 0. */
    private shiftResultSpans;
    /**
     * A trigger is chain-accessible if every patterned ancestor has an open
     * chain (matched within the last fireLength lines, inclusive of the current
     * line). Pattern-less ancestors (pure folders) always grant access. This
     * applies regardless of whether the ancestor is a folder or a leaf with its
     * own script — Mudlet treats any patterned trigger with children as a chain
     * head.
     */
    private isChainAccessible;
    private computeDepth;
}
