export declare const LUA_TBOOLEAN = 1;
export declare const LUA_TNUMBER = 3;
export declare const LUA_TSTRING = 4;
export declare const LUA_TTABLE = 5;
/** How a variable's key is typed in its parent table. Lua only distinguishes
 *  string vs number keys here (Mudlet never saves other key types). */
export type VarKeyKind = 'string' | 'number';
/** Scalar value types we round-trip. Tables are represented by `children`. */
export type VarValueType = 'boolean' | 'number' | 'string' | 'table';
/**
 * One saved variable (or table entry). `name` is the key as written in <name>
 * — for a numeric key it's the number stringified ("7"). `value` is Mudlet's
 * string form of the scalar ("true"/"42"/"3.5"/raw string); it is '' and unused
 * for tables, whose entries live in `children`.
 */
export interface MudletVariable {
    name: string;
    keyKind: VarKeyKind;
    valueType: VarValueType;
    value: string;
    children?: MudletVariable[];
}
export interface MudletVariablePackage {
    /** <HiddenVariables> names. Round-tripped verbatim; the populated inner
     *  format is unverified (only ever observed empty) so we preserve whatever
     *  <name> entries are present without interpreting them. */
    hidden: string[];
    variables: MudletVariable[];
}
/** Parse a `<VariablePackage>` element. */
export declare function parseVariablePackage(pkg: Element): MudletVariablePackage;
/** Parse the first `<VariablePackage>` out of a full Mudlet profile XML string.
 *  Returns an empty package when there is none. */
export declare function parseVariablePackageXml(xml: string): MudletVariablePackage;
/**
 * Coerce a loosely-typed variable tree (e.g. the result of `JSON.parse` on a
 * `yajl.to_string` capture from the Lua side) into well-formed `MudletVariable`s.
 * Notably, yajl can't tell an empty Lua table from an empty array, so an empty
 * `children`/root arrives as `{}` rather than `[]`; this normalises those back to
 * arrays and drops anything that isn't a recognisable node.
 */
export declare function normalizeVariableTree(raw: unknown): MudletVariable[];
/**
 * Serialize a `<VariablePackage>` to Mudlet's exact textual format (tab indent).
 * `indent` is the leading indent of the `<VariablePackage>` line itself (one tab
 * inside `<MudletPackage>` in a real profile). Top-level variables and table
 * children are emitted name-sorted to match Mudlet and keep output stable.
 */
export declare function serializeVariablePackage(pkg: MudletVariablePackage, indent?: string): string;
