import type { MudSession } from '../../mud/MudSession';
import type { ProfileVFS } from '../../scripting/vfs/ProfileVFS';
import type { ScriptingEngine } from '../../scripting/ScriptingEngine';
interface Props {
    connectionId: string;
    session: MudSession;
    vfs: ProfileVFS | null;
    scriptingEngineRef?: React.RefObject<ScriptingEngine | null>;
    onClose: () => void;
    onOpenVfsFile?: (path: string, line?: number) => void;
}
export declare function ScriptEditorModal({ connectionId, session, vfs, scriptingEngineRef, onClose, onOpenVfsFile }: Props): import("react/jsx-runtime").JSX.Element;
export {};
