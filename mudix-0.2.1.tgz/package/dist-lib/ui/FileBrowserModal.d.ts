import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
interface FileBrowserModalProps {
    connectionId: string;
    vfs: ProfileVFS | null;
    onClose: () => void;
    initialPath?: string | null;
    initialPathTick?: number;
    initialLine?: number;
}
export declare function FileBrowserModal({ connectionId, vfs, onClose, initialPath, initialPathTick, initialLine }: FileBrowserModalProps): import("react/jsx-runtime").JSX.Element;
export {};
