import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
interface SettingsModalProps {
    onClose: () => void;
    /** Active profile id; null on the connection screen (only theme is editable). */
    connectionId: string | null;
    vfs?: ProfileVFS | null;
}
export declare function SettingsModal({ onClose, connectionId, vfs }: SettingsModalProps): import("react/jsx-runtime").JSX.Element;
export {};
