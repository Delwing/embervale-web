import type React from 'react';
import type { MudSession } from '../../mud/MudSession';
/**
 * Caret mode / reading cursor (Mudlet's caret mode, web-native).
 *
 * When the user's configured `caretShortcut` is pressed, a focusable review
 * panel mirrors the main output's rendered lines (text + working links) and
 * takes focus, so a screen reader can navigate the scrollback by char/word/line
 * with its own virtual cursor — and reach links — without the live output's
 * additions-only ARIA region getting in the way. Escape, the close button, or
 * the toggle key again exits and returns focus to the command line.
 *
 * The mirror is kept live by a MutationObserver on the main output: appends and
 * evictions are reflected as they happen, so the panel never goes stale while
 * open. We clone the already-rendered DOM (rather than re-deriving from the
 * Console model) because the DOM is the faithful "what's on screen" source —
 * blank lines and inline command echoes included.
 */
export declare function CaretReviewPanel({ session, commandInputRef, }: {
    session: MudSession;
    commandInputRef?: React.RefObject<HTMLInputElement | HTMLTextAreaElement | null>;
}): import("react/jsx-runtime").JSX.Element | null;
