/**
 * OSC 8 hyperlink `visibility` (Mudlet's THyperlinkVisibilityManager).
 *
 * Timer- and click-driven actions are wired directly onto the rendered link
 * element by {@link applyVisibility}:
 *   - **reveal**            — start hidden, reveal after `delayMs` (from render).
 *   - **conceal**           — start visible, conceal on click (now, or after
 *                             `delayMs`); with expire flags, arm instead.
 *   - **reveal-then-conceal** — reveal after `delayMs`, then conceal on click.
 *   - **deletesEntireLine** — conceal removes the whole output line.
 *
 * Expire-on-event links (conceal on the next user input / prompt / output after
 * being clicked) can't be driven from the element alone — they're tagged with
 * `data-osc-vis-*` attributes here, and {@link HyperlinkVisibilityController}
 * (owned by the session) conceals them when the matching session event fires.
 * The first occurrence of each trigger is skipped: it's the response to the very
 * command the click sent, not a fresh event.
 */
import type { VisibilitySettings } from "./hyperlinkConfig";
/** Wire one link element's visibility behaviour. Call *after* the element's base
 *  style has been applied (it may set `visibility: hidden`, which a later
 *  `cssText` assignment would wipe). */
export declare function applyVisibility(el: HTMLElement, vis: VisibilitySettings): void;
/**
 * Session-scoped driver for expire-on-event visibility links. The session calls
 * `onInput`/`onPrompt`/`onOutput` as those events occur; each conceals every
 * armed link whose trigger set includes that event (after skipping the first
 * occurrence). `getRoot` supplies the DOM subtree to scan (the live output).
 */
export declare class HyperlinkVisibilityController {
    private readonly getRoot;
    constructor(getRoot: () => ParentNode | null);
    onInput(): void;
    onPrompt(): void;
    onOutput(): void;
    private fire;
}
