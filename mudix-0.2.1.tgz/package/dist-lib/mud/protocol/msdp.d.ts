/**
 * Frame a Mudlet-style `sendMSDP(variable, ...values)` call as an MSDP
 * subnegotiation: `IAC SB MSDP MSDP_VAR <variable> [MSDP_VAL <value>]... IAC SE`.
 * The returned string is a Latin-1 byte-string ready for sendBytes.
 */
export declare function encodeMsdp(variable: string, values: string[]): string;
export interface MsdpEnvelope {
    /** Top-level MSDP variable name (e.g. "HEALTH", "ROOM"). */
    path: string;
    /** Decoded value: a string, an array, or a nested string-keyed object. */
    value: unknown;
}
export interface MsdpStreamOptions {
    onEnvelope: (payload: MsdpEnvelope) => void;
}
/** Mirror of createGmcpStream for MSDP subnegotiations. The handler receives a
 *  subnegotiation body whose first byte is the MSDP option code (69); each
 *  top-level variable is emitted as its own envelope. */
export declare const createMsdpStream: ({ onEnvelope }: MsdpStreamOptions) => (data: string) => void;
