import type { IScriptingRuntime, CaptureSpan, LuaGlobalEntry } from '../IScriptingRuntime';
import type { ScriptingAPI } from '../ScriptingAPI';
import type { ProfileVFS } from '../vfs/ProfileVFS';
import { type MudletVariable } from '../../import/mudletVariables';
export declare class LuaRuntime implements IScriptingRuntime {
    private readonly lua;
    private readonly api;
    private vfs;
    private readonly proxyUrlGetter;
    private readonly tempIds;
    private nextTempId;
    private readonly labelCbIds;
    private cmdLineActionCbId;
    private windowCmdLineActionCbIds;
    private overlayCmdLineActionCbIds;
    private currentMatches;
    private currentCaptureSpans;
    private currentNamedSpans;
    private currentFullMatchSpan;
    private _denyCurrentSend;
    private destroyed;
    private readonly watchedPaths;
    private readonly rawFnPtrs;
    private http;
    private tts;
    private globalEvents;
    private flushPendingSqlSnapshots;
    private toLuaValue;
    private constructor();
    static create(api: ScriptingAPI, vfs?: ProfileVFS | null, proxyUrlGetter?: () => string | undefined): Promise<LuaRuntime>;
    private setup;
    private setupAnsiColorTable;
    /**
     * True when a script-created (temp) alias/trigger with this id is live and of
     * the given type. Backs exists(id, "alias"/"trigger") for temp items, which
     * don't live in the persisted store the way permanent items do.
     */
    tempItemExists(id: number, type: string): boolean;
    private setupBustedBridge;
    private setupSqlBridge;
    /**
     * Fire sysPathChanged for any addFileWatch subscription whose path equals
     * `changedPath` or is an ancestor directory of it. Mudlet's QFileSystemWatcher
     * reports the *watched* path (not the inner file) for directory watches, so
     * we do the same — handlers comparing `path == watchedPath` round-trip.
     */
    private notifyVfsPathChange;
    private setupVFS;
    load(code: string, name: string): void;
    run(code: string, name: string): void;
    /**
     * Restore saved Lua globals (a parsed Mudlet `<VariablePackage>` tree) into
     * `_G`. Call on profile load, after the bundle is up but before user scripts
     * run, so handlers see their persisted state. No-op for an empty list.
     */
    restoreVariables(vars: MudletVariable[]): void;
    /**
     * Snapshot the current values of the save-listed globals out of `_G` into a
     * `MudletVariable[]` tree (for serialization to `<VariablePackage>` / the
     * profile JSON). `saveList` is the set of top-level global names flagged to
     * persist (Mudlet's VarUnit::mSaveList). Names that are unset or hold a
     * non-serializable value (function/userdata/thread) are skipped.
     */
    captureVariables(saveList: string[]): MudletVariable[];
    /** Enumerate `_G` (user globals as a nested tree, built-ins flagged) for the
     *  Variables view. See {@link LuaGlobalEntry}. */
    listGlobals(): LuaGlobalEntry[];
    runWithMatches(code: string, name: string, matches: (string | undefined)[], multimatches?: (string | undefined)[][], namedGroups?: Record<string, string>, captureSpans?: CaptureSpan[], namedSpans?: Record<string, CaptureSpan>, fullMatchSpan?: CaptureSpan): void;
    private setMatches;
    /** Push a 1-indexed Lua table of capture strings (`matches[1]` = whole match),
     *  optionally merging named captures as string keys (`matches.hp`). Same shape
     *  the old `oneIndexed()` + `global.set` produced, via raw stack ops. An
     *  unmatched optional group (`undefined`) is left unset → nil, as before. */
    private pushMatchesTable;
    private exec;
    private execInner;
    private runChunk;
    private dispatchCb;
    private dispatchCbWithArg;
    private unregisterCb;
    private execModule;
    emitEvent(event: string, args: unknown[]): void;
    setGmcpValue(path: string, value: unknown): void;
    setMsdpValue(path: string, value: unknown): void;
    setMsspValue(name: string, value: string): void;
    /**
     * Mudlet-style async unzip. Reads the zip from the profile VFS, decodes
     * it on a worker (fflate falls back to a chunked main-thread decode where
     * workers aren't available), writes every entry under destDir, then
     * raises sysUnzipDone / sysUnzipError. Always fire-and-forget.
     */
    private runUnzipAsync;
    setCurrentLine(line: string, _isPrompt: boolean): void;
    setCommand(command: string): void;
    dispatchSendRequest(text: string): boolean;
    killScriptHandlers(scriptId: string): void;
    /**
     * Mudlet REGEX_LUA_CODE: the pattern body runs as a Lua function on every
     * incoming line. Side effects (raiseEvent, etc.) always run; the trigger
     * "matches" only when the body returns a truthy value.
     */
    evalTriggerPattern(code: string): boolean;
    /**
     * Invoke a `registerMapInfo` contributor. The Lua dispatcher pcalls the
     * stashed callback and writes its multi-return into scalar globals
     * (`__mudix_mapinfo_text` / _bold / _italic / _r / _g / _b). Returning
     * `null` covers three cases: runtime is being torn down, callback id is
     * stale, or the callback returned a nil/empty text — the panel treats
     * all three the same (skip the entry).
     */
    private evaluateMapInfo;
    /**
     * Push a JS value onto `L`'s stack via the raw lua_* C API, mirroring
     * wasmoon's pushValue conventions EXACTLY so behaviour is byte-identical to
     * the generic path — only the O(n²) ref/unref bookkeeping wasmoon's
     * pushTable does (see issue #2) is gone:
     *   - integer-valued numbers → lua_pushinteger, others → lua_pushnumber
     *   - arrays keyed by Object.keys + lua_rawseti, so dense 0-based arrays
     *     (map getters) stay 0-indexed and the sparse 1-based arrays toLuaValue
     *     builds stay 1-indexed — identical to wasmoon's arrIndexs handling
     *   - plain objects → string keys via lua_setfield
     * Anything that isn't a primitive / plain array / plain object (wasmoon
     * LuaTable proxies such as the yajl.null sentinel, functions, Maps, class
     * instances) is delegated to wasmoon's own pushValue, which is O(1) for
     * these leaves and preserves their reference identity. Such values only
     * appear as leaves of GMCP/MSDP payloads (toLuaValue rebuilds every
     * container as a fresh plain array/object) and always push on the main
     * thread; on a coroutine stack we can't safely delegate, so degrade to nil.
     */
    private pushJsValue;
    /**
     * Register `name` as a raw lua_CFunction (bypassing wasmoon's generic
     * pushValue marshalling for the return value). `fn` receives the lua_State
     * pointer, reads its args via the raw lua_* API, pushes its results with
     * pushJsValue(), and returns the result count. A throw across the WASM
     * trampoline would corrupt the C stack, so it is contained and the getter
     * degrades to a single nil (these are read-only queries — a nil miss is a
     * safe fallback).
     */
    private registerRawGlobal;
    destroy(): void;
}
