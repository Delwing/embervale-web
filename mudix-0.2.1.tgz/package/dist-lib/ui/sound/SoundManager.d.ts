import type { MediaCaptionInfo } from './closedCaption';
type LoaderFn = (path: string) => Promise<ArrayBuffer | null>;
/** Which mute gate a playback belongs to. `api` = triggered by a Lua script
 *  (playSoundFile / playMusicFile); `game` = triggered by the server (MSP, and
 *  GMCP media). Mirrors Mudlet's muteMediaAPI / muteMediaGame split, where API
 *  media maps to MediaProtocolAPI and game media to MSP/GMCP. */
export type MediaOrigin = 'api' | 'game';
export interface PlaySoundOptions {
    name: string;
    /** 0..100 — Mudlet scale. Default 50. */
    volume?: number;
    /** Fade-in duration in milliseconds. */
    fadein?: number;
    /** Fade-out duration in milliseconds (on natural end or stop). */
    fadeout?: number;
    /** Start offset within the buffer, in milliseconds. */
    start?: number;
    /** Loop count. 1 = play once (default). -1 = infinite. N>1 = N total plays. */
    loops?: number;
    /** Dedupe key — calling again with same key replaces the previous one. */
    key?: string;
    /** Group tag — stopMusic({tag=...}) and stopSounds() filter on this. */
    tag?: string;
    /** Which mute gate governs this playback. Default 'api'. */
    origin?: MediaOrigin;
    /** Optional closed-caption text (Mudlet's media `caption`). Shown verbatim
     *  when closed captions are on; absent → a caption is synthesized from the
     *  kind + filename. */
    caption?: string;
}
export interface PlayMusicOptions extends PlaySoundOptions {
    /** If true and a music track with the same name+key is already playing, do nothing. */
    continue?: boolean;
}
export interface StopMusicOptions {
    name?: string;
    key?: string;
    tag?: string;
    /** Fade-out duration in milliseconds. Overrides the source's own fadeout. */
    fadeout?: number;
}
export declare class SoundManager {
    private nextId;
    private active;
    private loader;
    /** 0..1, applied as an extra multiplier on every source's gain. */
    private masterVolume;
    /**
     * Persistent per-origin mute gates — Mudlet's muteMediaAPI / muteMediaGame.
     * A muted origin's sources keep playing (their position advances) but their
     * gain is pinned to 0, and new sources of that origin start silent; nothing
     * is stopped, so unmuting restores audibility mid-track. This mirrors Mudlet
     * toggling QAudioOutput::setMuted on the live players by protocol rather than
     * tearing them down.
     */
    private muted;
    /**
     * Raised when a tracked source ends — whether it played out naturally or
     * was stopped. ScriptingEngine wires this to raise Mudlet's
     * `sysMediaFinished(name, path)`. `stopAll()` nulls each source's onended
     * before stopping, so engine teardown never fires it.
     */
    onMediaFinished?: (name: string, path: string) => void;
    /**
     * Raised when a tracked source starts ('plays') or ends ('stops'), so the
     * engine can print a closed caption (Mudlet's enableClosedCaption). Fires
     * regardless of the caption setting — the consumer decides whether to show
     * it. Not fired by `stopAll()` (teardown nulls each onended first).
     */
    onMediaCaption?: (info: MediaCaptionInfo) => void;
    setLoader(fn: LoaderFn | null): void;
    setMasterVolume(value: number): void;
    /**
     * Mudlet `muteMediaAPI` / `muteMediaGame`. Sets the persistent mute gate for
     * a playback origin. While muted, that origin's currently-playing sources are
     * silenced in place (gain → 0, position keeps advancing) and any new ones
     * start silent — but nothing is stopped, so unmuting restores audibility
     * mid-track. `api` gates script playback (playSoundFile/playMusicFile);
     * `game` gates server-driven media (MSP / GMCP).
     */
    setOriginMuted(origin: MediaOrigin, muted: boolean): void;
    isOriginMuted(origin: MediaOrigin): boolean;
    /** Output gain for a source: its own volume scaled by the master volume,
     *  pinned to 0 while its origin is muted. */
    private effectiveGain;
    playSound(opts: PlaySoundOptions): Promise<number>;
    playMusic(opts: PlayMusicOptions): Promise<number>;
    stopSounds(): void;
    /**
     * Mudlet `pauseSounds([channel])`. Web Audio source nodes can be
     * scheduled to start but not paused once playing — they're transient by
     * design, with no equivalent of QMediaPlayer::pause(). We approximate
     * Mudlet's contract by stopping the matching sources outright (so the
     * mute happens immediately) and let the player retrigger them with
     * `playSoundFile` to resume. The optional `channel` filters by the
     * source's `tag` (matches Mudlet's "channel" semantics: a Tag string
     * passed to playSoundFile). Music sources are untouched — they have a
     * separate `stopMusic` codepath.
     */
    pauseSounds(channel?: string): void;
    /**
     * Mudlet `pauseMusic([settings])`. Web Audio source nodes can't truly
     * pause once started (same constraint as {@link pauseSounds}), so this is
     * an immediate fade-out + stop of the matching music sources — re-trigger
     * `playMusicFile` to "resume". The optional `channel`/tag filters which
     * music tracks are affected; sound effects are untouched.
     */
    pauseMusic(channel?: string): void;
    stopMusic(opts?: StopMusicOptions): void;
    /**
     * Mudlet getPlayingSounds / getPlayingMusic. Returns the currently-playing
     * sources of the requested `kind` (default 'sound' — music is reported
     * separately by getPlayingMusic) optionally filtered by name/key/tag.
     * Volume is reported on Mudlet's 0..100 scale.
     */
    getPlaying(filter?: {
        name?: string;
        key?: string;
        tag?: string;
    }, kind?: 'sound' | 'music'): Array<{
        name: string;
        key?: string;
        tag?: string;
        volume: number;
    }>;
    /**
     * Mudlet loadSoundFile. Preloads (decodes + caches) a sound so the first
     * playSoundFile has no decode latency. Fire-and-forget: warms `decodeCache`
     * via the same path playSound uses, so a later play of the same name hits
     * the cache. Returns false when no AudioContext is available yet.
     */
    preload(name: string): boolean;
    /**
     * Mudlet `purgeMediaCache()` — drop every decoded-audio buffer so the next
     * play of any file re-fetches and re-decodes it. Active playback is
     * untouched (the cache only fronts the decode step). Always returns true.
     */
    purgeCache(): boolean;
    /** Stop everything this manager owns. Call on engine teardown. */
    stopAll(): void;
    destroy(): void;
    private play;
    private fadeAndStop;
    private isMusicPlaying;
    private stopMusicMatching;
    private updateMediaSessionState;
    private firstActiveMusicName;
}
export {};
