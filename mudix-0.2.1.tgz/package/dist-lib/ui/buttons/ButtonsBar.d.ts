import { type RefObject } from 'react';
import type { ScriptingEngine } from '../../scripting/ScriptingEngine';
import type { ProfileVFS } from '../../scripting/vfs/ProfileVFS';
import './ButtonsBar.css';
interface ButtonsLayerProps {
    connectionId: string;
    engineRef: RefObject<ScriptingEngine | null>;
    vfs: ProfileVFS | null;
}
/**
 * Returns the four edge strips of toolbars (top/bottom/left/right). The caller
 * places each strip in the appropriate spot inside ContentLayout.
 */
export declare function useButtonStrips({ connectionId, engineRef, vfs }: ButtonsLayerProps): {
    top: import("react/jsx-runtime").JSX.Element;
    bottom: import("react/jsx-runtime").JSX.Element;
    left: import("react/jsx-runtime").JSX.Element;
    right: import("react/jsx-runtime").JSX.Element;
    floating: import("react/jsx-runtime").JSX.Element;
};
export {};
