import type { FormatColor, FormatStateSnapshot } from './FormatState';
/** Resolve an MXP color spec — an HTML named color, `#RGB`, `#RRGGBB`, or
 *  `rgb(r,g,b)` — into a {@link FormatColor}, or null when unrecognized.
 *  Used by the MXP parser for `<COLOR>`/`<FONT>` foreground and background. */
export declare function mxpColor(spec: string): FormatColor | null;
export declare function namedColorToAnsi(name: string, bg?: boolean): string;
/** Converts a named Mudlet color to a FormatStateSnapshot for buffer-level coloring. */
export declare function namedColorToState(name: string, bg?: boolean): FormatStateSnapshot | null;
/** cecho: <color_name>text<r>  or  <b:color_name>text for background */
export declare function parseCecho(text: string): string;
/** decho: <r,g,b>text  or  <:r,g,b>text for background, <r> to reset */
export declare function parseDecho(text: string): string;
/** hecho: #RRGGBBtext  or  #:RRGGBBtext for background, #r to reset */
export declare function parseHecho(text: string): string;
