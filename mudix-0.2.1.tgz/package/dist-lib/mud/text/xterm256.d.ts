declare const xterm256: string[];
export default xterm256;
