export interface ScrollBoxCreateOptions {
    /** Parent window id ('main' for the main viewport, or a userwindow / another
     *  scroll box name for nesting). */
    parent?: string;
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface ScrollBoxState {
    name: string;
    parent: string;
    x: number;
    y: number;
    width: number;
    height: number;
    visible: boolean;
    /** Raw Qt-style CSS string from a future setScrollBoxStyleSheet — stored for
     *  parity; Geyser.ScrollBox:setStyleSheet is itself unimplemented upstream. */
    styleSheet?: string;
    /** z-index — bumped by raiseWindow / lowerWindow. */
    zIndex?: number;
}
type Listener = (scrollBoxes: ScrollBoxState[]) => void;
/**
 * Registry for overlay scroll-box widgets (Mudlet createScrollBox). A scroll box
 * is an absolutely-positioned, scrollable container on top of a parent viewport
 * that other overlay widgets (labels, command lines, nested scroll boxes) can be
 * created *inside* by passing the box's name as their parent — mirroring
 * Mudlet's Geyser.ScrollBox, which treats the box as its own "window".
 *
 * Shares the per-parent subscriber shape of {@link CommandLineManager} /
 * {@link LabelManager}; the React {@link ScrollBoxOverlay} renders each box and
 * mounts the child overlays scoped to the box's name within its scroll area.
 */
export declare class ScrollBoxManager {
    private readonly boxes;
    private readonly listeners;
    private nextRaiseZ;
    private nextLowerZ;
    /** Mudlet createScrollBox([parent,] name, x, y, w, h) — false when a scroll
     *  box with that name already exists. */
    create(name: string, opts: ScrollBoxCreateOptions): boolean;
    has(name: string): boolean;
    get(name: string): ScrollBoxState | undefined;
    destroy(name: string): boolean;
    move(name: string, x: number, y: number): boolean;
    resize(name: string, width: number, height: number): boolean;
    show(name: string): boolean;
    hide(name: string): boolean;
    raise(name: string): boolean;
    lower(name: string): boolean;
    setStyleSheet(name: string, css: string): boolean;
    list(parent: string): ScrollBoxState[];
    subscribe(parent: string, fn: Listener): () => void;
    clearAll(): void;
    private notify;
}
export {};
