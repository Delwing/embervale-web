import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
import type { PackageKind, PackageManifest } from '../storage/schema';
import { type MudletImportResult } from './mudletXmlImport';
export interface InstallResult {
    manifest: PackageManifest;
    data: MudletImportResult;
}
export interface InstallOptions {
    /**
     * 'package' (default) — plain XML imports skip VFS storage; only zips are kept on disk.
     * 'module'            — XML on disk is the source of truth: even plain XML is written to the
     *                       VFS so it can be re-parsed on the next profile open and synced to.
     */
    kind?: PackageKind;
    /**
     * Absolute VFS path the bytes were read from, when known. If it lives inside the
     * derived pkgDir, the install skips the pkgDir wipe — otherwise an installer-style
     * "unzip into <pkgDir>/ then installPackage(<pkgDir>/foo.xml)" pattern would delete
     * the resources the script just staged.
     */
    sourcePath?: string;
}
/**
 * Install a Mudlet package from in-memory bytes. Synchronous — the caller is
 * expected to flush the VFS afterwards (or let the next idle flush handle it).
 *
 * Behaviour by kind:
 * - .mpackage / .zip : always unzipped into <profilePath>/<packageName>/. The full payload
 *                      is preserved so resources (images, sounds, lua modules) remain
 *                      available to scripts via the VFS, regardless of `kind`.
 * - .xml as 'package': parse only — no files written. Nodes live in the app store.
 * - .xml as 'module' : the XML is also written to <profilePath>/<packageName>/<filename>;
 *                      the on-disk file is treated as the source of truth, so it must exist
 *                      to be re-parsed on profile open.
 *
 * The XML is parsed in package-mode, which wraps each category in a top-level
 * group and tags every node with the package name, making uninstall a tag-based cascade.
 */
export declare function installPackageFromBytes(filename: string, buf: Uint8Array, vfs: ProfileVFS, opts?: InstallOptions): InstallResult;
/** Async wrapper that reads from a File and flushes the VFS to disk on success. */
export declare function installPackageFromFile(file: File, vfs: ProfileVFS, opts?: InstallOptions): Promise<InstallResult>;
/**
 * Remove a package's on-disk files. The store handles tag-based node removal
 * separately. Modules are exempt: they unlink only — the underlying XML (and any
 * unzipped resources) survive uninstall so the user's source files aren't
 * silently destroyed when they remove the module from the app.
 */
export declare function uninstallPackageFiles(manifest: PackageManifest, vfs: ProfileVFS): Promise<void>;
/**
 * Resolve the absolute VFS path of a module's XML file. Honors `xmlVfsPath` (in-place
 * modules) first, then falls back to the managed `<profilePath>/<name>/<xmlPath>` layout.
 * Returns null if neither is set.
 */
export declare function moduleXmlAbsolutePath(manifest: PackageManifest, vfs: ProfileVFS): string | null;
/**
 * Re-read a module's XML from the VFS and return the parsed result.
 * Throws if the on-disk file is missing — modules require their XML to be present.
 */
export declare function reloadModuleFromVfs(manifest: PackageManifest, vfs: ProfileVFS): MudletImportResult;
/**
 * Install a module from a path that already lives inside the profile's VFS.
 *
 * - Plain XML : referenced in place. The manifest stores `xmlVfsPath` and no pkgDir is
 *               created. Reload and sync read/write the user-chosen path verbatim, so
 *               external tools (a synced folder, an editor) can keep editing it.
 * - .mpackage / .zip : same flow as a normal module install — extracted into a fresh
 *               pkgDir so resources are accessible. The original archive on disk is
 *               left untouched but is no longer referenced by the module.
 *
 * Throws on read/parse failures.
 */
export declare function installModuleFromVfsPath(absolutePath: string, vfs: ProfileVFS): InstallResult;
