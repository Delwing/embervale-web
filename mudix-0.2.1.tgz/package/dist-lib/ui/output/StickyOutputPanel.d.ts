import type React from 'react';
import { type OutputMenuExtraItem } from './OutputContextMenu';
interface StickyOutputPanelProps {
    outputRef: React.RefObject<HTMLDivElement | null>;
    sentinelRef: React.RefObject<HTMLDivElement | null>;
    stickyAreaRef: React.RefObject<HTMLDivElement | null>;
    isSplitView: boolean;
    scrollToBottom: () => void;
    background?: string;
    /** Extra CSS layered on top of `background` — used to add background-image
     *  / border-image properties from Mudlet setBackgroundImage. */
    backgroundExtra?: React.CSSProperties;
    foreground?: string;
    showTimestamps?: boolean;
    onToggleTimestamps?: () => void;
    /** Script-provided right-click entries (Mudlet addMouseEvent), evaluated
     *  lazily when the menu opens since the registry can change. */
    getMenuExtraItems?: () => OutputMenuExtraItem[];
    commandInputRef?: React.RefObject<HTMLInputElement | HTMLTextAreaElement | null>;
    className?: string;
    fontSize?: number;
    fontFamily?: string;
    wrapAt?: number;
    wrapIndent?: number;
    wrapHangingIndent?: number;
}
export declare function StickyOutputPanel({ outputRef, sentinelRef, stickyAreaRef, isSplitView, scrollToBottom, background, backgroundExtra, foreground, showTimestamps, onToggleTimestamps, getMenuExtraItems, commandInputRef, className, fontSize, fontFamily, wrapAt, wrapIndent, wrapHangingIndent, }: StickyOutputPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
