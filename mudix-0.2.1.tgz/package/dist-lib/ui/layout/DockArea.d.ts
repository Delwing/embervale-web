import type { DockSide, DragState, ScriptWindowRenderData } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface DockAreaProps {
    side: DockSide;
    windows: ScriptWindowRenderData[];
    extent: number;
    dragState: DragState | null;
    manager: WindowManager;
    onSetExtent: (side: DockSide, n: number) => void;
    onDragStateChange: (ds: DragState | null) => void;
    onTitlebarContextMenu: (e: React.MouseEvent) => void;
}
export declare function DockArea({ side, windows, extent, dragState, manager, onSetExtent, onDragStateChange, onTitlebarContextMenu }: DockAreaProps): import("react/jsx-runtime").JSX.Element;
export {};
