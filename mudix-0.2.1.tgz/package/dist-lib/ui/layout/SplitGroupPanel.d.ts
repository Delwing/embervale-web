import type { DockSide, DragState, ScriptWindowRenderData } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface SplitGroupPanelProps {
    side: DockSide;
    panels: ScriptWindowRenderData[];
    splitGroupId: string;
    manager: WindowManager;
    onDragStateChange: (ds: DragState | null) => void;
    onTitlebarContextMenu: (e: React.MouseEvent) => void;
    /** Panel ID hovered for a tab-stack drop — highlights only that sub-panel. */
    stackTargetId?: string;
    /** Panel ID targeted for a within-split insert — shows ghost between members. */
    splitTargetId?: string;
    splitBefore?: boolean;
}
export declare function SplitGroupPanel({ side, panels, manager, onDragStateChange, onTitlebarContextMenu, stackTargetId, splitTargetId, splitBefore }: SplitGroupPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
