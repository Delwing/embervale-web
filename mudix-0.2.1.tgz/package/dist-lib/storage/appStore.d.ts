import { type AppSchema, type MudConnection, type AliasNode, type ButtonNode, type KeyNode, type TimerNode, type TriggerNode, type ScriptNode, type ScriptEditorBounds, type ModalBounds, type ClientSettings, type ProfileSettings, type PackageManifest, type WindowLayoutSnapshot, type ProfileVariables } from './schema';
import type { MudletVariable } from '../import/mudletVariables';
import type { MudletImportResult } from '../import/mudletXmlImport';
import type { WindowOpenOptions } from '../ui/windows/types';
interface AppStore extends AppSchema {
    /** Adds a connection and returns its newly generated id (so callers can
     *  immediately attach per-profile data like saved login credentials). */
    addConnection: (data: Omit<MudConnection, 'id'>) => string;
    updateConnection: (id: string, data: Omit<MudConnection, 'id'>) => void;
    /** Partial update preserving fields the patch doesn't mention. Used for
     *  surgical edits (icon, login creds) that must not wipe the rest of the
     *  connection record. Keys set to `undefined` are removed. */
    patchConnection: (id: string, patch: Partial<Omit<MudConnection, 'id'>>) => void;
    removeConnection: (id: string) => void;
    /** Reorder the profile list to match `orderedIds`. Ids not present in the
     *  list are ignored; any existing connection missing from `orderedIds` is
     *  appended in its current relative order (so a stale list can't drop
     *  profiles). Backs drag-to-rearrange on the connection screen. */
    reorderConnections: (orderedIds: string[]) => void;
    patchClient: (patch: Partial<ClientSettings>) => void;
    patchConnectionProfile: (connectionId: string, patch: Partial<ProfileSettings>) => void;
    saveWindowHint: (connectionId: string, panelId: string, hint: WindowOpenOptions) => void;
    clearWindowHints: (connectionId: string) => void;
    saveDockExtents: (connectionId: string, extents: Record<string, number>) => void;
    saveLayoutSnapshot: (connectionId: string, snapshot: WindowLayoutSnapshot) => void;
    /** Replace the set of global names flagged to persist (Mudlet save-list).
     *  Edited from the Variables view; triggers a profile-data save. */
    setVariableSaveList: (connectionId: string, saveList: string[]) => void;
    /** Replace the captured variable values without disturbing the save-list
     *  reference — so the engine can refresh them on save without re-triggering
     *  the save subscription (which keys on the save-list, not values). */
    setVariableValues: (connectionId: string, values: MudletVariable[]) => void;
    addScript: (connectionId: string, data: Omit<ScriptNode, 'id'>) => string;
    updateScript: (connectionId: string, id: string, patch: Partial<Omit<ScriptNode, 'id'>>) => void;
    removeScript: (connectionId: string, id: string) => void;
    addAlias: (connectionId: string, data: Omit<AliasNode, 'id'>) => string;
    updateAlias: (connectionId: string, id: string, patch: Partial<Omit<AliasNode, 'id'>>) => void;
    updateAliases: (connectionId: string, patches: ReadonlyArray<{
        id: string;
        patch: Partial<Omit<AliasNode, 'id'>>;
    }>) => void;
    removeAlias: (connectionId: string, id: string) => void;
    addTrigger: (connectionId: string, data: Omit<TriggerNode, 'id'>) => string;
    updateTrigger: (connectionId: string, id: string, patch: Partial<Omit<TriggerNode, 'id'>>) => void;
    /** Bulk apply enabled/disabled (or any partial) to many triggers in one set(). */
    updateTriggers: (connectionId: string, patches: ReadonlyArray<{
        id: string;
        patch: Partial<Omit<TriggerNode, 'id'>>;
    }>) => void;
    removeTrigger: (connectionId: string, id: string) => void;
    removeTriggers: (connectionId: string, ids: ReadonlyArray<string>) => void;
    addTimer: (connectionId: string, data: Omit<TimerNode, 'id'>) => string;
    updateTimer: (connectionId: string, id: string, patch: Partial<Omit<TimerNode, 'id'>>) => void;
    updateTimers: (connectionId: string, patches: ReadonlyArray<{
        id: string;
        patch: Partial<Omit<TimerNode, 'id'>>;
    }>) => void;
    removeTimer: (connectionId: string, id: string) => void;
    removeTimers: (connectionId: string, ids: ReadonlyArray<string>) => void;
    removeAliases: (connectionId: string, ids: ReadonlyArray<string>) => void;
    addKeybinding: (connectionId: string, data: Omit<KeyNode, 'id'>) => string;
    updateKeybinding: (connectionId: string, id: string, patch: Partial<Omit<KeyNode, 'id'>>) => void;
    removeKeybinding: (connectionId: string, id: string) => void;
    removeKeybindings: (connectionId: string, ids: ReadonlyArray<string>) => void;
    addButton: (connectionId: string, data: Omit<ButtonNode, 'id'>) => string;
    updateButton: (connectionId: string, id: string, patch: Partial<Omit<ButtonNode, 'id'>>) => void;
    removeButton: (connectionId: string, id: string) => void;
    moveScript: (connectionId: string, id: string, newParentId: string | null, insertBeforeId: string | null) => void;
    moveAlias: (connectionId: string, id: string, newParentId: string | null, insertBeforeId: string | null) => void;
    moveTrigger: (connectionId: string, id: string, newParentId: string | null, insertBeforeId: string | null) => void;
    moveTimer: (connectionId: string, id: string, newParentId: string | null, insertBeforeId: string | null) => void;
    moveKeybinding: (connectionId: string, id: string, newParentId: string | null, insertBeforeId: string | null) => void;
    moveButton: (connectionId: string, id: string, newParentId: string | null, insertBeforeId: string | null) => void;
    saveScriptEditorBounds: (connectionId: string, bounds: ScriptEditorBounds) => void;
    saveModalBounds: (connectionId: string, key: string, bounds: ModalBounds) => void;
    installPackage: (connectionId: string, manifest: PackageManifest, data: MudletImportResult) => void;
    uninstallPackage: (connectionId: string, packageName: string) => void;
    updatePackageManifest: (connectionId: string, packageName: string, patch: Partial<Omit<PackageManifest, 'name'>>) => void;
    /** Replace the VFS-persisted automation slices for one connection in a single
     *  set(). Called once on profile open, after its VFS mounts, to seed the
     *  store from `.mudix/profile.json`. Missing keys reset to empty arrays. */
    hydrateConnectionData: (connectionId: string, data: PersistedConnectionData) => void;
}
/** The per-connection slices persisted in the profile VFS (see profileVfsData.ts). */
interface PersistedConnectionData {
    scripts?: ScriptNode[];
    aliases?: AliasNode[];
    triggers?: TriggerNode[];
    timers?: TimerNode[];
    keybindings?: KeyNode[];
    buttons?: ButtonNode[];
    packages?: PackageManifest[];
    profile?: Partial<ProfileSettings>;
    windowHints?: Record<string, WindowOpenOptions>;
    dockExtents?: Record<string, number>;
    scriptEditorBounds?: ScriptEditorBounds;
    modalBounds?: Record<string, ModalBounds>;
    layoutSnapshot?: WindowLayoutSnapshot;
    variables?: ProfileVariables;
}
/** localStorage key + schema version for the persisted store. Exported so the
 *  cross-tab sync (crossTabSync.ts) can match `storage` events to this store and
 *  reject writes from a different schema version. */
export declare const MUDIX_STORE_NAME = "mudix_v1";
export declare const MUDIX_STORE_VERSION = 21;
/** One-time localStorage key holding pre-v21 per-profile UI/layout/settings
 *  slices, stashed by the v21 migration so they can be moved into each profile's
 *  VFS (.mudix/profile.json) the first time it's opened. Kept separate from the
 *  persisted store blob so editing the connections list (which rewrites the
 *  blob) can't drop un-migrated profiles' data. Consumed per-profile by
 *  loadProfileData, then removed when empty. */
export declare const MIGRATION_BACKUP_KEY = "mudix_profile_migration_v21";
export declare const useAppStore: import("zustand").UseBoundStore<Omit<import("zustand").StoreApi<AppStore>, "setState" | "persist"> & {
    setState(partial: AppStore | Partial<AppStore> | ((state: AppStore) => AppStore | Partial<AppStore>), replace?: false | undefined): unknown;
    setState(state: AppStore | ((state: AppStore) => AppStore), replace: true): unknown;
    persist: {
        setOptions: (options: Partial<import("zustand/middleware").PersistOptions<AppStore, {
            connections: MudConnection[];
            client: ClientSettings;
        }, unknown>>) => void;
        clearStorage: () => void;
        rehydrate: () => Promise<void> | void;
        hasHydrated: () => boolean;
        onHydrate: (fn: (state: AppStore) => void) => () => void;
        onFinishHydration: (fn: (state: AppStore) => void) => () => void;
        getOptions: () => Partial<import("zustand/middleware").PersistOptions<AppStore, {
            connections: MudConnection[];
            client: ClientSettings;
        }, unknown>>;
    };
}>;
export {};
