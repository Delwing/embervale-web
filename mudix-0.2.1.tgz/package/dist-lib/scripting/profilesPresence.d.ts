/**
 * Cross-tab view of which profiles are open and which are connected — backs
 * Mudlet's `getProfiles()`. mudix runs one profile per browser tab, so two
 * cross-tab signals are combined:
 *
 *  - **loaded** (open & editable): every open profile holds an exclusive Web
 *    Lock named `mudix:profile:<id>` (see profileLock.ts). `navigator.locks
 *    .query()` lists held locks across all same-origin tabs, so the held
 *    profile locks ARE the loaded set. Authoritative and crash-safe (the browser
 *    auto-releases a lock when its tab closes/crashes). Polled on a slow interval
 *    since the query is async but `getProfiles()` is a synchronous Lua call.
 *
 *  - **connected** (playing): not observable through Web Locks, so each tab
 *    announces its own live connection state over a `BroadcastChannel`. A tab
 *    announces on connect/disconnect and answers a `query` from a newly-opened
 *    tab; `bye` on teardown clears it eagerly (a crash is caught by the loaded
 *    set dropping). The owning tab's own state is always read live.
 *
 * Degrades gracefully where the platform lacks these APIs (legacy browser,
 * insecure context, or the Node test environment): no Web Locks → loaded is just
 * this profile; no BroadcastChannel → connected is just this profile's live
 * state. That matches the old single-profile `getProfiles()` behaviour.
 */
export declare class ProfilesPresence {
    private readonly ownId;
    /** This tab's live connected state, read whenever we announce. */
    private readonly localConnected;
    private channel;
    private lockTimer;
    /** Loaded profile ids from Web Locks (authoritative; always includes self). */
    private loaded;
    /** Last-announced connected state of OTHER tabs' profiles. */
    private readonly remoteConnected;
    constructor(ownId: string, 
    /** This tab's live connected state, read whenever we announce. */
    localConnected: () => boolean, refreshMs?: number);
    /** Broadcast this tab's current connected state to peers. Call on connect/
     *  disconnect. No-op without a channel. */
    announce(): void;
    /** Connection ids of all loaded profiles (best-effort snapshot, always
     *  including this profile's own id). */
    loadedIds(): string[];
    /** Connected state for a profile id: own → live, others → last announced
     *  (false when never announced). Callers gate this on `loaded` so a crashed
     *  tab's stale "connected" can't outlive its lock. */
    isConnected(id: string): boolean;
    private onMessage;
    private refreshLoaded;
    destroy(): void;
}
