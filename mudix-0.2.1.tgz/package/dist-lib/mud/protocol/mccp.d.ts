export declare class MccpHandler {
    private compressing;
    private inflator;
    private readonly sendRaw;
    private _enabled;
    constructor(sendRaw: (data: string) => void);
    isActive(): boolean;
    get enabled(): boolean;
    set enabled(value: boolean);
    /**
     * Process incoming data, handling MCCP negotiation and decompression.
     * Must be called BEFORE stripTelnetSequences.
     */
    processData(data: string): string;
    reset(): void;
    private startCompression;
    private decompress;
}
