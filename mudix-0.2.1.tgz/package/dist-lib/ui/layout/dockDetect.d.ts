import type { DockSide } from '../windows/types';
/**
 * 5-zone drop detection per slot.
 *
 * For a horizontal dock area (top/bottom):
 *   ┌────────────────────────────────┐
 *   │        SPLIT ABOVE 25%         │
 *   ├────┬──────────────────────┬────┤
 *   │bef │      tab stack       │aft │  (middle 50% cross-axis)
 *   │20% │      center 60%      │20% │
 *   ├────┴──────────────────────┴────┤
 *   │        SPLIT BELOW 25%         │
 *   └────────────────────────────────┘
 *
 * Ghost-slot hysteresis: when the cursor is inside the ghost slot that appears
 * on a before/after drop, we merge the ghost + adjacent real panel into one
 * bounding box for zone detection.  This keeps the center/split zones reachable
 * without having to drag all the way across the ghost to reach the shifted panel.
 */
export declare function detectDock(mx: number, my: number): {
    side: DockSide | null;
    slotIndex: number;
    stackTargetId?: string;
    splitTargetId?: string;
    splitBefore?: boolean;
};
