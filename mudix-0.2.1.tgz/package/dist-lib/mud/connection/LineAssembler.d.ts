export declare const DEFAULT_PROMPT_TIMEOUT_MS = 300;
/**
 * Keep prompt-flush timeouts in a sane range. 0 disables the safety net (only
 * a real GA/EOR or the next chunk's newline will flush a partial tail) — handy
 * for tests but risky for GA-less MUDs. The upper bound stops a typo from
 * stalling output for minutes.
 */
export declare function clampPromptTimeout(ms: number): number;
export interface LineAssemblerCallbacks {
    /** Deliver assembled whole lines (or a flushed prompt tail) downstream —
     *  the trigger pipeline and rendering treat each chunk as complete lines. */
    onChunk(text: string, ts: number): void;
    /** Fired after a prompt marker (IAC GA/EOR) flushed the held tail — the
     *  owner emits its `prompt` event here. */
    onPrompt(): void;
    /** Fired after an idle-timer flush so the owner can render any messages
     *  the flushed chunk produced (MudClient.flushMessageBuffer). */
    onIdleFlush(): void;
}
export interface LineAssemblerOptions {
    promptTimeoutMs?: number;
    /** Mudlet `mUSE_IRE_DRIVER_BUGFIX` — strip a spurious leading newline from
     *  GA-driven prompt blocks. Off by default; toggled live via
     *  setFixUnnecessaryLinebreaks (setConfig). */
    fixUnnecessaryLinebreaks?: boolean;
}
/**
 * Assembles the decoded MUD text stream into whole lines. WebSocket frames can
 * split a long line at an arbitrary byte (mid-word, mid-ANSI-escape), so the
 * trailing partial line of each frame is held back until the next frame
 * supplies the rest, a prompt marker (IAC GA/EOR) flushes it, or the idle
 * timer fires. Our render path finalizes every emitted chunk and has no
 * downstream open-line carry (unlike Mudlet's TBuffer), so the "line ends only
 * at \n or GA" invariant is enforced here. The live-partial parity work is
 * deferred — see docs/line-assembly-tbuffer-port.md.
 */
export declare class LineAssembler {
    private readonly callbacks;
    /** Trailing text (after the last `\n`) held back from rendering until either
     *  the next frame supplies the rest of the line, a prompt marker arrives, or
     *  the idle-flush timer fires. Prevents spurious line breaks when a long MUD
     *  line is split across multiple WebSocket frames. */
    private pendingLineTail;
    private pendingTailTimer;
    private promptTimeoutMs;
    /** Set true once the server has sent IAC GA / IAC EOR at least once.
     *  Mirrors Mudlet's `mGA_Driver` latch (`cTelnet::gotRest`). From then on
     *  the held partial tail is flushed by the prompt marker rather than the
     *  idle timer. Note: unlike Mudlet's cTelnet — which posts GA-mode chunks
     *  verbatim and reassembles split lines in TBuffer — we keep buffering
     *  partial lines here, because our render path finalizes every emitted
     *  chunk and has no downstream open-line carry. */
    private _gaDriver;
    /** True at the start of a GA-driven data block — i.e. before any content of
     *  the current post-GA transmission has been seen. Drives the
     *  `fixUnnecessaryLinebreaks` leading-newline strip, which fires at most once
     *  per block. Set true on connect and after each prompt flush, cleared once
     *  the block's leading-newline question has been settled. */
    private atPromptBlockStart;
    private fixUnnecessaryLinebreaks;
    constructor(callbacks: LineAssemblerCallbacks, options?: LineAssemblerOptions);
    /** True once the session has latched into GA-driven prompt mode. */
    get gaDriver(): boolean;
    setPromptTimeoutMs(ms: number): void;
    getPromptTimeoutMs(): number;
    /** Mudlet `setConfig("fixUnnecessaryLinebreaks", …)`. Takes effect on the
     *  next GA-driven block; never retroactive. */
    setFixUnnecessaryLinebreaks(enabled: boolean): void;
    /** Drop all held state (call on connect and after close). */
    reset(): void;
    /** Feed one frame's decoded text plus whether the frame carried a prompt
     *  marker (IAC GA/EOR). Emits only whole lines (text up to and including
     *  the last `\n`) and holds the trailing partial in `pendingLineTail`
     *  until the rest of the line arrives, a prompt marker flushes it, or the
     *  idle timer fires. */
    feed(decoded: string, hasPrompt: boolean, ts: number): void;
    /** Flush a held-back partial line (text after the final `\n` of a frame).
     *  Triggered by prompt markers (IAC GA/EOR), the idle-flush timer, or
     *  socket close. Pushes the tail through the normal chunk path so triggers
     *  and rendering treat it as a complete line. */
    flush(ts: number, final?: boolean): void;
    private scheduleTailFlush;
    private clearTailTimer;
}
