export declare function renderMarkdown(src: string): string;
