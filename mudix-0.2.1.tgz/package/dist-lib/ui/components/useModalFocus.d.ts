/** Visible (Tab-reachable) focusable descendants of `container`, in DOM order. */
export declare function focusableWithin(container: HTMLElement): HTMLElement[];
/**
 * Where a Tab/Shift+Tab should send focus to keep it inside the dialog, or null
 * to let the browser move focus normally (the common case, mid-list). Wraps at
 * the ends and pulls focus back in if it has escaped the dialog. Pure — the
 * caller reads the return and focuses it. Exported for testing.
 */
export declare function focusTrapTarget(items: HTMLElement[], active: HTMLElement | null, shiftKey: boolean): HTMLElement | null;
export interface ModalFocusOptions {
    /** Move focus into the dialog on open. Default true. Set false when the
     *  modal manages its own initial focus (e.g. a specific field or button). */
    autoFocus?: boolean;
    /** Close on Escape via `onClose`. Default true. Set false when the modal has
     *  its own Escape handling (then `onClose` may be omitted). */
    closeOnEscape?: boolean;
}
export declare function useModalFocus<T extends HTMLElement = HTMLDivElement>(onClose?: () => void, opts?: ModalFocusOptions): React.RefObject<T | null>;
