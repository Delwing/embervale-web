import type { MudSession } from '../../mud/MudSession';
import { AnsiAwareBuffer } from '../../mud/text/FormatState';
export declare const MAX_LINES = 60;
/**
 * The plain text a `message` line should announce, or null when it must be
 * skipped: interim `script-partial` cecho output (superseded by the finalized
 * line), missing text, or blank/whitespace-only lines (no speech, only churn).
 * Raw strings carry ANSI, so they route through an {@link AnsiAwareBuffer} for
 * the plain text; an `AnsiAwareBuffer` payload already exposes `.text`. Pure.
 */
export declare function screenReaderPlainText(text?: string | AnsiAwareBuffer, type?: string): string | null;
/**
 * Append a batch of lines to the live `region` as ONE node (a wrapper div with
 * a child per line) so the screen reader announces the whole burst once — the
 * way Mudlet coalesces a buffer update into a single announcement — instead of
 * once per line. Per-line child divs keep the line boundaries in the a11y tree.
 * Then cap the region to `maxLines` batches. Returns true when a batch was
 * appended. Exported for testing.
 */
export declare function flushScreenReaderLines(region: HTMLElement, lines: string[], maxLines?: number): boolean;
export declare function ScreenReaderLog({ session }: {
    session: MudSession;
}): import("react/jsx-runtime").JSX.Element;
