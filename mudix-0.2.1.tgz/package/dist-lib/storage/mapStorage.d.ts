export declare function saveMap(connectionId: string, data: ArrayBuffer): Promise<void>;
export declare function loadMap(connectionId: string): Promise<ArrayBuffer | null>;
