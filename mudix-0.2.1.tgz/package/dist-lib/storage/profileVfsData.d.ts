import type { ScriptNode, AliasNode, TriggerNode, TimerNode, KeyNode, ButtonNode, PackageManifest, ProfileSettings, ScriptEditorBounds, ModalBounds, WindowLayoutSnapshot, ProfileVariables } from './schema';
import type { WindowOpenOptions } from '../ui/windows/types';
import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
/**
 * Per-profile data is stored inside that profile's own VFS rather than the
 * shared localStorage blob — see the design notes in CLAUDE.md / the storage
 * layer. One JSON file per profile holds the bulky tree data (scripts, aliases,
 * triggers, …) AND the per-profile UI/settings/layout slices, so the only
 * per-profile state left in localStorage is the connection record itself. That
 * makes each profile single-writer (one tab owns it via the cross-tab lock),
 * eliminating the multi-tab clobber the shared blob suffered.
 *
 * The file is dot-prefixed so it stays out of the way in the user-browsable
 * file area. `ProfileVFS.writeFile` creates the `.mudix/` parent dir for us.
 */
export declare const PROFILE_DATA_PATH = ".mudix/profile.json";
export interface PersistedProfileData {
    version: number;
    scripts: ScriptNode[];
    aliases: AliasNode[];
    triggers: TriggerNode[];
    timers: TimerNode[];
    keybindings: KeyNode[];
    buttons: ButtonNode[];
    packages: PackageManifest[];
    /** Mudlet saved-variables: the save-list + last captured values. Optional so
     *  older files (no variables) still parse. */
    variables?: ProfileVariables;
    profile?: Partial<ProfileSettings>;
    windowHints?: Record<string, WindowOpenOptions>;
    dockExtents?: Record<string, number>;
    scriptEditorBounds?: ScriptEditorBounds;
    modalBounds?: Record<string, ModalBounds>;
    layoutSnapshot?: WindowLayoutSnapshot;
}
/**
 * Read `.mudix/profile.json` from the profile VFS and push it into the store
 * for `connectionId`. Also completes the one-time v21 migration: if this
 * profile's UI/settings/layout slices haven't moved into the VFS yet, they're
 * pulled from the migration backup, hydrated, written to the VFS, and dropped
 * from the backup. No-op for a fresh profile with nothing to load.
 */
export declare function loadProfileData(vfs: ProfileVFS, connectionId: string): void;
/** Serialize a profile's automation + UI slices for `connectionId` from the store. */
export declare function serializeProfileData(connectionId: string): string;
/** Write the current store state for `connectionId` to the profile VFS. */
export declare function saveProfileData(vfs: ProfileVFS, connectionId: string): void;
