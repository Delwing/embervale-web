/** Shared prefix for every per-profile Web Lock name. */
export declare const PROFILE_LOCK_PREFIX = "mudix:profile:";
/** Web Lock name for a profile. */
export declare const profileLockName: (connectionId: string) => string;
/** Inverse of {@link profileLockName}: the connectionId encoded in a lock name,
 *  or null when the name isn't a profile lock. Used to enumerate which profiles
 *  are open across tabs from `navigator.locks.query()`. */
export declare const connectionIdFromLockName: (name: string) => string | null;
/** Best-effort check whether some tab currently holds the profile's lock. Used
 *  only to pick the initial "waiting for the other tab" message; the actual
 *  hand-off is the queued request in {@link acquireProfileLock}. */
export declare function isProfileLockHeld(connectionId: string): Promise<boolean>;
export interface ProfileLockHandle {
    /** Resolves once this tab owns the profile — immediately when the lock is
     *  free, or later when the owning tab releases it. Rejects with AbortError
     *  if the signal fires before ownership is granted. */
    readonly acquired: Promise<void>;
    /** Release ownership. Idempotent; safe to call before `acquired` resolves
     *  (it then cancels the pending request via the same signal path). */
    release(): void;
}
/** Acquire the profile's exclusive lock, queuing behind another tab if one
 *  already holds it. Pass an AbortSignal to stop waiting (e.g. the user backs
 *  out to the connection screen). Degrades to a no-op guard when the Web Locks
 *  API is unavailable (legacy browser or insecure context). */
export declare function acquireProfileLock(connectionId: string, signal: AbortSignal): ProfileLockHandle;
