import type { Completion, CompletionContext, CompletionResult } from '@codemirror/autocomplete';
export interface ReferenceGroup {
    title: string;
    prefix: string;
    entries: Completion[];
}
export declare const REFERENCE_GROUPS: ReferenceGroup[];
export declare const HOVER_MAP: Map<string, Completion>;
export declare function luaCompletionSource(context: CompletionContext): CompletionResult | null;
