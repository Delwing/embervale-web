import type { MudletModuleRef } from '../import/mudletHost';
export interface ModuleUpload {
    key: string;
    bytes: Uint8Array;
}
interface Props {
    /** Modules whose external XML file couldn't be found in the imported tree. */
    modules: MudletModuleRef[];
    /** Called when every module has been decided — uploaded modules are folded
     *  in, the rest dropped. */
    onComplete: (uploads: ModuleUpload[]) => void;
    /** Abort the whole import. */
    onCancel: () => void;
}
/**
 * After a Mudlet-profile import, modules that load from an external local XML
 * file (which a browser can't read, and that wasn't found inside the profile)
 * are listed here. For each, the user uploads its `.xml` or drops it. The import
 * only proceeds once every module is decided.
 */
export declare function ModuleResolveModal({ modules, onComplete, onCancel }: Props): import("react/jsx-runtime").JSX.Element;
export {};
