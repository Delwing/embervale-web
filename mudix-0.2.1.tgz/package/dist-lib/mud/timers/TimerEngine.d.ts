import type { TimerNode } from '../../storage/schema';
export type { TimerNode };
type TempFn = () => void;
type ExecuteFn = (timer: TimerNode) => void;
export declare class TimerEngine {
    private readonly temp;
    /** Permanent timers keyed by stored TimerNode id (uuid). Two timers can
     *  share a name; we keep id as the canonical handle and build a separate
     *  name → id index for Mudlet's name-based lookups. */
    private readonly perm;
    /** Name → first matching id, used by remainingTime / kill-by-name. */
    private readonly permNameToId;
    private nextId;
    /** Number of live session-scoped temp timers (Mudlet `getProfileStats` temp count). */
    get tempCount(): number;
    addTemp(seconds: number, fn: TempFn, repeat?: boolean): number;
    killTimer(id: number): boolean;
    /**
     * Cached previous load. `nodes` is the TimerNode keyed by id, `desc` is the
     * shape that determines whether the running setTimeout/setInterval is still
     * correct (seconds, repeat, isGroup, code presence, name) — if `desc` is
     * unchanged AND the timer is still enabled, the live handle is left alone.
     * This makes a name-toggle that disables one timer cost one clearTimeout
     * instead of "clear all + recreate all".
     */
    private readonly prevDesc;
    private descOf;
    loadPerm(timers: TimerNode[], executeFn: ExecuteFn): void;
    private startPerm;
    private killPermHandle;
    /**
     * Mudlet `remainingTime(idOrName)` — seconds until the next fire. For
     * non-repeating timers, returns the time left before the one and only
     * fire. For repeating timers, returns the time until the next tick.
     * Returns -1 if no live timer matches (Mudlet's miss sentinel).
     *   - Numeric arg: looks up tempTimer ids only.
     *   - String arg: looks up permanent timer names; falls back to the stored
     *     TimerNode id when the string is a uuid that no name matched.
     */
    remainingTime(idOrName: number | string): number;
    private stopPerm;
    destroy(): void;
}
