import React from 'react';
import type { MudSession } from '../../../mud/MudSession';
import type { ProfileVFS } from '../../../scripting/vfs/ProfileVFS';
import type { ScriptingEngine } from '../../../scripting/ScriptingEngine';
import './ScriptEditorPanel.css';
type Category = 'scripts' | 'aliases' | 'triggers' | 'timers' | 'keys' | 'buttons' | 'packages' | 'errors' | 'variables';
type EditCategory = Exclude<Category, 'errors' | 'packages' | 'variables'>;
interface ScriptEditorPanelProps {
    connectionId: string;
    session: MudSession;
    vfs: ProfileVFS | null;
    scriptingEngineRef?: React.RefObject<ScriptingEngine | null>;
    initialListWidth?: number;
    onSplitsChange?: (listWidth: number) => void;
    onOpenVfsFile?: (path: string, line?: number) => void;
}
/** Imperative API exposed to the title-bar search box. */
export interface ScriptEditorPanelHandle {
    /** Switch to the item's category, expand its ancestors, select it, and —
     *  when a line is given — move the editor cursor there. */
    navigateToItem: (category: EditCategory, id: string, line?: number) => void;
}
export declare const ScriptEditorPanel: React.ForwardRefExoticComponent<ScriptEditorPanelProps & React.RefAttributes<ScriptEditorPanelHandle>>;
export {};
