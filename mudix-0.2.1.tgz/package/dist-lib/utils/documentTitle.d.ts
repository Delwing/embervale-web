/**
 * Single owner of `document.title`.
 *
 * The tab title is composed from two parts that used to fight over it: a leading
 * connection-status dot (🟢/🟡/🔴, set from React) and the profile label. On top
 * of that sit transient flashes — Mudlet's `alert()` and the "notify on new
 * data" feature. Everything goes through here so there's exactly one blink
 * interval and one set of focus/visibility listeners for the whole app.
 *
 * The flash reuses the *same* status dot rather than adding a second one: while
 * flashing, the leading dot blinks to white `⚪` and back. Both frames are emoji
 * so they share an advance width and the title text never shifts as it blinks.
 * If there's no status dot (connection indicator off) the flash falls back to a
 * standalone 🟢 ↔ ⚪ dot so the notification is still visible.
 *
 * - `setBaseTitle()` updates the status dot + label; an active flash is preserved.
 * - `flashTitle()` starts the blink, until the user returns to the tab (and,
 *   optionally, no longer than `maxSeconds` — Mudlet's `alert(seconds)`).
 * - A flash is a no-op while the tab is already focused, matching Mudlet.
 */
/**
 * Set the steady-state title: a leading status `dot` (pass '' for none) and the
 * profile `text`. Any active flash keeps running on top of it.
 */
export declare function setBaseTitle(text: string, dot?: string): void;
/**
 * Flash the title until the user returns to the tab. If `maxSeconds` is given it
 * also caps the duration. No-op while the tab is focused. Calling again while a
 * flash is active just refreshes the deadline (the blink keeps its phase).
 */
export declare function flashTitle(maxSeconds?: number): void;
/** Stop any active flash immediately. Does not change the base title. */
export declare function clearTitleFlash(): void;
