import type { ReactNode } from 'react';
interface FormFieldProps {
    label: string;
    htmlFor?: string;
    className?: string;
    children: ReactNode;
}
export declare function FormField({ label, htmlFor, className, children }: FormFieldProps): import("react/jsx-runtime").JSX.Element;
interface CheckFieldProps {
    label: string;
    htmlFor?: string;
    className?: string;
    children: ReactNode;
}
export declare function CheckField({ label, htmlFor, className, children }: CheckFieldProps): import("react/jsx-runtime").JSX.Element;
export {};
