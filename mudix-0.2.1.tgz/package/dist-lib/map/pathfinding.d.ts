import type { MudletRoom } from 'mudlet-map-binary-reader';
export interface PathfindResult {
    /** Room ids visited in order, excluding the start room. Matches Mudlet's
     *  speedWalkPath, which prepends each step until reaching `from` but never
     *  prepends `from` itself. */
    path: number[];
    /** Direction taken at each step — short name ("n"/"ne"/"up"/"down"/"in"/"out")
     *  for stock exits or the verbatim command string for special exits. Same
     *  length as `path` / `weights`. */
    dirs: string[];
    /** Edge cost per step (target room weight, or per-exit weight override). */
    weights: number[];
    /** Sum of `weights` — Mudlet's getPath returns this alongside the bool. */
    totalWeight: number;
}
/**
 * Mudlet `findPath(from, to)` — A* shortest path. Heuristic mirrors Mudlet's
 * TAstar.h: 3D Euclidean distance when both rooms share an area, constant 1
 * (equivalent to Dijkstra) when they don't — Mudlet falls back because raw
 * coordinates aren't comparable across areas. Edge cost is the per-exit
 * override in `exitWeights[key]` if set, otherwise the target room's `weight`
 * (clamped to ≥1 to keep the heap monotonic).
 *
 * Skips locked rooms (`isLocked`), locked stock-direction exits (`exitLocks`
 * carries the 1-12 dir codes), and locked special exits. The binary reader
 * keys special-exit locks by destination room id (`mSpecialExitLocks` is an
 * array of target ids) — its round-trip loses per-command resolution when
 * multiple cmds share a destination, but that's the on-disk representation.
 *
 * Trivial `from == to` returns an empty path with totalWeight 0 (also
 * Mudlet's behavior). Returns null when either room is missing or no route
 * exists.
 */
export declare function findPath(rooms: ReadonlyMap<number, MudletRoom>, from: number, to: number): PathfindResult | null;
