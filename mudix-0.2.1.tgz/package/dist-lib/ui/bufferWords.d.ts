import type { MudSession } from '../mud/MudSession';
/**
 * Maintains a bounded, recency-ordered set of words seen in session output.
 * Subscribes to the `message` event — the single choke point every output line
 * passes through (the same tap SessionLogger uses) — so it captures MUD text,
 * script echoes, and trigger output alike. One instance per session.
 */
export declare class BufferWordIndex {
    private readonly session;
    private readonly words;
    private unsubscribe;
    constructor(session: MudSession);
    start(): void;
    stop(): void;
    private ingest;
    /** Words in recency order, newest first. */
    getWords(): string[];
}
export interface ActiveWord {
    /** Everything before the trailing word (unchanged by completion). */
    prefix: string;
    /** The trailing word the user is typing. */
    word: string;
}
/** Splits the trailing word being typed from its leading text. Returns null when
 *  the command is empty or ends in whitespace/punctuation (nothing to complete). */
export declare function splitTrailingWord(command: string): ActiveWord | null;
/** True when the trailing word is an *argument* (something precedes it), not the
 *  command name. This is what routes Tab to buffer completion vs. history. */
export declare function hasPrecedingWord(prefix: string): boolean;
/**
 * Prefix-matches `word` against several candidate lists, tried in priority order
 * (e.g. suggestions, then history, then buffer words). Case-insensitive,
 * de-duplicated across all lists, excludes the exact word already typed. Matching
 * is **prefix-only** — never subsequence — so a completion always literally starts
 * with what was typed. The returned order is the Tab cycle order.
 */
export declare function matchWordCandidates(word: string, lists: string[][], limit?: number): string[];
