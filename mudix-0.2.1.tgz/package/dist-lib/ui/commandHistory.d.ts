export declare const MAX_HISTORY = 500;
/** Default number of entries persisted to localStorage when the profile hasn't
 *  set Mudlet's `commandLineHistorySaveSize`. Matches MAX_HISTORY so existing
 *  histories survive untouched until the user opts into a smaller save cap. */
export declare const DEFAULT_HISTORY_SAVE_SIZE = 500;
/** localStorage key for a profile's command history. History is per-profile —
 *  one MUD's commands shouldn't surface in another's. The bare prefix (no
 *  connection) backs the connection screen before a profile is open. */
export declare function historyStorageKey(connectionId: string | null): string;
export declare function loadHistory(key: string): string[];
/** Persist the MRU history, keeping at most `saveSize` entries (Mudlet's
 *  `commandLineHistorySaveSize`). A negative size means "no cap"; the in-memory
 *  list is still bounded by MAX_HISTORY via {@link addToHistory}. */
export declare function saveHistory(items: string[], key: string, saveSize?: number): void;
export declare function addToHistory(history: string[], item: string): string[];
export type MatchKind = 'prefix-start' | 'prefix-mid' | 'subseq';
export interface Match {
    item: string;
    mruIndex: number;
    kind: MatchKind;
    /** First match position used as the LCP anchor. */
    anchor: number;
    /** [start, end) ranges over `item` to visually highlight. */
    ranges: Array<[number, number]>;
}
export declare function matchHistory(prefix: string, history: string[], limit?: number): Match[];
/** Longest common prefix across all matches, measured from each match's anchor.
 *  Returns the would-be replacement string if it extends the current prefix,
 *  null otherwise. Case-insensitive comparison; the returned string preserves
 *  the casing of the top-ranked match. */
export declare function computeLcp(matches: Match[], prefix: string): string | null;
