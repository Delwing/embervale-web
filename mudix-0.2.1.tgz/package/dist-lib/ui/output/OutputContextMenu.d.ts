export interface OutputMenuExtraItem {
    label: string;
    tooltip?: string;
    onClick: () => void;
}
interface OutputContextMenuProps {
    x: number;
    y: number;
    /** Whether the selection touches this window (gates the copy actions). */
    hasSelection: boolean;
    onSelectAll: () => void;
    onCopy: () => void;
    onCopyHtml: () => void;
    onCopyImage: () => void;
    /** Timestamp toggle — only the main console passes these. */
    showTimestamps?: boolean;
    onToggleTimestamps?: () => void;
    /** Script-provided entries (Mudlet addMouseEvent). */
    extraItems?: OutputMenuExtraItem[];
    onClose: () => void;
}
export declare function OutputContextMenu({ x, y, hasSelection, onSelectAll, onCopy, onCopyHtml, onCopyImage, showTimestamps, onToggleTimestamps, extraItems, onClose, }: OutputContextMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
