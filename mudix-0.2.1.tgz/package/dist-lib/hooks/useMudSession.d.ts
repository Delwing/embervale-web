import { MudSession, type SessionStatus, type MudSessionOptions } from '../mud/MudSession';
export declare function useMudSession(options?: MudSessionOptions): {
    session: MudSession;
    status: SessionStatus;
    ping: number | null;
    passwordMode: boolean;
    connect: (url: string) => void;
    disconnect: () => void;
    send: (text: string, echo?: boolean) => void;
};
