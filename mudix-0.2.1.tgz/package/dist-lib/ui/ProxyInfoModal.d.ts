interface Props {
    onClose: () => void;
    onUseProxy: (wssUrl: string) => void;
}
export declare function ProxyInfoModal({ onClose, onUseProxy }: Props): import("react/jsx-runtime").JSX.Element;
export {};
