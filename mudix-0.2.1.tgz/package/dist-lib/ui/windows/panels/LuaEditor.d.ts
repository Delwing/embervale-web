interface Props {
    value: string;
    onChange: (value: string) => void;
    /** Invoked when the user hits Ctrl/Cmd+S or Ctrl/Cmd+Enter inside the editor. */
    onSave?: () => void;
    /** Jump request from the parent (e.g. error log click). Bump `revision` to
     *  re-trigger a jump even when `line` is unchanged. */
    gotoLine?: {
        line: number;
        revision: number;
    } | null;
}
export declare function LuaEditor({ value, onChange, onSave, gotoLine }: Props): import("react/jsx-runtime").JSX.Element;
export {};
