export interface CmdLineMenuEntry {
    /** Stable id used by removeCommandLineMenuEvent. */
    uniqueName: string;
    /** Event name passed to raiseEvent on click. */
    eventName: string;
    /** Label rendered in the context menu. Defaults to uniqueName. */
    displayName: string;
}
/**
 * Backs Mudlet's addCommandLineMenuEvent / removeCommandLineMenuEvent /
 * getCommandLineMenuEvents. Right-clicking the command bar shows entries from
 * this registry; clicking one raises the registered event with the current
 * command-line text as the first argument.
 */
export declare class CmdLineMenuRegistry {
    private entries;
    private subscribers;
    private dispatcher;
    subscribe(cb: () => void): () => void;
    private notify;
    setDispatcher(fn: ((eventName: string, args: unknown[]) => void) | null): void;
    add(uniqueName: string, eventName: string, displayName?: string): boolean;
    remove(uniqueName: string): boolean;
    list(): CmdLineMenuEntry[];
    /** Raise the entry's event, passing the current command-line text. */
    dispatch(uniqueName: string, cmdLineText: string): void;
}
