import type { WindowManager } from '../windows/WindowManager';
interface PopoutWindowProps {
    id: string;
    title: string;
    width: number;
    height: number;
    manager: WindowManager;
    /** Called when the popout should be re-docked into the main window — either
     *  because the user closed the child window, or the browser blocked it. */
    onClosed: () => void;
}
/**
 * Detaches a panel into a separate browser window.
 *
 * The whole window system is built on a single persistent portal-target div per
 * panel (WindowManager.getOrCreatePortalTarget) that physically moves between
 * dock slots and floating frames while the React component rendered into it
 * never unmounts. A popout is just one more place to move that div: into a
 * `window.open()` child document. Because the component stays mounted in the
 * main React tree, scrollback, buffered writes, and the live renderer/viewport
 * registrations all survive the move.
 *
 * Cross-window events: React 19 attaches its event delegation to the root
 * container passed to createRoot — which lives in the main window — so synthetic
 * events never reach panel content sitting in another window. We fix this by
 * mounting a throwaway React root on the child window's body and appending the
 * portal target as a descendant (the same appendChild-into-a-ref'd-div pattern
 * DockedPanel/ScriptWindow use). The throwaway root registers React's listeners
 * on the child document; when a native event fires there, React resolves the
 * target node's fiber (the `__reactFiber$` key matches because both roots share
 * the one React bundle) and dispatches synthetic events up the *main* tree, so
 * the panel's existing onChange/onKeyDown/onClick handlers fire normally.
 */
export declare function PopoutWindow({ id, title, width, height, manager, onClosed }: PopoutWindowProps): null;
export {};
