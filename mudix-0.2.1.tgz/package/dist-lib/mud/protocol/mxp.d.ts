import type { BufferSegment, FormatStateSnapshot } from "../text/FormatState";
import { HyperlinkPresetRegistry } from "../text/hyperlinkConfig";
/** A clickable region the parser found, expressed as offsets into `plain`. The
 *  engine builds the actual `FormatHyperlink` (with session/URL behaviour). */
export interface MxpLink {
    /** Start offset into the line's plain text (inclusive). */
    start: number;
    /** End offset into the line's plain text (exclusive). */
    end: number;
    /** `url` → open in a browser tab; `command` → send to the MUD. */
    kind: "command" | "url";
    /** The single command or URL fired on left-click. */
    payload: string;
    /** Tooltip / title text. */
    hint?: string;
    /** Present when the SEND carried a `cmd1|cmd2|…` list — the engine renders a
     *  right-click popup of `cmds` labelled by `hints`. */
    prompts?: {
        cmds: string[];
        hints: string[];
    };
}
/** A `<FRAME>` window-lifecycle command the parser surfaces to the session.
 *  The parser is session-free, so it only reports the request; the consumer
 *  (ScriptingEngine) maps it onto a mini-console via the window manager. */
export interface MxpFrameCommand {
    /** Frame name (the window id). */
    name: string;
    /** Upper-cased attribute keys → raw string values. Flag attributes
     *  (`INTERNAL`/`EXTERNAL`/`FLOATING`) are present with value `"true"`.
     *  `ACTION` is `open` (default) / `close` / `redirect`; geometry lives in
     *  `LEFT`/`TOP`/`WIDTH`/`HEIGHT`. */
    attrs: Record<string, string>;
}
/** Text the parser redirected into a named frame via `<DEST>…</DEST>`. */
export interface MxpRedirect {
    /** Target frame name (matches an `MxpFrameCommand.name`). */
    frame: string;
    /** Styled segments of the redirected text. */
    segments: BufferSegment[];
    /** Plain text of the redirected run. */
    plain: string;
    /** `EOL` attr (or the network line ended mid-DEST): the write is a complete
     *  line. */
    eol: boolean;
    /** `EOF` attr: clear the frame before writing (status-frame replace). */
    eof: boolean;
}
/** The result of parsing one raw MXP line. */
export interface MxpLineResult {
    /** Styled segments, ready for `new AnsiAwareBuffer(segments)`. */
    segments: BufferSegment[];
    /** MXP-stripped, ANSI-stripped, entity-decoded text — for trigger matching. */
    plain: string;
    /** End-of-line SGR/format pen, carried into the next line (replaces
     *  `computeTrailingState` while MXP is active). */
    trailingSnapshot?: FormatStateSnapshot;
    /** Clickable regions discovered on this line. */
    links: MxpLink[];
    /** `<FRAME>` commands seen on this line (window create/close). Omitted when none. */
    frames?: MxpFrameCommand[];
    /** Text redirected into frames via `<DEST>` on this line. Omitted when none. */
    redirects?: MxpRedirect[];
}
export declare class MxpParser {
    private readonly opts;
    private elements;
    private entities;
    private lineMode;
    private lockedMode;
    private tempSecure;
    private stack;
    /** Active MXP `<COLOR>`/`<FONT>` fg/bg overrides, innermost last. While
     *  non-empty, the top entry's colours are painted over whatever the ANSI
     *  pen holds — matching Mudlet, where an open MXP colour element overrides
     *  embedded ANSI SGR (TBuffer.cpp: `if (hasFgColor()) c.mFgColor = ...`).
     *  Stays in sync with the colour tags on `stack` (pushed in openColor,
     *  popped in finalizeTag). */
    private mxpColorStack;
    /** Partial tag/entity held from the end of the previous line. */
    private pendingTag;
    /** Active `<DEST>` target frame (persists across lines until `</DEST>`), or
     *  null when output flows to the main window. While set, appended text and
     *  flushed runs route to `destOut`/`destPlain` instead of `out`/`plain`. */
    private destName;
    private destEol;
    private destEof;
    /** OSC 8 preset definitions seen this session (shared with the ANSI path
     *  when the engine supplies a registry). */
    private presets;
    private fmt;
    private out;
    private run;
    private plain;
    private links;
    /** `<FRAME>` commands and `<DEST>` redirects accumulated this line. */
    private frames;
    private redirects;
    /** Redirected-text scratch — the current `<DEST>` run's segments/plain. */
    private destOut;
    private destPlain;
    constructor(opts: {
        send: (raw: string) => void;
        presets?: HyperlinkPresetRegistry;
    });
    /** Clear all cross-line state. Called on (re)connect so a new session starts
     *  with no leftover definitions, open tags, or modes. */
    reset(): void;
    /** Parse one raw line (post telnet-strip, post UTF-8 decode), which may carry
     *  ANSI SGR, MXP tags, `ESC[#z` modes, and entities. `baseSnapshot` is the
     *  carried pen from the previous line. */
    parseLine(rawLine: string, baseSnapshot?: FormatStateSnapshot): MxpLineResult;
    private effectiveMode;
    private resetTransientMode;
    private appendText;
    private flushRun;
    private parseFragment;
    private applyLineMode;
    private closeAllTags;
    private handleTag;
    private openAllowed;
    private handleOpenTag;
    /** `<FRAME name [action] [internal|external|floating] [left|top|width|height]
     *  [scrolling] [title]>` — record a window create/close request for the
     *  consumer. NAME is the first positional or the NAME attribute; valueless
     *  flags (INTERNAL/EXTERNAL/FLOATING) become `"true"`. */
    private handleFrameTag;
    /** `<DEST name [eol] [eof]>` — start redirecting enclosed text into `name`.
     *  NAME is the NAME attribute or the first non-flag positional. Persists
     *  until `</DEST>` (or end of line). A nameless DEST is ignored so its text
     *  renders inline, matching Mudlet (setMxpDestination fails → not handled). */
    private handleDestTag;
    /** Finalize the current `<DEST>` run into a redirect and stop redirecting. */
    private closeDest;
    private openFormat;
    private openColor;
    private openLink;
    private openVar;
    private handleCloseTag;
    private finalizeTag;
    private handleDefinition;
    private defineElement;
    private defineEntity;
    private expandElement;
    private substituteTemplate;
    private decodeEntity;
}
/** Split a parsed MXP line into one entry per *visual* line. MXP `<BR>` tags
 *  become embedded `\n`s in the parser's plain text and segments — Discworld
 *  sends a whole room (description, exits, contents, prompt) as a single network
 *  line delimited by `<BR>` — but a render path that emits one line per result
 *  would collapse them all together. So we split the segments at every `\n`,
 *  re-slicing each segment's text and remapping each link's `plain`-offset range
 *  into the subline it falls on. The `\n` separators are dropped (each subline
 *  renders on its own). The fast path (no embedded newline) returns the result
 *  untouched, sharing the original arrays. */
export declare function splitMxpResultLines(r: MxpLineResult): {
    plain: string;
    segments: BufferSegment[];
    links: MxpLink[];
}[];
