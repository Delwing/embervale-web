import type { PackageManifest } from '../storage/schema';
import { type MudletProfileImport, type MudletModuleRef } from './mudletHost';
export interface MudletProfileBundle {
    /** Profile name — `<Host><name>`, else the profile folder name, else fallback. */
    name: string;
    /** MUD address from `<Host>` (`<url>`/`<port>`), if present. */
    host?: string;
    port?: number;
    /** Parsed settings + automation + variables from the newest current/*.xml. */
    profile: MudletProfileImport;
    /** Manifests for the profile's installed packages (from <mInstalledPackages>,
     *  metadata from each package's config.lua). Registered on import so
     *  getPackageInfo / package managers see them as installed. */
    packages: PackageManifest[];
    /** Modules the profile loads from external local XML files — unresolvable in a
     *  browser; the import UI asks the user to upload or drop each. */
    modules: MudletModuleRef[];
    /** Newest map/* binary, ready for mapStorage. Undefined if the profile has no map. */
    mapBytes?: Uint8Array;
    /** Remaining profile-root files to copy into the new VFS (packages, fonts,
     *  sounds, …), keyed relative to the profile root. Excludes current/ and map/. */
    files: Record<string, Uint8Array>;
}
/**
 * Build a manifest per installed package, reading metadata from each package's
 * config.lua via `readConfig(name)` (returns the file text or undefined).
 * `installedAt` is left empty for the caller to stamp (keeps this deterministic).
 * Reusable across the file-map import path and the linked-folder (VFS) path.
 */
export declare function buildPackageManifests(names: string[], readConfig: (name: string) => string | undefined): PackageManifest[];
/**
 * Build a profile bundle from a Mudlet profile's files. `fallbackName` is used
 * when neither the Host `<name>` nor a wrapping folder name is available.
 * `mtimes` (keyed the same as `files`) makes the newest-save selection match
 * Mudlet's (most-recently-modified wins); without it, a deterministic fallback
 * prefers `current/autosave.xml` then the latest timestamp filename.
 * Throws if no `current/*.xml` is present (not a Mudlet profile).
 */
export declare function buildMudletProfileBundle(files: Record<string, Uint8Array>, fallbackName?: string, mtimes?: Record<string, number>): MudletProfileBundle;
/** Build a profile bundle from a `.zip` of a Mudlet profile directory. (Zip
 *  entry mtimes aren't surfaced, so newest-save uses the autosave/timestamp
 *  fallback.) */
export declare function extractMudletProfileZip(bytes: Uint8Array, fallbackName?: string): MudletProfileBundle;
export interface ResolvedModule {
    ref: MudletModuleRef;
    xmlBytes: Uint8Array;
}
/** Split a bundle's modules into those whose XML was found in the imported tree
 *  (by filename) and those still missing. */
export declare function resolveModulesFromTree(bundle: MudletProfileBundle): {
    resolved: ResolvedModule[];
    unresolved: MudletModuleRef[];
};
/**
 * Fold a resolved/uploaded module's XML into the bundle: its triggers/aliases/…
 * are parsed (grouped + tagged under the module key, so it's a removable unit)
 * and appended to the automation, and a manifest is registered. Mutates and
 * returns the bundle. Treated as a package — the live-sync-to-disk behaviour
 * doesn't apply in a browser.
 */
export declare function addModuleToBundle(bundle: MudletProfileBundle, key: string, xmlBytes: Uint8Array): MudletProfileBundle;
