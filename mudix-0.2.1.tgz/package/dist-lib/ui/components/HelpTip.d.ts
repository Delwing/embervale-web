import { type ReactNode } from 'react';
interface HelpTipProps {
    label?: string;
    children: ReactNode;
}
export declare function HelpTip({ label, children }: HelpTipProps): import("react/jsx-runtime").JSX.Element;
export {};
