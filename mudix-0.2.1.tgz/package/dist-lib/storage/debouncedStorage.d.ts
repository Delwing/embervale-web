import type { PersistStorage } from 'zustand/middleware';
/**
 * Zustand PersistStorage adapter that coalesces rapid mutations into a single
 * write — *including* the JSON serialization step.
 *
 * Using `createJSONStorage` over a debounced Web-Storage wrapper only collapses
 * the localStorage.setItem call; zustand still runs `JSON.stringify(state)`
 * before each setItem, so N mutations cost N full serializations of the
 * persisted blob (scripts, triggers, packages, …). Implementing PersistStorage
 * directly lets us hold the unserialized object and stringify exactly once,
 * at flush time.
 *
 * The latest pending value is flushed synchronously on `pagehide`,
 * `visibilitychange→hidden`, and `beforeunload` so a tab close right after a
 * mutation doesn't lose state. `getItem` honours an in-flight pending value so
 * the adapter is internally consistent even mid-debounce.
 */
export declare function createDebouncedJsonStorage<S>(delayMs: number): PersistStorage<S>;
