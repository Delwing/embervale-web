import type { EventBus } from "../../core/EventBus";
import type { MudClientEvents } from "../events";
export interface TelnetNegotiatorFlags {
    gmcpEnabled: boolean;
    mttsEnabled: boolean;
    msdpEnabled: boolean;
    msspEnabled: boolean;
    charsetEnabled: boolean;
    mspEnabled: boolean;
    mxpEnabled: boolean;
    mnesEnabled: boolean;
    newEnvironEnabled: boolean;
    nawsEnabled: boolean;
    /** Whether the game-facing transport is TLS (MTTS SSL bit, NEW-ENVIRON TLS var). */
    secureTransport: boolean;
}
export interface TelnetNegotiatorHooks {
    sendRaw(data: string): void;
    /** GMCP came up — send the Core.Hello / Core.Supports.Set handshake
     *  (latched by the owner so a re-offer doesn't re-announce). */
    onGmcpNegotiated(): void;
    /** CHARSET came up — kick off the client-driven REQUEST listing our
     *  preferred encodings. */
    onCharsetNegotiated(): void;
    /** Current inbound encoding (IANA label) — drives the MTTS UTF-8 bit and
     *  the MNES/NEW-ENVIRON CHARSET variable. */
    getEncoding(): string;
}
/**
 * Telnet option negotiation for a MUD session. Owns the WILL/WONT/DO/DONT
 * response policy, the per-session negotiation latches (TTYPE cycle position,
 * MXP started, NAWS accepted), the Mudlet `addSupportedTelnetOption` registry,
 * and the `telnet.event` (sysTelnetEvent) surface for everything unrecognized.
 *
 * `processFrame` makes a single position-aware walk over each incoming frame's
 * IAC sequences — skipping subnegotiation payloads and escaped `IAC IAC` bytes
 * so data bytes can't be mistaken for negotiation commands — and buffers a
 * trailing incomplete sequence for the next frame. Subnegotiation *bodies*
 * (SB … SE payloads) are not parsed here; they arrive via the handleXxxSubneg
 * methods, routed by MudClient's option parser.
 */
export declare class TelnetNegotiator {
    private readonly flags;
    private readonly eventBus;
    private readonly hooks;
    /** Mudlet `addSupportedTelnetOption(option)` registry. On IAC WILL <opt>
     *  we reply IAC DO <opt>; on IAC DO <opt> we reply IAC WILL <opt>. Options
     *  negotiated natively (GMCP/MSDP/TTYPE/…) are excluded — they have their
     *  own response logic. Survives reconnects (matches the old client-field
     *  lifetime: the registry lives as long as the client instance). */
    private readonly supportedTelnetOptions;
    /** Per-incoming-frame dedupe. Keys below 0x100 mark a natively-handled
     *  option as already answered this frame (mirroring the old one-response-
     *  per-frame `includes()` behavior); keys `(cmd << 8) | opt` mark a
     *  `telnet.event` as already raised. Telnet sequences can repeat across
     *  frames, so we only suppress duplicates within a single frame to avoid
     *  event storms. */
    private readonly frameSeen;
    /** Trailing bytes of a frame that might be the start of a split IAC
     *  sequence (a bare IAC, IAC WILL with no option byte yet, or an IAC SB
     *  whose IAC SE hasn't arrived) — prepended to the next frame so
     *  negotiation commands split across WebSocket frames aren't missed. */
    private carry;
    /** MTTS cycle position. The server issues SB TTYPE SEND repeatedly; we walk
     *  through client name (0), terminal type (1), then the MTTS bitvector (2+).
     *  Reset on each connect(). */
    private ttypeStep;
    /** Latches true once MXP has started for this session — via telnet option 91
     *  negotiation OR by detecting an in-band MXP line-mode sequence (`ESC[<n>z`).
     *  Many MUDs enable MXP server-side and just start streaming tags without the
     *  telnet handshake, so the in-band signal is the reliable trigger. Reset on
     *  each connect(). */
    private mxpStarted;
    /** True once we've sent IAC WILL NAWS this session (proactively on connect,
     *  or in response to a server-initiated IAC DO NAWS), so we don't re-offer. */
    private nawsWillSent;
    /** True once the server has accepted NAWS (IAC DO NAWS). Gates whether a
     *  window-size change is pushed to the server. */
    private nawsNegotiated;
    /** Latest known main output window size in character columns × rows, fed in
     *  by the session's resize observer via setWindowSize(). Null until the UI
     *  has measured the grid at least once. Deliberately NOT cleared by reset()
     *  so a reconnect keeps reporting the current grid. */
    private windowSize;
    constructor(flags: TelnetNegotiatorFlags, eventBus: EventBus<MudClientEvents>, hooks: TelnetNegotiatorHooks);
    /** Clear the per-connection latches (call on connect). */
    reset(): void;
    /** The WebSocket handshake completed — proactively offer NAWS (RFC 1073
     *  has the window-owning side send WILL). The server replies IAC DO NAWS —
     *  handled in processFrame — at which point we send the actual dimensions.
     *  Harmless if the server doesn't support it (it answers DONT or ignores us). */
    onSocketOpen(): void;
    /** Mudlet `addSupportedTelnetOption(option)`. Marks the telnet option byte
     *  (0..255) as one the client will accept: on the next IAC WILL <opt> we
     *  reply IAC DO <opt>; on IAC DO <opt> we reply IAC WILL <opt>. Natively
     *  negotiated options (GMCP=201, MSDP=69, TTYPE=24, …) don't need to be
     *  registered. Returns true if the option was newly added, false if it was
     *  already present. */
    addSupportedTelnetOption(option: number): boolean;
    /** Record the main output window's character grid (columns × rows) for NAWS.
     *  The value is stored regardless of negotiation state (so a client created
     *  on a later connect can be seeded with the current size); it's only sent
     *  to the server once NAWS has been negotiated, and only when it changed. */
    setWindowSize(cols: number, rows: number): void;
    /** Walk one incoming frame (post-MCCP Latin-1 byte-string) for telnet IAC
     *  sequences: answer WILL/WONT/DO/DONT per the option policy, auto-respond
     *  to registered supported options, raise `telnet.event` for everything
     *  else (including SB of unrecognized options), and watch for in-band MXP
     *  line-mode sequences on servers that skip the option-91 handshake. */
    processFrame(data: string): void;
    /** One WILL/WONT/DO/DONT for `opt`. Natively-handled options are answered
     *  at most once per frame (matching the old `includes()`-based scan); the
     *  supported-options registry answers every occurrence; anything left is
     *  surfaced as a `telnet.event`. */
    private handleNegotiationCommand;
    private respondToKnownOption;
    /** Raise `telnet.event` for an SB of an option we neither handle natively
     *  nor auto-negotiate (type 5 in Mudlet's sysTelnetEvent mapping). */
    private noticeSubnegotiation;
    /** `type` mirrors Mudlet's TLuaInterpreter mapping: 1=WILL, 2=WONT, 3=DO,
     *  4=DONT, 5=SB. Deduped per (command, option) within the frame so a server
     *  that spams the same option doesn't flood handlers. */
    private emitTelnetEvent;
    /** Reply to a TERMINAL-TYPE / MTTS subnegotiation. `subneg` is the SB body
     *  with the option byte (24) at [0]; [1] is the request kind (1 = SEND). We
     *  answer `IAC SB TTYPE IS <value> IAC SE`, cycling client name → terminal
     *  type → MTTS capability bitvector on successive SENDs, then repeating the
     *  last value to signal the list is exhausted (RFC 1091 + the MTTS standard). */
    handleTtypeSubneg(subneg: string): void;
    /** Handle an `IAC SB MXP IAC SE` subnegotiation. Per spec it carries no
     *  payload — it merely confirms MXP is active — so we just start MXP. The
     *  actual MXP markup arrives in-band and is parsed downstream by the
     *  scripting engine. */
    handleMxpSubneg(): void;
    /** Answer an `IAC SB NEW-ENVIRON SEND … IAC SE` request, framed as
     *  `IAC SB NEW-ENVIRON IS <marker> … VALUE … IAC SE`. Telnet option 39 is
     *  shared by two modes: MNES reports the five core variables framed as VAR;
     *  plain NEW-ENVIRON reports the core set plus an extended capability set,
     *  framed as USERVAR. MNES takes precedence when both toggles are on
     *  (matching Mudlet). The server may request specific variables or send a
     *  bare SEND for all; selectMnesVars handles both. No-op when the option is
     *  off for this profile or on a malformed/non-SEND body. */
    handleNewEnvironSubneg(subneg: string): void;
    /** Build the option-39 variable set from live client state. CHARSET tracks
     *  the negotiated encoding; the extended NEW-ENVIRON capabilities derive from
     *  the game-facing transport (TLS — false in proxy mode) and the measured
     *  output grid (WORD_WRAP). The static identity (CLIENT_NAME/VERSION, MTTS,
     *  TERMINAL_TYPE) and the capability defaults live in buildNewEnvironVars. */
    private collectNewEnvironVars;
    /** Latch MXP on for this session and notify listeners. Idempotent — only the
     *  first call emits `mxp.negotiated`; later calls (repeat WILL/DO, in-band
     *  detection on subsequent frames) are no-ops. `viaTelnet` distinguishes a
     *  real option-91 handshake from in-band-only detection (see the event doc). */
    private startMxp;
    /** Send the current window size as an `IAC SB NAWS … IAC SE` subnegotiation.
     *  Falls back to a conventional 80×24 terminal default when the UI hasn't
     *  reported a real size yet — better than the NAWS 0×0 "no preference"
     *  sentinel, which some servers treat as "disable wrapping". */
    private sendNawsSize;
}
