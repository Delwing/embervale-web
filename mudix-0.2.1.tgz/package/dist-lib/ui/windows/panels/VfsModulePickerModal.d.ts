import type { ProfileVFS } from '../../../scripting/vfs/ProfileVFS';
interface Props {
    vfs: ProfileVFS;
    onClose: () => void;
    onPick: (absolutePath: string) => void;
}
export declare function VfsModulePickerModal({ vfs, onClose, onPick }: Props): import("react/jsx-runtime").JSX.Element;
export {};
