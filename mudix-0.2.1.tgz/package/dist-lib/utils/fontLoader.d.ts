import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
import type { OutputFontSource } from '../storage';
/** Synchronous detection. May false-negative on a system font whose face the
 *  browser hasn't materialized yet — use {@link ensureFontAvailable} when an
 *  await is acceptable. */
export declare function isFontAvailable(family: string): boolean;
/** Async variant: nudges the browser via document.fonts.load() first (this
 *  causes Chrome to materialize an installed system face into the FontFaceSet
 *  so subsequent measurements can see it), then measures via the DOM probe. */
export declare function ensureFontAvailable(family: string): Promise<boolean>;
export interface FontProbeRow {
    fallback: string;
    baselineWidth: number;
    candidateWidth: number;
    diverges: boolean;
}
export interface FontProbeReport {
    family: string;
    text: string;
    fontSizePx: number;
    rows: FontProbeRow[];
    available: boolean;
    fontsCheckSays: boolean;
    fontsLoadFaces: number;
    fontFamiliesInSet: number;
}
/** Run the probe and return raw measurements for debugging the detector. */
export declare function diagnoseFontProbe(family: string): Promise<FontProbeReport>;
export interface LocalFontEntry {
    family: string;
    fullName: string;
    postscriptName: string;
    style?: string;
}
export declare function isLocalFontApiSupported(): boolean;
export declare function queryLocalFonts(): Promise<LocalFontEntry[]>;
export declare function getUniversalDefaultFonts(): readonly string[];
export declare function getCachedLocalFonts(): string[];
export declare function setLocalFontsCache(families: Iterable<string>): void;
/** Fire-and-forget. If Local Font Access is supported AND permission was
 *  previously granted, query installed fonts and cache the family list.
 *  Never prompts the user. Idempotent: subsequent calls before the first
 *  resolves piggy-back on the in-flight promise. */
export declare function primeLocalFontsCache(): Promise<void>;
/** Families currently registered in document.fonts — URL stylesheets and
 *  FontFace-API uploads (the kind loaded by loadFontFromUrl / loadFontFromVfs)
 *  show up here once the browser has materialized the face. Quoted-string
 *  forms ("Family Name") are unwrapped to plain names. */
export declare function getRegisteredFontFamilies(): string[];
export declare function loadFontFromUrl(family: string, url: string): Promise<void>;
export declare function loadFontFromVfs(family: string, path: string, vfs: ProfileVFS): Promise<void>;
export declare function applyOutputFont(font: OutputFontSource | undefined, vfs: ProfileVFS | null): Promise<void>;
