export interface GmcpEnvelope {
    path: string;
    value: unknown;
}
export type TelnetOptionHandler = (data: string) => string;
export declare const createTelnetOptionParser: (onSubnegotiation: (data: string) => void) => TelnetOptionHandler;
export declare const stripTelnetSequences: (data: string, handler: TelnetOptionHandler) => string;
export declare const encodeGmcp: (path: string, payload: unknown) => string;
/** Encode a GMCP frame from a single pre-formatted body (e.g. `"Module.Sub args"`).
 *  Matches Mudlet's `sendGMCP` semantics — the caller controls the exact bytes
 *  between IAC SB GMCP and IAC SE. */
export declare const encodeGmcpRaw: (message: string) => string;
export interface GmcpStreamOptions {
    onEnvelope: (payload: GmcpEnvelope) => void;
    /** Called for gmcp_msgs subnegotiations (base64-encoded text with a type field). */
    onMessage?: (text: string, type: string) => void;
    /** Text decoder used for gmcp_msgs payloads. Defaults to UTF-8. */
    textEncoding?: string;
}
export declare const createGmcpStream: ({ onEnvelope, onMessage, textEncoding, }: GmcpStreamOptions) => (data: string) => void;
