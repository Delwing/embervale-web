export interface LabelCreateOptions {
    /** Parent window id ('main' for main viewport). Defaults to 'main'. */
    parent?: string;
    x: number;
    y: number;
    width: number;
    height: number;
    /** Whether to draw the label's background fill. */
    fillBackground: boolean;
    /** Whether clicks pass through to whatever is underneath. */
    clickThrough?: boolean;
}
export interface LabelState {
    name: string;
    parent: string;
    x: number;
    y: number;
    width: number;
    height: number;
    fillBackground: boolean;
    clickThrough: boolean;
    visible: boolean;
    /** Inner HTML content set via echo()/setLabelText. */
    html: string;
    /** rgba 0..255 channels; alpha defaults to 255 when set via setBackgroundColor. */
    backgroundColor?: {
        r: number;
        g: number;
        b: number;
        a: number;
    };
    /** Mudlet setBackgroundImage(labelName, imageLocation) — resolved CSS URL.
     *  Labels have no `mode` (unlike consoles); always rendered as a centered
     *  no-repeat background, matching Mudlet's QLabel default. */
    backgroundImage?: {
        url: string;
    };
    /** Qt-style CSS string set via setLabelStyleSheet; parsed at render time. */
    styleSheet?: string;
    /** Mudlet setLinkStyle(labelName, linkColor, linkVisitedColor, underline) —
     *  styling for `<a>` links inside the label's HTML. Cleared by
     *  resetLinkStyle. Colors are any CSS color string (empty = leave default). */
    linkStyle?: {
        color?: string;
        visitedColor?: string;
        underline: boolean;
    };
    /** Click handler installed by setLabelClickCallback. The event table mirrors
     *  Mudlet's `mudlet.mouse_button` shape: `{button, x, y, alt, ctrl, shift, meta}`. */
    onClick?: (event: LabelMouseEvent) => void;
    /** Pointer down (Mudlet release callback fires on mouseup; press is implicit). */
    onMouseDown?: (event: LabelMouseEvent) => void;
    /** Pointer up — Mudlet setLabelReleaseCallback. */
    onMouseUp?: (event: LabelMouseEvent) => void;
    /** Double-click — Mudlet setLabelDoubleClickCallback. */
    onDoubleClick?: (event: LabelMouseEvent) => void;
    /** Pointer move — Mudlet setLabelMoveCallback. */
    onMouseMove?: (event: LabelMouseEvent) => void;
    /** Wheel — Mudlet setLabelWheelCallback. event.angleDelta carries the scroll. */
    onWheel?: (event: LabelWheelEvent) => void;
    /** Pointer enter — Mudlet setLabelOnEnter. */
    onMouseEnter?: (event: LabelMouseEvent) => void;
    /** Pointer leave — Mudlet setLabelOnLeave. */
    onMouseLeave?: (event: LabelMouseEvent) => void;
    /** Tooltip text rendered via the title attribute. */
    tooltip?: string;
    /** CSS cursor value (e.g. 'pointer', 'crosshair', 'none'). */
    cursor?: string;
    /** z-index applied to the label DIV. Higher = on top of other labels. */
    zIndex?: number;
}
/** Event payload for label mouse callbacks. `button` is the Qt button *name*
 *  Mudlet reports ("LeftButton" / "RightButton" / "MidButton" / "NoButton" / …),
 *  so ported Geyser scripts that branch on `event.button == "LeftButton"` work. */
export interface LabelMouseEvent {
    button: string;
    x: number;
    y: number;
    globalX: number;
    globalY: number;
    alt: boolean;
    ctrl: boolean;
    shift: boolean;
    meta: boolean;
}
export interface LabelWheelEvent extends LabelMouseEvent {
    /** Mudlet exposes wheel deltas via `angleDelta.x` / `angleDelta.y` (Qt naming). */
    angleDelta: {
        x: number;
        y: number;
    };
}
type Listener = (labels: LabelState[]) => void;
export declare class LabelManager {
    private readonly labels;
    private readonly listeners;
    private nextRaiseZ;
    private nextLowerZ;
    /** Returns true if a new label was created. Mudlet's createLabel returns
     *  false when a label with the same name already exists. */
    create(name: string, opts: LabelCreateOptions): boolean;
    has(name: string): boolean;
    destroy(name: string): boolean;
    move(name: string, x: number, y: number): boolean;
    resize(name: string, width: number, height: number): boolean;
    /** Mudlet `getLabelSizeHint(name)` → the label's preferred `{width,height}`.
     *  Mudlet returns the QLabel sizeHint (the size its content wants); the
     *  browser analogue is the rendered node's content extent
     *  (`scrollWidth`/`scrollHeight`), read off the `data-mudix-label` element.
     *  Falls back to the configured geometry when the label isn't in the DOM
     *  yet (hidden, or rendered before mount). null when no such label. */
    getSizeHint(name: string): {
        width: number;
        height: number;
    } | null;
    show(name: string): boolean;
    hide(name: string): boolean;
    setHtml(name: string, html: string): boolean;
    setBackgroundColor(name: string, r: number, g: number, b: number, a?: number): boolean;
    getBackgroundColor(name: string): {
        r: number;
        g: number;
        b: number;
        a: number;
    } | null;
    setBackgroundImage(name: string, url: string): boolean;
    resetBackgroundImage(name: string): boolean;
    setStyleSheet(name: string, css: string): boolean;
    /** Mudlet `setLinkStyle(labelName, linkColor, linkVisitedColor, underline)`. */
    setLinkStyle(name: string, color: string, visitedColor: string, underline: boolean): boolean;
    /** Mudlet `resetLinkStyle(labelName)` — drop any setLinkStyle override. */
    resetLinkStyle(name: string): boolean;
    /** Mudlet `getLabelStyleSheet(name)` — the Qt-style CSS last set via
     *  {@link setStyleSheet}, or `""` when none is set. Returns `undefined`
     *  when the label doesn't exist so the caller can distinguish that case. */
    getStyleSheet(name: string): string | undefined;
    setClickCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseUpCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setDoubleClickCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseMoveCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setWheelCallback(name: string, fn: ((e: LabelWheelEvent) => void) | undefined): boolean;
    setMouseEnterCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setMouseLeaveCallback(name: string, fn: ((e: LabelMouseEvent) => void) | undefined): boolean;
    setTooltip(name: string, text: string | undefined): boolean;
    setClickThrough(name: string, value: boolean): boolean;
    setCursor(name: string, cursor: string | undefined): boolean;
    raise(name: string): boolean;
    lower(name: string): boolean;
    list(parent: string): LabelState[];
    subscribe(parent: string, fn: Listener): () => void;
    clearAll(): void;
    private notify;
}
export {};
