import { type OscPaletteOp } from "./ansiEscapes";
import { HyperlinkPresetRegistry, type HyperlinkConfig } from "./hyperlinkConfig";
/** Apply OSC 4/104 palette operations to the global colour tables. Palette
 *  changes affect text parsed *after* this point — which is exactly document
 *  order, since lines are fed to the parser in the order the server sent them. */
export declare function applyOscPaletteOps(ops: ReadonlyArray<OscPaletteOp>): void;
export interface FormatHyperlink {
    onClick?: (ev: MouseEvent) => void;
    onContextMenu?: (ev: MouseEvent) => void;
    onMouseEnter?: (ev: MouseEvent) => void;
    onMouseLeave?: (ev: MouseEvent) => void;
    title?: string;
    /**
     * Raw link target recorded by the low-level ANSI parser for OSC 8 links.
     * The parser has no access to the scripting API, so it stores the URI here
     * and the engine later wires the click behaviour via `bindUrlHyperlinks`.
     * For OSC 8 links this is the *cleaned* command (extension query stripped).
     */
    url?: string;
    /** Parsed Mudlet OSC 8 extension config (styling, states, tooltip, menu,
     *  spoiler, disabled, visibility, selection), resolved at parse time. */
    config?: HyperlinkConfig;
    /** OSC 8 `id=` parameter — groups split runs of one logical link so hover
     *  can highlight them together. */
    linkId?: string;
    /**
     * Document-style link that should render with an underline cue by default,
     * the way a web browser underlines anchors. Set on MXP `<send>`/`<a>` links
     * and OSC 8 hyperlinks. Scripted Mudlet-API links (`echoLink`, `echoPopup`,
     * `setLink`) leave this unset — they underline only when the script sets the
     * real `underline` attribute (Mudlet's `useCurrentFormat=false` default), so
     * a `useCurrentFormat=true` link keeps the current pen with no underline.
     */
    autoUnderline?: boolean;
}
export interface IndexedColor {
    space: "indexed";
    index: number;
}
export interface RgbColor {
    space: "rgb";
    r: number;
    g: number;
    b: number;
    a?: number;
}
export interface HexColor {
    space: "hex";
    color: string;
}
export type FormatColor = IndexedColor | RgbColor | HexColor;
export type DimEasing = 'linear' | 'ease' | 'ease-in' | 'ease-out' | 'ease-in-out';
export interface DimEffect {
    startOpacity: number;
    endOpacity: number;
    duration: number;
    easing?: DimEasing;
}
export interface FormatStateSnapshot {
    foreground?: FormatColor;
    background?: FormatColor;
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
    inverse?: boolean;
    strikethrough?: boolean;
    overline?: boolean;
    slowBlink?: boolean;
    rapidBlink?: boolean;
    dim?: DimEffect;
    hyperlink?: FormatHyperlink;
    cssClass?: string;
}
export type TextRange = [start: number, end: number];
export interface BufferSegment {
    text: string;
    state?: FormatStateSnapshot;
}
declare function cloneState(state?: FormatStateSnapshot): FormatStateSnapshot | undefined;
declare function statesEqual(a?: FormatStateSnapshot, b?: FormatStateSnapshot): boolean;
export declare class FormatState {
    static DEFAULT: {};
    foreground?: FormatColor;
    background?: FormatColor;
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
    inverse?: boolean;
    strikethrough?: boolean;
    overline?: boolean;
    slowBlink?: boolean;
    rapidBlink?: boolean;
    dim?: DimEffect;
    hyperlink?: FormatHyperlink;
    constructor(initial?: FormatStateSnapshot);
    private applySnapshot;
    reset(): void;
    toSnapshot(): FormatStateSnapshot;
    applySgr(params: number[]): void;
    setHyperlink(link?: FormatHyperlink): void;
}
/**
 * A run of text with its visual attributes resolved to concrete CSS colour
 * strings — the shape a canvas/image renderer wants. `color`/`background` are
 * undefined when the run uses the console default (the renderer fills in its
 * own default for those).
 */
export interface OutputStyledRun {
    text: string;
    color?: string;
    background?: string;
    bold: boolean;
    italic: boolean;
    underline: boolean;
}
/**
 * Buffer of text aware of ANSI formatting codes and hyperlink metadata.
 */
export declare class AnsiAwareBuffer {
    private segments;
    private _deleted;
    private _onRender?;
    private _textCache;
    private _renderContainer;
    constructor(initial?: string | BufferSegment[], state?: FormatStateSnapshot, presets?: HyperlinkPresetRegistry);
    get deleted(): boolean;
    markAsDeleted(): this;
    /** Per-line prompt flag. Mudlet's TBuffer tracks isPrompt on each line so
     *  the matching `isPrompt()` script primitive reflects the prompt status of
     *  whatever line the cursor is currently on (not just the last). Set by the
     *  trigger pipeline before triggers run; defaults to false. */
    isPrompt: boolean;
    /** Wall-clock time (epoch ms) the line was created. Mudlet stamps every
     *  buffer line with a QTime; `getTimestamp(lineNumber)` reads it back. A
     *  buffer is built right as its line is echoed/received, so construction
     *  time is the line's timestamp. */
    timestamp: number;
    removeFromDom(): void;
    onRender(callback: (container: HTMLElement) => void): this;
    /** @internal */
    notifyRender(container: HTMLElement): void;
    /** Re-renders the buffer into its previously notified container. No-op if not yet rendered. */
    rerender(): void;
    /** Removes all formatting from a range (clears colors, bold, etc.). */
    clearFormat(range: TextRange): this;
    clone(): AnsiAwareBuffer;
    get text(): string;
    get length(): number;
    clear(): this;
    replace(range: [number, number], text: string, state?: FormatStateSnapshot): this;
    replaceBuffer(range: [number, number], buffer: AnsiAwareBuffer): this;
    insert(index: number, text: string, state?: FormatStateSnapshot): this;
    insertBuffer(index: number, buffer: AnsiAwareBuffer): this;
    prefix(text: string, state?: FormatStateSnapshot): this;
    suffix(text: string, state?: FormatStateSnapshot): this;
    private insertInternal;
    append(text: string, state?: FormatStateSnapshot): this;
    appendBuffer(buffer: AnsiAwareBuffer): this;
    prepend(text: string, state?: FormatStateSnapshot): this;
    prependBuffer(buffer: AnsiAwareBuffer): this;
    remove(range: [number, number]): this;
    /** @internal */
    getSegments(): BufferSegment[];
    toHyperlinkSegments(): {
        text: string;
        hyperlink?: FormatHyperlink;
    }[];
    color(range: TextRange, color: number | FormatStateSnapshot): this;
    applyFormat(range: TextRange, format: FormatStateSnapshot): this;
    /**
     * Overlays a hyperlink on every segment in `range`, preserving each
     * segment's existing colors/attributes. Pass `undefined` to clear any
     * hyperlinks in the range. Unlike `applyFormat` (which homogenizes
     * formatting across the range), this is segment-wise — used by Mudlet
     * `setLink` so coloured selections remain coloured after becoming clickable.
     */
    setHyperlink(range: TextRange, hyperlink?: FormatHyperlink): this;
    /**
     * Wire deferred URL hyperlinks (recorded by the ANSI parser for OSC 8 links
     * as a bare `url` with no handlers) into live, clickable links. `factory`
     * turns a URI into a {@link FormatHyperlink} with the right click behaviour
     * (or `undefined` to drop the link). Segments that already have a handler —
     * e.g. an MXP `<SEND>` link overlaid on the same range — are left alone.
     */
    bindUrlHyperlinks(factory: (url: string, link: FormatHyperlink) => FormatHyperlink | undefined): this;
    colorWords(words: string | string[], color: number | FormatStateSnapshot, options?: {
        caseInsensitive?: boolean;
    }): this;
    splitLines(): AnsiAwareBuffer[];
    /** Returns the format state at the end of this buffer, for carrying into the next line. */
    trailingState(): FormatStateSnapshot | undefined;
    /**
     * Build the CSS visual declarations (colour, weight, decorations) for a
     * segment. When `overlay` is given (an OSC 8 link style for a state), its set
     * fields win over the segment's own SGR attributes — that's how a link's
     * configured colour/decoration paints over the underlying run. With no
     * overlay this reproduces the plain SGR rendering exactly.
     */
    private visualDecls;
    toHtml(): string;
    /**
     * Resolve the buffer's segments to styled runs with concrete CSS colours,
     * for rendering to a canvas (copy-as-image). Mirrors {@link toHtml}'s colour
     * handling, including reverse-video on default colours — there the swap
     * yields no explicit colour, so we hand back the console default of the
     * opposite role for the renderer to paint.
     */
    toStyledRuns(): OutputStyledRun[];
    toDom(): DocumentFragment;
    private escapeHtml;
    private colorToHex;
    private prepareStyle;
    private appendSegmentAtEnd;
    private createSegmentsFromText;
    private resolveIndex;
    private resolveBoundaryIndex;
    private inferState;
    private splitSegment;
    private normalizeSegments;
    private assertRange;
    getStateAt(index: number): FormatStateSnapshot | undefined;
    applyMudletColors(): this;
    createLink(range: TextRange, options: {
        onClick?: (ev: MouseEvent) => void;
        onContextMenu?: (ev: MouseEvent) => void;
        onMouseEnter?: (ev: MouseEvent) => void;
        onMouseLeave?: (ev: MouseEvent) => void;
        title?: string;
    }): this;
    createLinksForText(text: string, options: {
        onClick?: (ev: MouseEvent) => void;
        onContextMenu?: (ev: MouseEvent) => void;
        onMouseEnter?: (ev: MouseEvent) => void;
        onMouseLeave?: (ev: MouseEvent) => void;
        title?: string;
    }, searchOptions?: {
        caseInsensitive?: boolean;
    }): this;
    private assertIndex;
}
export { cloneState as cloneFormatState, statesEqual as formatStatesEqual };
/**
 * Walks ANSI SGR escapes in `text` starting from `baseState` and returns the
 * SGR state that would apply *after* the last byte of `text`. Unlike
 * `AnsiAwareBuffer.trailingState()` (which returns the state of the last
 * non-empty text segment), this reflects the actual end-of-stream state:
 *   - empty `text` → returns `baseState`, so blank lines preserve carry
 *   - text ending in `\e[0m` → returns default (undefined), not the pre-reset color
 *   - text with no ANSI codes → returns `baseState` unchanged
 * Used to carry SGR state across line breaks the way Mudlet's TBuffer does.
 */
export declare function computeTrailingState(text: string, baseState?: FormatStateSnapshot): FormatStateSnapshot | undefined;
