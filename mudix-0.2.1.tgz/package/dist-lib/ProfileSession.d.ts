import { type MudConnection } from './storage';
import type { ProfileVFS } from './scripting/vfs/ProfileVFS';
interface Props {
    connection: MudConnection;
    /** If true, dial the WebSocket on mount. Offline mode skips this. */
    autoConnect: boolean;
    /** The profile's VFS, mounted by App before this renders. Available
     *  synchronously here (and to children), so first-render reads see it. */
    vfs: ProfileVFS | null;
    settingsOpen: boolean;
    onToggleSettings: () => void;
    onCloseProfile: () => void;
}
export declare function ProfileSession({ connection, autoConnect, vfs, settingsOpen, onToggleSettings, onCloseProfile }: Props): import("react/jsx-runtime").JSX.Element;
export {};
