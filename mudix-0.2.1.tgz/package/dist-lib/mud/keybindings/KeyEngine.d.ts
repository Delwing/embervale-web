import type { KeyNode } from '../../storage/schema';
export type { KeyNode };
type TempFn = () => void;
/** Mudlet getKeyCode() result — a Qt::Key integer + Qt::KeyboardModifier mask. */
export interface KeyCodeInfo {
    keyCode: number;
    modifiers: number;
}
export declare class KeyEngine {
    private readonly temp;
    private perm;
    private nextId;
    /** Number of live session-scoped temp keys (Mudlet `getProfileStats` temp count). */
    get tempCount(): number;
    addTemp(key: string, modifiers: string[], fn: TempFn, qt?: {
        keyCode: number;
        modifier: number;
    }): number;
    /**
     * Mudlet getKeyCode(idOrName) lookup. A numeric id resolves a temp key; a
     * string resolves a permanent key by name. Returns the Qt key code + modifier
     * mask, or null when nothing matches (caller turns that into nil + errMsg).
     */
    getKeyCode(idOrName: number | string): KeyCodeInfo | null;
    killKey(id: number): boolean;
    processTemp(event: KeyboardEvent): boolean;
    loadPerm(keybindings: KeyNode[]): void;
    matchPerm(event: KeyboardEvent): KeyNode | null;
    destroy(): void;
}
