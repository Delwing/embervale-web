import type { DragState } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface DockedPanelProps {
    id: string;
    title: string;
    kind: 'text' | 'html' | 'map';
    manager: WindowManager;
    onHide: () => void;
    onDragStateChange: (ds: DragState | null) => void;
    onTitlebarContextMenu: (e: React.MouseEvent) => void;
}
export declare function DockedPanel({ id, title, manager, onHide, onDragStateChange, onTitlebarContextMenu }: DockedPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
