import type { MediaCaptionInfo } from '../sound/closedCaption';
type LoaderFn = (path: string) => Promise<ArrayBuffer | null>;
export interface PlayVideoOptions {
    name: string;
    /** 0..100 — Mudlet scale. Default 50. */
    volume?: number;
    /** Loop count. 1 = play once (default). -1 = infinite. */
    loops?: number;
    /** CSS units; default fills the viewport. */
    width?: string;
    height?: string;
    /** Optional closed-caption text (Mudlet's media `caption`). */
    caption?: string;
}
export declare class VideoManager {
    private loader;
    /** Returns the DOM element that videos should be attached to. Set by
     *  WindowManager.observeMain so videos drop onto the main viewport. */
    private getMount;
    private active;
    /** Buffers fetched ahead of play via loadVideoFile, keyed by VFS path. */
    private prefetched;
    /** Fires when a video ends naturally or is stopped — mirrors Mudlet's
     *  sysMediaFinished. */
    onEnded: ((name: string, path: string) => void) | null;
    /** Raised when a video starts ('plays') or finishes ('stops') so the engine
     *  can print a closed caption (Mudlet's enableClosedCaption). */
    onMediaCaption: ((info: MediaCaptionInfo) => void) | null;
    setLoader(fn: LoaderFn | null): void;
    setMountPoint(fn: (() => HTMLElement | null) | null): void;
    /**
     * Mudlet `loadVideoFile`. Preloads (fetches + caches) a VFS-backed video so
     * the first playVideoFile has no fetch latency. http(s)/data/blob URLs need
     * no preloading (the element fetches them directly) and report success.
     * Returns false when no loader is wired or the fetch fails.
     */
    preload(path: string): Promise<boolean>;
    play(path: string, opts: PlayVideoOptions): Promise<boolean>;
    pauseAll(): void;
    /**
     * Mudlet `getPlayingVideos([settings])` / `getPausedVideos([settings])`.
     * Lists the videos currently in the requested play state, optionally
     * filtered by name. Volume is reported on Mudlet's 0..100 scale.
     */
    getByState(wantPaused: boolean, filter?: {
        name?: string;
    }): Array<{
        name: string;
        path: string;
        volume: number;
    }>;
    stopAll(): void;
    private stopByName;
    destroy(): void;
}
export {};
