/**
 * Session-scoped state for stateful OSC 8 links — `selection` groups and
 * `:visited` tracking (Mudlet's selection manager + visited links).
 *
 * The styling itself is precomputed by the renderer and stashed on each link
 * element as `data-css-base` / `data-css-selected` / `data-css-visited`; this
 * manager only holds the *state* (which group values are selected, which links
 * have been activated) and re-applies the right stashed style to the live link
 * elements when state changes. Restyling queries the document, so it updates
 * every rendered run of a group across lines — not just the clicked one.
 */
export declare class OscLinkManager {
    /** group → set of currently-selected values. */
    private readonly selected;
    /** Activated link keys (the command URI), for `:visited` styling. */
    private readonly visited;
    isSelected(group: string, value: string): boolean;
    isVisited(key: string): boolean;
    /**
     * Toggle `(group, value)` and return its new selected state. `exclusive`
     * groups behave like radio buttons (one value at a time); non-exclusive like
     * checkboxes (independent toggles).
     */
    toggleSelection(group: string, value: string, exclusive: boolean): boolean;
    /** Seed an initially-selected value (server sent `selection.selected:true`). */
    select(group: string, value: string, exclusive: boolean): void;
    markVisited(key: string): void;
    /**
     * Re-apply the correct stashed style to every OSC link element under `root`,
     * based on current selection/visited state. Selection wins over visited.
     * No-op when `root` is null (e.g. a headless call with no DOM).
     */
    restyle(root: ParentNode | null | undefined): void;
    clear(): void;
}
