import type { MudletMap } from 'mudlet-map-binary-reader';
/**
 * Parse a Mudlet binary map off the main thread. The buffer is transferred —
 * caller must not reuse it after the call. Resolves with the parsed MudletMap
 * (deep-cloned by structured-clone on its way back).
 */
export declare function parseMapInWorker(buf: ArrayBuffer): Promise<MudletMap>;
/**
 * Serialise a MudletMap to the Mudlet binary `.dat` format off the main thread.
 * The map is structured-cloned to the worker (so the caller's object isn't
 * touched); the resulting bytes are transferred back as a standalone
 * ArrayBuffer the caller owns.
 */
export declare function serializeMapInWorker(map: MudletMap): Promise<ArrayBuffer>;
