export declare function encodeRowsToLuaSource(rows: unknown[][]): string;
