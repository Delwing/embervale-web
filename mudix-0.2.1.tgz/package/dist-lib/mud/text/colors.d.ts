export declare const colorCodes: {
    xterm: string[];
    ansi: {
        bright: string[];
        dark: string[];
    };
};
/** Built-in 16-color ANSI palette. Index 0–7 dark, 8–15 bright. The Settings
 *  modal uses this as the fallback when a profile hasn't overridden a slot. */
export declare const DEFAULT_ANSI_PALETTE: readonly string[];
/** Enable/disable server-driven OSC 4/104 palette redefinition. */
export declare function setServerRedefineColorsAllowed(allowed: boolean): void;
/** Whether the server is currently allowed to redefine palette colors. */
export declare function isServerRedefineColorsAllowed(): boolean;
/** Apply an override palette to the global ANSI table (mutates colorCodes.ansi
 *  in place so FormatState picks it up without plumbing). Pass `undefined` or
 *  a sparse array to restore defaults for unspecified / invalid slots. The
 *  palette layout is `[...dark(8), ...bright(8)]`. */
export declare function applyAnsiPalette(palette?: readonly (string | undefined)[]): void;
/**
 * OSC 4 palette redefinition: point colour index `index` (0–255) at `hex`
 * (`#rrggbb`). Indices 0–15 also update the 16-colour ANSI table so subsequent
 * SGR 30–37/40–47/90–107 pick up the change, keeping the two tables coherent.
 * Out-of-range indices and malformed colours are ignored.
 */
export declare function setPaletteColor(index: number, hex: string): void;
/** OSC 104 single-index reset: restore one palette entry to its base value (the
 *  user palette for 0–15, the built-in xterm default otherwise). */
export declare function resetPaletteColor(index: number): void;
/** OSC 104 with no index: restore the entire palette to its base state. */
export declare function resetAllPaletteColors(): void;
