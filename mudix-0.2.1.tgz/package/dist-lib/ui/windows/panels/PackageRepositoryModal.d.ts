import { type PackageRepoEntry } from '../../../import/packageRepository';
interface Props {
    /** Names of packages already installed on this profile — used to flag matching entries. */
    installedNames: Set<string>;
    /** Active proxy URL, used to retry catalog/download fetches when a direct fetch fails CORS. */
    proxyUrl?: string;
    onClose: () => void;
    /**
     * Called after the user clicks Install on an entry. The caller fetches/installs/commits
     * to the store — keeping that flow in ScriptEditorPanel means we don't need to plumb the
     * VFS, scripting engine, or store mutators through the modal.
     *
     * Must throw on failure so the modal can surface the error inline.
     */
    onInstall: (entry: PackageRepoEntry, bytes: Uint8Array) => Promise<void>;
}
export declare function PackageRepositoryModal({ installedNames, proxyUrl, onClose, onInstall }: Props): import("react/jsx-runtime").JSX.Element;
export {};
