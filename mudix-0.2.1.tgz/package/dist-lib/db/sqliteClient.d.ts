import { type SqlValue } from '@sqlite.org/sqlite-wasm';
type ExecResult = {
    kind: 'rows';
    rows: SqlValue[][];
    columns: string[];
} | {
    kind: 'changes';
    changes: number;
};
export declare const sqliteReady: Promise<void>;
export declare class SqliteClient {
    private readonly dbs;
    private readonly idByPath;
    private readonly pathById;
    private nextId;
    liveId(path: string): number | undefined;
    private get s();
    open(path: string, preload?: Uint8Array): number;
    exec(dbId: number, sql: string): ExecResult;
    exportFile(dbId: number): Uint8Array;
    close(dbId: number): void;
    escape(s: string): string;
}
export declare function getSqliteClient(): SqliteClient;
export {};
