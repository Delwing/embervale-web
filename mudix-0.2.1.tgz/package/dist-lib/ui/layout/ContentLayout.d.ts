import type { MudSession } from '../../mud/MudSession';
import type { WindowManager } from '../windows/WindowManager';
import type { ScriptingEngine } from '../../scripting/ScriptingEngine';
import type { ProfileVFS } from '../../scripting/vfs/ProfileVFS';
import './ScriptWindow.css';
interface ContentLayoutProps {
    session: MudSession;
    manager: WindowManager;
    connectionId: string;
    stickyLines?: number;
    commandInputRef?: React.RefObject<HTMLInputElement | HTMLTextAreaElement | null>;
    commandBar?: React.ReactNode;
    contextMenuHandlerRef?: React.RefObject<((e: React.MouseEvent) => void) | null>;
    /** Live ref so button clicks reach the engine even though the ref is set after initial render. */
    scriptingEngineRef?: React.RefObject<ScriptingEngine | null>;
    vfs?: ProfileVFS | null;
}
export declare function ContentLayout({ session, manager, connectionId, stickyLines, commandInputRef, commandBar, contextMenuHandlerRef, scriptingEngineRef, vfs, }: ContentLayoutProps): import("react/jsx-runtime").JSX.Element;
export {};
