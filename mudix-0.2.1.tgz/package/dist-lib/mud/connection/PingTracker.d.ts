export interface PingEventSource {
    on(event: 'gmcp.negotiated', handler: () => void): () => void;
    on(event: 'client.disconnect', handler: () => void): () => void;
    on(event: 'gmcp.core.ping', handler: () => void): () => void;
}
export declare class PingTracker {
    private readonly sendPingCommand;
    private readonly onPing;
    private timer;
    private probeTimer;
    private lastSentAt;
    private lastDuration;
    private supported;
    private readonly unsubs;
    constructor(sendPingCommand: () => void, onPing: (duration: number | null) => void, source: PingEventSource);
    destroy(): void;
    private probe;
    private start;
    private stop;
    private sendPing;
    private handlePingResponse;
}
