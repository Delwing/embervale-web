import type { MapState, SceneOverlay, SceneOverlayContext, Shape, ViewportBounds } from 'mudlet-map-renderer';
import type { MapStore } from './MapStore';
import type { MudixMapReader } from './MudixMapReader';
export declare class MapSelectionOverlay implements SceneOverlay {
    private readonly mapStore;
    private readonly reader;
    private ctx?;
    private mapStoreUnsub?;
    private areaHandler?;
    constructor(mapStore: MapStore, reader: MudixMapReader);
    attach(ctx: SceneOverlayContext): void;
    detach(): void;
    render(state: MapState, _bounds: ViewportBounds): Shape[] | void;
    private collectSelected;
}
