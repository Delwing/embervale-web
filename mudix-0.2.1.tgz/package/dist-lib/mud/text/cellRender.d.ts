/**
 * Renders text onto the monospace grid. Pure-ASCII runs are emitted as plain
 * text (the font lays them out at exactly 1ch each); every other grapheme is
 * boxed into a fixed `Nch` inline-block cell so wide/combining/font-fallback
 * glyphs can't drift the column grid. See `wcwidth.ts` for the width tables.
 */
export declare const CELL_CLASS = "ocell";
/** Append `text` to a DOM node as plain-text runs interleaved with cell spans. */
export declare function appendCells(parent: Node, text: string): void;
/** String equivalent of {@link appendCells} for the `toHtml()` path. */
export declare function cellsToHtml(text: string, escape: (s: string) => string): string;
