import { EventBus } from '../core/EventBus';
import { WindowManager } from '../ui/windows/WindowManager';
import { LabelManager } from '../ui/labels/LabelManager';
import { CommandLineManager } from '../ui/cmdline/CommandLineManager';
import { ScrollBoxManager } from '../ui/scrollbox/ScrollBoxManager';
import { SoundManager } from '../ui/sound/SoundManager';
import { VideoManager } from '../ui/video/VideoManager';
import { CmdLineMenuRegistry } from '../ui/CmdLineMenuRegistry';
import { MouseEventRegistry } from '../ui/MouseEventRegistry';
import { type MudClientOptions } from './connection/MudClient';
import { type MudEvents, type SessionStatus } from './events';
import type { Console } from './text/Console';
export type { SessionStatus, MudEvents } from './events';
export type MudSessionOptions = Omit<MudClientOptions, 'url'>;
/** Mudlet `showSentText` modes — controls local echo of commands you send.
 *  `never`: never echo. `script`: echo unless a script passes `send(cmd, false)`
 *  (the default). `always`: echo even when a script passes `send(cmd, false)`. */
export type ShowSentTextMode = 'never' | 'script' | 'always';
/** Mudlet `blankLinesBehaviour` modes — controls how empty server lines render.
 *  `show`: render the blank line as-is (default). `hide`: suppress it entirely.
 *  `replacewithspace`: render it as a single space (so screen readers announce
 *  it — Mudlet's QTBUG-105035 workaround). */
export type BlankLinesBehaviour = 'show' | 'hide' | 'replacewithspace';
export type ScriptLogSourceKind = 'script' | 'alias' | 'trigger' | 'timer' | 'key' | 'button';
export interface ScriptLogSource {
    kind: ScriptLogSourceKind;
    id: string;
    name: string;
    line?: number;
}
export interface ScriptLogEntry {
    text: string;
    level: 'error' | 'info';
    timestamp: number;
    source?: ScriptLogSource;
}
export declare class MudSession {
    readonly events: EventBus<MudEvents>;
    readonly windows: WindowManager;
    readonly labels: LabelManager;
    readonly cmdLines: CommandLineManager;
    readonly scrollBoxes: ScrollBoxManager;
    readonly sounds: SoundManager;
    readonly videos: VideoManager;
    readonly cmdLineMenu: CmdLineMenuRegistry;
    readonly mouseEvents: MouseEventRegistry;
    /** Per-window Console instances. 'main' registered by ScriptingAPI; named windows by WindowManager. */
    readonly consoles: Map<string, Console>;
    private client;
    /** The most recent URL passed to connect() — replayed by reconnect(). */
    private lastUrl;
    private pingTracker;
    private stateUnsubs;
    private _status;
    private _ping;
    private _outputReady;
    private _destroyed;
    /** Latest main output area character grid (columns × rows), tracked here so
     *  it survives client teardown and seeds a freshly-created client on the
     *  next connect(). Fed by the WindowManager's main-console resize callback
     *  and forwarded to the live client for NAWS (telnet option 31). */
    private windowSize;
    /** Colors for the local echo of sent commands. Re-applied from the active
     *  profile by ProfileSession. `fg` defaults to Mudlet's olive; `bg` empty =
     *  no background. Consumed by echoCommand() to wrap the echo in ANSI. */
    commandEchoColor: {
        fg: string;
        bg: string;
    };
    /** Mudlet `setConfig("showSentText", ...)`. Controls local echo of sent
     *  commands (the server-side ECHO suppression in `shouldEchoCommand` still
     *  applies independently). `script` (the default) echoes only when send()'s
     *  `echo` flag is set, so scripts can suppress per command via
     *  `send(cmd, false)`; `always` echoes even then; `never` never echoes.
     *  Toggled live by the config registry in ScriptingAPI. */
    showSentText: ShowSentTextMode;
    /** Mudlet `setConfig("blankLinesBehaviour", ...)`. Controls how empty server
     *  lines render in the main output. Read by ScriptingEngine.processFlushBatch
     *  per line; toggled live (and persisted) by the config registry in
     *  ScriptingAPI. */
    blankLinesBehaviour: BlankLinesBehaviour;
    /** Bounded script.log buffer so the editor panel can backfill entries that
     *  arrived before it was first opened (e.g. errors during initial load). */
    private static readonly SCRIPT_LOG_LIMIT;
    private _scriptLog;
    private readonly options;
    /** Warn before the tab closes while a connection is live. Owned here rather
     *  than by MudClient — a fresh client is created on every connect(), so a
     *  per-client listener would accumulate one leaked closure per reconnect. */
    private readonly beforeUnload;
    constructor(options?: MudSessionOptions);
    get scriptLog(): readonly ScriptLogEntry[];
    clearScriptLog(): void;
    get status(): SessionStatus;
    get ping(): number | null;
    get outputReady(): boolean;
    markOutputReady(): void;
    markOutputGone(): void;
    connect(url: string): void;
    disconnect(): void;
    /** Whether a send() carrying the given per-call `echo` flag should produce a
     *  local echo, under the current showSentText mode. `script` defers to the
     *  flag; `always`/`never` ignore it. */
    private shouldEchoSentText;
    echoCommand(text: string): void;
    /** Wrap the echoed command in ANSI truecolor escapes from commandEchoColor
     *  so it renders in the configured foreground (and optional background). */
    private styleEchoCommand;
    send(text: string, echo?: boolean): void;
    /** Send credentials/secrets that must NEVER be echoed locally — regardless of
     *  the showSentText mode (including `always`) or the server-echo state. Used
     *  for auto-login passwords. The normal `send(text, false)` only suppresses
     *  the echo in `script` mode; `always` would override it, so a password must
     *  take this path instead of relying on the per-call echo flag. */
    sendSecret(text: string): void;
    sendGmcpRaw(message: string): void;
    /** Reply to a GMCP `Char.Login.Default` request. Pass an account + password
     *  to authenticate, or no arguments to send the empty "fall back to text
     *  login" reply (the credentials popup's Cancel). The password is relayed
     *  straight to the wire and never persisted. */
    sendCharLoginCredentials(account?: string, password?: string): void;
    sendMSDP(variable: string, values: string[]): boolean;
    sendSocket(data: string): boolean;
    feedTelnet(data: string): void;
    sendATCP(message: string): boolean;
    sendTelnetChannel102(msg: string): boolean;
    /** Mudlet `reconnect()`. Disconnect and redial the most recently connected
     *  URL (set by connect(), so it covers both the app and Lua connect paths).
     *  Returns false when nothing has been dialed yet. */
    reconnect(): boolean;
    /** Mudlet `getServerEncoding()`. The live client's inbound decoder name;
     *  'utf-8' when no client is attached. */
    getServerEncoding(): string;
    /** Mudlet `setServerEncoding(name)`. Returns false when no client is
     *  attached or the name isn't supported. */
    setServerEncoding(name: string): boolean;
    /** Mudlet `getServerEncodingsList()`. The fixed set of encodings mudix can
     *  decode — available even before a connection is dialed. */
    getServerEncodingsList(): string[];
    /** Mudlet `addSupportedTelnetOption(option)`. Forwards to the live
     *  MudClient when one is attached so the option will be auto-negotiated
     *  on the next IAC WILL/DO from the server. Returns false when no client
     *  is wired up yet. */
    addSupportedTelnetOption(option: number): boolean;
    /** Updates both the active client (if any) and the stored options so the
     *  setting survives a reconnect. */
    setPromptTimeoutMs(ms: number): void;
    getPromptTimeoutMs(): number | null;
    /** Mudlet `setConfig("fixUnnecessaryLinebreaks", …)`. Updates the live client
     *  and the stored options so the setting survives a reconnect. */
    setFixUnnecessaryLinebreaks(enabled: boolean): void;
    /** Update the telnet protocol toggles applied on the next connect.
     *  Mid-session changes do not retroactively renegotiate — the values are
     *  read by MudClient's constructor, so the next dial sees them. */
    setProtocolOptions(opts: {
        gmcpEnabled?: boolean;
        mttsEnabled?: boolean;
        msdpEnabled?: boolean;
        msspEnabled?: boolean;
        charsetEnabled?: boolean;
        mspEnabled?: boolean;
        mccpEnabled?: boolean;
        mxpEnabled?: boolean;
        mnesEnabled?: boolean;
        newEnvironEnabled?: boolean;
        secureTransport?: boolean;
        nawsEnabled?: boolean;
        subprotocols?: string[];
    }): void;
    /** Record the main output area's character grid (columns × rows) and forward
     *  it to the live client for NAWS. Stored on the session so a client created
     *  on a later connect() is seeded with the current size. Called by the
     *  WindowManager whenever the main console's grid changes. */
    setWindowSize(cols: number, rows: number): void;
    private teardownClient;
    get destroyed(): boolean;
    /** Release resources that live outside the JS heap. In-memory state (maps,
     *  arrays, sub-managers) is reclaimed by GC once the instance is dropped, so
     *  this only handles the three things that don't self-clean: the WebSocket
     *  + ping timer (via `teardownClient`), Web Audio nodes, and any EventBus
     *  listeners with an AbortSignal cleanup still pending. Idempotent. */
    destroy(): void;
    private setStatus;
    private setPing;
    private reportConnectionError;
}
