interface LogBrowserModalProps {
    connectionId: string;
    connectionName: string;
    onClose: () => void;
}
export declare function LogBrowserModal({ connectionId, connectionName, onClose }: LogBrowserModalProps): import("react/jsx-runtime").JSX.Element;
export {};
