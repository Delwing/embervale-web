import './ScriptSearch.css';
export type EditCategory = 'scripts' | 'aliases' | 'triggers' | 'timers' | 'keys' | 'buttons';
interface ScriptSearchProps {
    connectionId: string;
    /** Navigate the editor to a matched item (and optionally a code line). */
    onNavigate: (category: EditCategory, id: string, line?: number) => void;
}
/** Global search for the Scripts editor — lives in the modal title bar and
 *  drops a VS Code-style results overlay (rendered through a portal so it
 *  escapes the modal's `overflow: hidden`). */
export declare function ScriptSearch({ connectionId, onNavigate }: ScriptSearchProps): import("react/jsx-runtime").JSX.Element;
export {};
