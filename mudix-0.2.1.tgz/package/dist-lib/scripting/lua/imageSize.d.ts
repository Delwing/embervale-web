export declare function parseImageSize(b: Uint8Array): {
    width: number;
    height: number;
} | null;
