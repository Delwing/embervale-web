interface Props {
    onClose: () => void;
}
/** Small "About" dialog reachable from the connection screen — wordmark,
 *  tagline and description come from the active brand (stock mudix by
 *  default) plus a link to the source repository when the brand sets one. */
export declare function AboutModal({ onClose }: Props): import("react/jsx-runtime").JSX.Element;
export {};
