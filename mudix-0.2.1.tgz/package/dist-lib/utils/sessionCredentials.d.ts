/**
 * In-memory login credentials, keyed by connection id. Used by branded builds,
 * where credentials are **never persisted**: the login screen deposits them
 * here and the auto-login paths (GMCP Char.Login, text-login prompts) read
 * them with priority over the connection record's stored fields. Lifetime is
 * the page — a reload starts back at the login form.
 */
export interface SessionCredentials {
    account: string;
    password: string;
}
export declare function setSessionCredentials(connectionId: string, creds: SessionCredentials | null): void;
export declare function getSessionCredentials(connectionId: string): SessionCredentials | undefined;
/** The most recently entered credentials this page, regardless of profile —
 *  prefills the branded login form after closing a profile. */
export declare function getLastSessionCredentials(): SessionCredentials | undefined;
