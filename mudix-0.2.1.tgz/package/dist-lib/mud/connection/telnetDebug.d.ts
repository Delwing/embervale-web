/**
 * localStorage-gated diagnostic logging for the MUD connection. Each gate is
 * toggled from the browser console (e.g. `localStorage.setItem('mudix.debugTelnet',
 * '1')`) and read live on every use, so logging can be flipped mid-session
 * without a reconnect.
 */
/**
 * `mudix.debugTelnet` — log every telnet command/subnegotiation byte seen on
 * each incoming frame. Used to investigate protocol-negotiation issues
 * (GMCP/MSDP/MCCP not enabling) by revealing exactly what the server sends.
 */
export declare function debugTelnetEnabled(): boolean;
/**
 * `mudix.debugFrames` — log WebSocket frame boundaries for the MUD stream.
 * Used to investigate "extra line break" issues that surface when long MUD
 * lines arrive split across multiple WebSocket frames.
 */
export declare function debugFramesEnabled(): boolean;
/**
 * `mudix.debugMsp` — log MSP negotiation, parsed `!!SOUND`/`!!MUSIC` tags
 * (inline and subneg), and their dispatch into the SoundManager. Use this to
 * confirm whether a MUD is actually emitting MSP and whether the client is
 * routing it through.
 */
export declare function debugMspEnabled(): boolean;
/**
 * `mudix.debugGa` — log every IAC GA / IAC EOR prompt marker the server sends,
 * plus the one-time moment the client latches into GA-driven prompt mode. Use
 * this to confirm whether a MUD actually signals its prompts (GA-less MUDs rely
 * on the `promptTimeoutMs` idle-flush fallback instead).
 */
export declare function debugGaEnabled(): boolean;
/** Scan a Latin-1 byte-string for telnet IAC sequences and log them in
 *  human-readable form. Logs SB option codes too (e.g. `SB GMCP` / `SB MSDP`). */
export declare function logTelnetNegotiation(label: string, s: string): void;
