/**
 * Browse and install packages from Mudlet's official package repository.
 *
 * The repository is published as a static site backed by the
 * github.com/Mudlet/mudlet-package-repository git repo. A reindex script
 * regenerates `packages/mpkg.packages.json` after every commit, so the JSON
 * catalog is authoritative — we don't try to scrape the all-packages.html page.
 *
 * Catalog shape (top-level object):
 *   { name, updated, packages: PackageRepoEntry[] }
 *
 * URLs are constructed from the repo's GitHub Pages base. Icon paths inside
 * each entry are already relative to the repo root (e.g. "packages/icons/Foo.png"),
 * so they're joined to REPO_BASE_URL verbatim.
 */
/**
 * Public-facing repository site (used for "view in browser" links).
 * NOT used for fetching the catalog — the GitHub Pages mirror lags weeks behind
 * the main branch. Mudlet's own package manager dialog hits raw.githubusercontent.com
 * for the same reason; we mirror that choice.
 */
export declare const REPO_SITE_URL = "https://mudlet.github.io/mudlet-package-repository";
/** Base for fetching individual .mpackage files and icons (always-current `main` branch). */
export declare const REPO_RAW_BASE = "https://raw.githubusercontent.com/Mudlet/mudlet-package-repository/refs/heads/main";
export declare const CATALOG_URL = "https://raw.githubusercontent.com/Mudlet/mudlet-package-repository/refs/heads/main/packages/mpkg.packages.json";
export interface PackageRepoEntry {
    /** Internal identifier (matches manifest.name produced by installPackageFromBytes). */
    mpackage: string;
    /** Filename inside the repo's packages/ directory, e.g. "Foo.mpackage". */
    filename: string;
    title?: string;
    description?: string;
    author?: string;
    version?: string;
    /** ISO-8601 author-declared creation date. */
    created?: string;
    /** Unix timestamp the package was last uploaded to the repo. */
    uploaded?: number;
    /** Repo-relative icon path, e.g. "packages/icons/Foo.png". Optional. */
    icon?: string;
}
export interface PackageRepoCatalog {
    name: string;
    updated: string;
    packages: PackageRepoEntry[];
}
/** Absolute URL of the .mpackage zip for `entry`. */
export declare function packageDownloadUrl(entry: PackageRepoEntry): string;
/** Absolute URL of the icon image for `entry`, or null when none. */
export declare function packageIconUrl(entry: PackageRepoEntry): string | null;
/** Fetch and parse the package catalog. Throws on network or JSON errors. */
export declare function fetchPackageCatalog(proxyUrl?: string): Promise<PackageRepoCatalog>;
/** Download a single package's bytes. The caller is expected to pass it to installPackageFromBytes. */
export declare function downloadPackageBytes(entry: PackageRepoEntry, proxyUrl?: string): Promise<Uint8Array>;
