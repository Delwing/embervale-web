import type { ScriptWindowRenderData } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface WindowContextMenuProps {
    windows: ScriptWindowRenderData[];
    manager: WindowManager;
    x: number;
    y: number;
    onClose: () => void;
}
export declare function WindowContextMenu({ windows, manager, x, y, onClose }: WindowContextMenuProps): import("react/jsx-runtime").JSX.Element;
export {};
