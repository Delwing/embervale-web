interface CharLoginModalProps {
    /** Connection name, shown in the title for context. */
    connectionName?: string;
    /** Error from a previous failed attempt (Char.Login.Result success=false). */
    error?: string;
    /** Account/username to prefill (saved per-profile credential). */
    initialAccount?: string;
    /** Password to prefill (saved per-profile credential — plaintext). */
    initialPassword?: string;
    /** Initial state of the "remember on this device" checkbox. */
    initialRemember?: boolean;
    /** Show the "remember on this device" checkbox (default true). Branded
     *  builds hide it — credentials are never persisted there, so `onSubmit`
     *  always receives `remember=false`. */
    allowRemember?: boolean;
    /** Send `account` + `password` to the server (Char.Login.Credentials).
     *  `remember` tells the caller whether to persist them for next time. */
    onSubmit: (account: string, password: string, remember: boolean) => void;
    /** Decline GMCP login — sends the empty reply so the server falls back to
     *  its text login prompt. */
    onCancel: () => void;
}
/**
 * Credentials popup for GMCP `Char.Login` authentication. Rendered as a real
 * `<form>` with `autocomplete="username"` / `autocomplete="current-password"`
 * inputs so browser password managers offer to fill and save. Optionally
 * remembers the account + password per profile (plaintext localStorage — see
 * the inline warning); the password is otherwise handed straight to `onSubmit`
 * and relayed to the server, never stored. Cancelling falls back to text login.
 */
export declare function CharLoginModal({ connectionName, error, initialAccount, initialPassword, initialRemember, allowRemember, onSubmit, onCancel, }: CharLoginModalProps): import("react/jsx-runtime").JSX.Element;
export {};
