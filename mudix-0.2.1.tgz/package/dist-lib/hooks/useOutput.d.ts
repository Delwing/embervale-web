import { type OutputRendererControls, type MessageSource } from '../ui/output/OutputRenderer';
export declare const DEFAULT_STICKY_LINES = 50;
export interface UseStickyOutputOptions {
    stickyLines?: number;
    maxElements?: number;
    splitViewThreshold?: number;
    showTimestamps?: boolean;
}
export interface UseStickyOutputResult {
    outputRef: React.RefObject<HTMLDivElement | null>;
    sentinelRef: React.RefObject<HTMLDivElement | null>;
    stickyAreaRef: React.RefObject<HTMLDivElement | null>;
    isSplitView: boolean;
    scrollToBottom: () => void;
    controls: OutputRendererControls | null;
}
export declare function useStickyOutput(source: MessageSource | null, { stickyLines, maxElements, splitViewThreshold, showTimestamps, }?: UseStickyOutputOptions): UseStickyOutputResult;
