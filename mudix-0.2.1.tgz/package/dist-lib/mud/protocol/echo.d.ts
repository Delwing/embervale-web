export declare class EchoHandler {
    /** Committed (debounced) state exposed to UI / send-echo logic. True
     *  whenever the server is echoing for us, which means we must suppress our
     *  own local command echo to avoid showing every line twice. This is *not*
     *  the same as password masking — see `_passwordStyle` / `passwordMode`. */
    private _serverEchoing;
    /** Latest raw on-the-wire state. Used to gate ack dedup and decide whether
     *  to schedule a commit. */
    private _rawEchoing;
    /** Whether the *current* ECHO engagement should mask the input line. A
     *  server that enables ECHO during the opening negotiation burst — before
     *  it has printed any output — is doing session-wide remote echo (it will
     *  echo your name, commands, everything), not requesting a password. The
     *  classic Diku/ROM password pattern instead toggles `IAC WILL ECHO` on
     *  *after* the name prompt, right before "Password:". So we only treat an
     *  ECHO that engages after the server has already sent output as a password
     *  prompt. Captured at each OFF→ON transition. Mudlet masks on every ECHO;
     *  doing so here would hide the name on full-server-echo MUDs, which is the
     *  bug this distinction fixes. */
    private _passwordStyle;
    /** Set once the server has emitted any non-telnet output. Distinguishes a
     *  connect-time (server-wide) ECHO from a later (password) ECHO. */
    private sawAppData;
    private stabilityTimer;
    private passwordSafetyTimer;
    private connectionStartAt;
    private toggleCount;
    private lastToggleAt;
    private _anomalyDetected;
    private readonly sendRaw;
    private readonly onEchoChange;
    private readonly onAnomalyDetected;
    constructor(sendRaw: (data: string) => void, onEchoChange: (maskInput: boolean) => void, onAnomalyDetected?: () => void);
    get serverEchoing(): boolean;
    /** Whether the command input should be masked (password mode). Only true
     *  for an ECHO engagement that began after the server started sending
     *  output — a genuine password prompt — never for connect-time server-wide
     *  echo. */
    get passwordMode(): boolean;
    get anomalyDetected(): boolean;
    /** Scan the post-MCCP byte stream for true `IAC WILL/WONT ECHO`. Substring
     *  matching on the raw buffer is unsafe — GMCP/MSDP subnegotiation payloads
     *  can contain the same byte sequence (e.g. an unescaped IAC followed by
     *  MSDP_VAR=\x01), which would spuriously flip password mode every prompt
     *  on data-heavy servers like Legend of Kallisti. Walk the stream as
     *  telnet: skip SB…SE blocks entirely, honor IAC IAC escapes, and only act
     *  on top-level IAC WILL/WONT ECHO. */
    processData(data: string): void;
    private setEchoing;
    /** Arm / disarm the Mudlet-style "password mode never ended" safety
     *  timeout. Called right after a committed state change. */
    private updatePasswordSafetyTimer;
    /** Mirror cTelnet::checkEchoAnomalyPattern. Increments a sliding-window
     *  toggle counter on every raw flip and, when the threshold is crossed,
     *  trips sticky anomaly state. Returns true when anomaly was tripped on
     *  this call (the caller should bail out). */
    private trackToggleAndDetectAnomaly;
    /** Refuse ECHO for the rest of the session: send `IAC DONT ECHO`, drop any
     *  pending commit / safety timers, force the UI back to normal, and notify
     *  the engine so a `sysEchoAnomalyDetected` Lua event can fire. */
    private tripAnomaly;
    reset(): void;
}
