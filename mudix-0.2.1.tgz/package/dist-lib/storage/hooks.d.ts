import { type ClientSettings, type ProfileSettings, type Theme } from './schema';
/**
 * Active profile id, provided by ProfileSession. `null` outside a profile
 * (e.g. on the connection screen) — settings consumers fall through to
 * PROFILE_DEFAULTS in that case.
 */
export declare const ConnectionIdContext: import("react").Context<string | null>;
export declare function useConnectionId(): string | null;
/** Read one ProfileSettings field for the active profile (from context). */
export declare function useProfileField<K extends keyof ProfileSettings>(key: K): ProfileSettings[K];
/** Read one ClientSettings field. */
export declare function useClientField<K extends keyof ClientSettings>(key: K): ClientSettings[K];
/** The theme actually in effect: the active profile's override if it has one,
 *  else the launcher theme. Use anywhere a profile-scoped component needs the
 *  current theme (e.g. CodeMirror editors). Outside a profile (no context) it
 *  resolves to the launcher theme. */
export declare function useEffectiveTheme(): Theme;
