import type { CommandLineManager } from './CommandLineManager';
import './CommandLineOverlay.css';
interface CommandLineOverlayProps {
    manager: CommandLineManager;
    parent: string;
}
export declare function CommandLineOverlay({ manager, parent }: CommandLineOverlayProps): import("react/jsx-runtime").JSX.Element | null;
export {};
