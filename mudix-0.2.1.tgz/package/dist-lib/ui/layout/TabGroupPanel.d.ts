import type { DockSide, DragState, ScriptWindowRenderData } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface TabGroupPanelProps {
    side: DockSide;
    panels: ScriptWindowRenderData[];
    activeId: string;
    manager: WindowManager;
    onDragStateChange: (ds: DragState | null) => void;
    onTitlebarContextMenu: (e: React.MouseEvent) => void;
}
export declare function TabGroupPanel({ side, panels, activeId, manager, onDragStateChange, onTitlebarContextMenu }: TabGroupPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
