interface Props {
    name: string;
    /** Re-request folder access (must run from this click — a user gesture). */
    onGrant: () => void;
    /** Drop the folder link; the profile opens from local storage instead. */
    onUnlink: () => void;
    onBack: () => void;
}
/**
 * Shown when a linked Mudlet profile is opened but the browser hasn't granted
 * access to its folder (typically on a fresh page load via a deep link, where
 * there's no user gesture to prompt with). The user must decide — grant access
 * or unlink — rather than silently falling through to an empty local copy.
 */
export declare function FolderPermissionScreen({ name, onGrant, onUnlink, onBack }: Props): import("react/jsx-runtime").JSX.Element;
export {};
