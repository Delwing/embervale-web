import { FormatState } from './FormatState';
import { AnsiAwareBuffer } from './FormatState';
import type { FormatStateSnapshot } from './FormatState';
/**
 * Self-contained text output entity — equivalent of Mudlet's TConsole.
 * Owns format state, line history, and cursor position.
 * The renderer is a pure consumer: it receives lines via takeLines() and
 * calls buf.notifyRender() so that rerender()/removeFromDom() can reach the DOM.
 */
export declare class Console {
    readonly format: FormatState;
    private history;
    private pending;
    private partial;
    private cursorIdx;
    private cursorCol;
    private _maxLines;
    private _batchDeleteSize;
    /** Mudlet `sysBufferShrinkEvent(name, linesRemoved)` hook. Fired by
     *  `evict()` whenever the scrollback cap drops one or more lines from the
     *  head of `history`. Set by the owning session (ScriptingAPI for "main",
     *  WindowManager for named user windows). */
    onBufferShrink: ((linesRemoved: number) => void) | undefined;
    private consumeLeadingNewline;
    setFgColor(r: number, g: number, b: number): void;
    setBgColor(r: number, g: number, b: number, a?: number): void;
    setBold(v: boolean): void;
    setItalic(v: boolean): void;
    setUnderline(v: boolean): void;
    setStrikethrough(v: boolean): void;
    setOverline(v: boolean): void;
    setReverse(v: boolean): void;
    resetFormat(): void;
    get maxLines(): number;
    setMaxLines(n: number): void;
    get batchDeleteSize(): number;
    setBatchDeleteSize(n: number): void;
    echo(text: string): void;
    /**
     * Append a pre-built complete line buffer to history. Used by the network
     * trigger pipeline: the line has already been parsed and is being added as
     * a single canonical entry, not via partial accumulation. The cursor is
     * placed on the new line at column 0 so triggers see Mudlet's "cursor on
     * the matching line at trigger fire" state. Does NOT enqueue into pending
     * — the renderer for network output drains via the 'message' event
     * pipeline; pending is reserved for script-driven echo flushes.
     */
    appendLine(buffer: AnsiAwareBuffer): void;
    /**
     * Append a pre-formatted buffer as a new complete line — mirrors Mudlet's
     * TConsole::appendBuffer, the primitive behind the `appendBuffer`/`paste`
     * clipboard functions. Unlike `appendLine` (network pipeline) this also
     * enqueues into `pending` so the line reaches the renderer through the
     * normal drain path; the cursor resets to the end so a following
     * `selectCurrentLine` sees the pasted line.
     */
    appendBuffer(buffer: AnsiAwareBuffer): void;
    private evict;
    /** Drain newly completed lines to hand to the renderer. */
    takeLines(): AnsiAwareBuffer[];
    get currentPartial(): AnsiAwareBuffer;
    /**
     * Promote the in-flight partial (an echo without a trailing newline, e.g.
     * a trigger's `cecho("\n text")`) into a finished history line and return
     * it, leaving a fresh empty partial behind. Returns null when nothing is
     * pending. Unlike `clear()`, the existing history is preserved so
     * line-number / selectString lookups for later lines in the same flush
     * batch stay valid — this is what lets a per-line trigger-echo flush place
     * the echoed line right after the line it was echoed on. The line is NOT
     * enqueued into `pending` (the caller emits it explicitly), so a following
     * `takeLines()` won't re-emit it.
     */
    completePartialLine(): AnsiAwareBuffer | null;
    clear(): void;
    /**
     * Discard only the in-flight partial (and the leading-newline latch),
     * leaving history/cursor untouched. `feedTriggers` uses this to drop a
     * stray partial left by a prior direct `echo()` without wiping accumulated
     * history — multiple `feedTriggers` calls must accumulate lines (Mudlet
     * appends fed text to the buffer), which a full `clear()` would destroy.
     */
    clearPartial(): void;
    private get cursor();
    private get followingEnd();
    getLine(): string;
    getBuffer(): AnsiAwareBuffer | null;
    /** Per-line prompt flag on the current cursor line. Mirrors Mudlet's TBuffer
     *  behaviour: `isPrompt()` follows the cursor, so moveCursor + isPrompt can
     *  inspect any historical line's prompt status, not just the most recent. */
    cursorOnPrompt(): boolean;
    deleteLine(): void;
    /**
     * Insert `text` at the cursor (Mudlet `insertText`). Embedded `\n` split the
     * current line into multiple history lines (Mudlet issue #8945): the text up
     * to the first `\n` is inserted at the cursor column, each subsequent `\n`
     * starts a new line, and the remainder of the original line trails the last
     * inserted segment. For a single-line insert the cursor stays at the
     * insertion point (Mudlet's `insertText` does not advance `mUserCursor` — the
     * bundled GUIUtils `xEcho`/`cinsertText` loop advances it explicitly with its
     * own `moveCursor` after each segment; advancing here too would double-count
     * and push later color segments past their intended column). Returns false
     * when there's no current line to insert into (caller falls back to an echo).
     * Mid-buffer multi-line inserts update the buffer model fully; the
     * incremental renderer redraws the affected line(s) lazily.
     */
    insertText(text: string, state?: FormatStateSnapshot): boolean;
    /**
     * Move the cursor up `lines` rows. When `keepHorizontal` is false (the
     * default, matching Mudlet) the column resets to 0; when true the column
     * is preserved across the move and lazily clamps to the destination
     * line's length on read via `getCursorColumn`.
     */
    moveUp(lines?: number, keepHorizontal?: boolean): boolean;
    moveDown(lines?: number, keepHorizontal?: boolean): boolean;
    /**
     * Seek the cursor to absolute line `line` (0-indexed). When `col` is
     * supplied, also set the column; otherwise the column is reset to 0 (the
     * Mudlet `moveCursor(x=0, y)` default).
     */
    moveTo(line: number, col?: number): boolean;
    /**
     * Mudlet's `mUserCursor.x()` — the column on the cursor line. Lazily
     * clamped to the current line's length so a stale `cursorCol` from a
     * `keepHorizontal` move never reports past the end of a shorter line.
     */
    getCursorColumn(): number;
    setCursorColumn(col: number): boolean;
    /** Mark cursor as positioned at the end of existing rendered content, so the
     *  next leading `\n` is treated as cursor advance rather than a blank line.
     *  Pass `false` to clear the latch (e.g. when leaving trigger processing) so
     *  it can't leak onto an unrelated later echo. */
    markCursorAtEnd(value?: boolean): void;
    getLineNumber(): number;
    getLineCount(): number;
    getLines(from: number, to: number): string[];
    /**
     * Mudlet `getTimestamp(lineNumber)` — the wall-clock time (epoch ms) the
     * line entered the buffer. `lineNumber` is 1-based to match `getLines`
     * (Mudlet's timeBuffer reserves index 0); omit it to read the current
     * cursor line. Returns null when the line is out of range or the buffer
     * is empty. Formatting into Mudlet's "hh:mm:ss.zzz" string happens one
     * layer up, in ScriptingAPI.
     */
    getLineTimestamp(lineNumber?: number): number | null;
    /**
     * Mudlet `wrapLine(lineNumber)` — re-display the line at `lineNumber`
     * (0-indexed, matching getLineNumber/getLineCount), re-interpreting its
     * embedded `\n` characters and re-wrapping to the current width. mudix
     * renders each line buffer with CSS `white-space: pre-wrap`, and the
     * rendered DOM node holds the very same buffer object as history (set via
     * `notifyRender`), so re-rendering that buffer in place is what makes any
     * `\n` show as line breaks — the documented use case after a `deleteLine()`
     * + `echo()` sequence left un-displayed newlines in the buffer. Returns
     * false when `lineNumber` is out of range.
     */
    wrapLine(lineNumber: number): boolean;
}
