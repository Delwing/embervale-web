/** Backing store for persistent stopwatches (localStorage in the browser). */
export interface StopwatchStore {
    load(): string | null;
    save(data: string): void;
}
/** Build a localStorage-backed store scoped to a connection, or undefined when
 *  localStorage is unavailable (tests / SSR) — in which case persistence is a
 *  no-op and watches behave as memory-only. */
export declare function localStorageStopwatchStore(connectionId: string): StopwatchStore | undefined;
/** Broken-down elapsed time, mirroring Mudlet's generateElapsedTimeTable. */
export interface BrokenDownTime {
    negative: boolean;
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
    milliSeconds: number;
    /** Signed total seconds (matches Mudlet's elapsedMilliSeconds / 1000). */
    decimalSeconds: number;
}
/** Per-watch record returned by getStopWatches (keyed by stringified id). */
export interface StopwatchSummary {
    name: string;
    isRunning: boolean;
    isPersistent: boolean;
    elapsedTime: BrokenDownTime;
}
export declare class StopwatchManager {
    private readonly storage?;
    private readonly watches;
    private nextId;
    constructor(storage?: StopwatchStore | undefined);
    private now;
    private elapsedMs;
    /**
     * Resolve a watchID-or-name argument. Numbers (and numeric strings, which
     * Mudlet's lua_isnumber treats as ids) look up by id; other strings look up
     * by name. An empty string returns the first unnamed watch — Mudlet's
     * findStopWatchId("") behaviour.
     */
    private resolve;
    /** Rehydrate persistent watches from the backing store (called once on construction). */
    private restore;
    /** Write the current set of persistent watches to the backing store. */
    private persist;
    /**
     * Mudlet createStopWatch([name], [autostart]). Returns the new id, or null
     * when `name` is given and already in use (Mudlet rejects duplicate names).
     */
    create(name: string, autoStart: boolean): number | null;
    /**
     * Mudlet startStopWatch. `resetAndRestart` replicates the legacy behaviour
     * for a numeric id called bare: reset to zero and run from there. Otherwise
     * a stopped watch resumes and a running one is left untouched. Returns false
     * for an unknown watch.
     */
    start(arg: number | string, resetAndRestart: boolean): boolean;
    /**
     * Mudlet stopStopWatch. Pauses the watch and returns the elapsed seconds
     * once (legacy behaviour preserved by Mudlet). null for an unknown watch.
     */
    stop(arg: number | string): number | null;
    /** Mudlet getStopWatchTime — elapsed seconds without stopping. */
    getTime(arg: number | string): number | null;
    /** Mudlet getStopWatchBrokenDownTime — elapsed time as a day/hour/minute/
     *  second/millisecond table. null for an unknown watch. */
    getBrokenDownTime(arg: number | string): BrokenDownTime | null;
    /**
     * Mudlet setStopWatchName(watchID|currentName, newName). Assigns or renames
     * a watch. Returns false for an unknown watch, an empty new name, or when
     * another watch already uses the new name (Mudlet rejects duplicate names).
     */
    setName(arg: number | string, newName: string): boolean;
    /** Mudlet resetStopWatch — zero the elapsed time; a running watch keeps running. */
    reset(arg: number | string): boolean;
    /** Mudlet adjustStopWatch — add `seconds` (may be negative) to the elapsed time. */
    adjust(arg: number | string, seconds: number): boolean;
    /** Mudlet deleteStopWatch. */
    delete(arg: number | string): boolean;
    /**
     * Mudlet setStopWatchPersistence(id|name, state). Marks whether the watch is
     * saved to (and restored from) the backing store across reloads. Returns
     * false for an unknown watch.
     */
    setPersistence(arg: number | string, state: boolean): boolean;
    /** Mudlet getStopWatches — record keyed by stringified id (Bridge.lua re-keys to ints). */
    getAll(): Record<string, StopwatchSummary>;
}
