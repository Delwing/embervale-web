import type { MudSession } from '../../mud/MudSession';
import type { ScriptWindowRenderData } from '../windows/types';
import type { WindowManager } from '../windows/WindowManager';
interface MobileLayoutProps {
    session: MudSession;
    manager: WindowManager;
    /** Already filtered to non-popped-out windows by ContentLayout. */
    windows: ScriptWindowRenderData[];
    stickyLines?: number;
    commandInputRef?: React.RefObject<HTMLInputElement | HTMLTextAreaElement | null>;
    commandBar?: React.ReactNode;
}
/**
 * Phone layout: a single column showing one view at a time — the main MUD
 * output or one script panel — flipped via a bottom switcher bar. The desktop
 * dock/float chrome (drag, splitters, floating frames) is bypassed entirely;
 * panel *content* is reused untouched by re-parenting the same stable
 * portal-target divs WindowManager already maintains (same trick as the
 * desktop TabGroupPanel), so panels stay live in the background.
 */
export declare function MobileLayout({ session, manager, windows, stickyLines, commandInputRef, commandBar }: MobileLayoutProps): import("react/jsx-runtime").JSX.Element;
export {};
