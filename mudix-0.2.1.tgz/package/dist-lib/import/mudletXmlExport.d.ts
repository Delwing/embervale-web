import type { AliasNode, ButtonNode, KeyNode, ScriptNode, TimerNode, TriggerNode } from '../storage/schema';
export interface SerializeInput {
    scripts: ScriptNode[];
    aliases: AliasNode[];
    triggers: TriggerNode[];
    timers: TimerNode[];
    keys: KeyNode[];
    buttons: ButtonNode[];
}
/**
 * Serialize a Mudlet-package node set back to XML. When `packageName` is supplied,
 * a top-level wrapper group of that name (the one that `applyPackageTagging`
 * inserts on import) is unwrapped — its children become package-level roots —
 * so the document round-trips back to the same structure on re-import.
 */
export declare function serializeMudletXml(input: SerializeInput, packageName?: string): string;
