/** Begin listening for other tabs' persisted-store writes and merging them in.
 *  Idempotent; safe to call more than once (e.g. across HMR reloads). */
export declare function initCrossTabSync(): void;
