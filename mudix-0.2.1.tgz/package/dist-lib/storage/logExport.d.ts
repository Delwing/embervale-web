import { type LogEntry, type LogSession } from './logStorage';
/** `YYYY-MM-DD HH-MM-SS`, safe for filenames. */
export declare function formatSessionFileStamp(ts: number): string;
/** `HH:MM:SS` for per-line timestamps. */
export declare function formatTime(ts: number): string;
/** `YYYY-MM-DD HH:MM:SS` for session labels. */
export declare function formatDateTime(ts: number): string;
/** A standalone, self-contained HTML document for one session. */
export declare function buildSessionHtml(session: LogSession, entries: LogEntry[]): string;
/** Trigger a browser download for an in-memory blob. */
export declare function downloadBlob(filename: string, blob: Blob): void;
/** Download one session as a standalone `.html` file. */
export declare function exportSessionHtml(session: LogSession): Promise<void>;
/** Bundle several sessions into one `.zip`, one HTML file per session. */
export declare function exportSessionsZip(sessions: LogSession[]): Promise<void>;
/** Shape of the JSON export/import payload. */
export interface LogExportJson {
    version: 1;
    exportedAt: number;
    sessions: Array<{
        session: LogSession;
        entries: LogEntry[];
    }>;
}
/** Export sessions (with their entries) to a `.json` file. */
export declare function exportSessionsJson(sessions: LogSession[]): Promise<void>;
/**
 * Import a previously exported JSON payload. Each session is re-keyed with a
 * fresh id so re-importing never clobbers an existing session, and entry rows
 * drop their old auto-increment ids. Returns the number of sessions imported.
 */
export declare function importSessionsJson(text: string): Promise<number>;
