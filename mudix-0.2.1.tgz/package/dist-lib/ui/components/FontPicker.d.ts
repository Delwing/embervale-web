import type { ProfileVFS } from '../../scripting/vfs/ProfileVFS';
import type { OutputFontSource } from '../../storage';
interface FontPickerProps {
    value: OutputFontSource | undefined;
    onChange: (next: OutputFontSource | undefined) => void;
    vfs: ProfileVFS | null;
}
export declare function FontPicker({ value, onChange, vfs }: FontPickerProps): import("react/jsx-runtime").JSX.Element;
export {};
