import type { ScriptingEngine } from '../../../scripting/ScriptingEngine';
interface VariablesViewProps {
    connectionId: string;
    scriptingEngineRef?: React.RefObject<ScriptingEngine | null>;
}
/**
 * Mudlet's Variables view: the live `_G` tree with a checkbox per top-level
 * entry that toggles whether it persists across sessions (the profile's
 * save-list / Mudlet `<VariablePackage>`). Built-in globals — the default Lua +
 * Mudlet API namespace present at runtime boot — are hidden by default (toggle
 * to show), so only your own variables appear. Tables expand to browse their
 * contents (fetched eagerly, so expansion is instant). Functions/userdata are
 * shown but not flaggable. Save flagging is top-level granularity (checking a
 * table persists all of it); per-key flagging is a follow-up.
 *
 * Enumerating `_G` runs synchronously on the Lua/main thread, so we defer it a
 * tick behind a loader: the spinner paints first, then the walk runs, keeping
 * opening the tab responsive even for a large namespace.
 */
export declare function VariablesView({ connectionId, scriptingEngineRef }: VariablesViewProps): import("react/jsx-runtime").JSX.Element;
export {};
