interface ToggleProps {
    id?: string;
    checked: boolean;
    onChange: (next: boolean) => void;
    disabled?: boolean;
    'aria-label'?: string;
    'aria-labelledby'?: string;
}
export declare function Toggle({ id, checked, onChange, disabled, ...aria }: ToggleProps): import("react/jsx-runtime").JSX.Element;
export {};
