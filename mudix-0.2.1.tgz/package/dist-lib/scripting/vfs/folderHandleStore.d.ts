interface ShowDirectoryPickerOptions {
    mode?: 'read' | 'readwrite';
}
declare global {
    interface Window {
        showDirectoryPicker?: (options?: ShowDirectoryPickerOptions) => Promise<FileSystemDirectoryHandle>;
    }
}
export type FolderPermissionState = 'granted' | 'prompt' | 'denied' | 'unsupported';
export declare function isFolderLinkSupported(): boolean;
export declare function saveFolderHandle(connectionId: string, handle: FileSystemDirectoryHandle): Promise<void>;
export declare function loadFolderHandle(connectionId: string): Promise<FileSystemDirectoryHandle | null>;
export declare function clearFolderHandle(connectionId: string): Promise<void>;
export declare function checkFolderPermission(handle: FileSystemDirectoryHandle): Promise<FolderPermissionState>;
export declare function requestFolderPermission(handle: FileSystemDirectoryHandle): Promise<FolderPermissionState>;
export {};
