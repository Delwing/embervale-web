import type { ProfileVFS } from './ProfileVFS';
/**
 * Rewrite `url(<local-path>)` references in a Qt/CSS stylesheet to
 * `url(/__vfs/<connectionId>/<path>)` so the registered service worker can
 * serve the bytes from the connection's ProfileVFS. Already-absolute http/data/
 * blob/__vfs URLs pass through untouched.
 *
 * Paths are resolved through the VFS (which honours its cwd and profile root)
 * and rebased onto the profile root before being put into the URL.
 */
export declare function rewriteVfsUrlsInCss(css: string, connectionId: string, vfs: ProfileVFS): string;
