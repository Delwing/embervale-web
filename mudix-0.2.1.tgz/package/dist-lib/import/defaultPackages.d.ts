import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
/**
 * Install any default packages the profile doesn't already have. Idempotent:
 * a package is skipped if its manifest name is already in `connectionPackages`
 * — so existing profiles also pick up newly-added defaults on next open.
 *
 * A default the user explicitly uninstalled stays uninstalled: the store's
 * `uninstallPackage` tombstones the name in the profile's
 * `uninstalledPackages` (Mudlet's `deletedDefaultMuds` equivalent), and this
 * skips tombstoned names — except brand packages marked `removable: false`,
 * which always come back.
 *
 * Failures are logged and swallowed: a broken default must never block the
 * profile from opening.
 */
export declare function ensureDefaultPackages(connectionId: string, vfs: ProfileVFS): Promise<void>;
