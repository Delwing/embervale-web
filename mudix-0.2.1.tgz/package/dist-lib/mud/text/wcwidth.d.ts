/**
 * Terminal display-width tables (a wcwidth-style implementation).
 *
 * MUD output is laid out on a monospace grid: every character occupies an
 * integer number of cells (0, 1, or 2). Browsers don't enforce that — a glyph
 * the chosen font lacks falls back to another font with a different advance
 * width, wide CJK/emoji render at their natural width, and combining marks add
 * code-unit length but no visual width. The renderer uses these tables to box
 * each grapheme into a fixed `Nch` cell so columns stay aligned regardless of
 * the font.
 *
 * Ranges follow Markus Kuhn's wcwidth (combining + East Asian Wide/Fullwidth),
 * extended with the Supplementary-plane emoji/symbol blocks. BMP dingbats and
 * miscellaneous symbols (☎ ★ ♠ …) are East Asian *Ambiguous* and kept at width
 * 1, matching the common "narrow" terminal rendering.
 */
/**
 * Display width of a single Unicode code point, in monospace cells.
 * Returns 0 for combining/zero-width, 2 for wide, 1 otherwise. C0/C1 control
 * characters (which shouldn't reach the renderer) are treated as 0.
 */
export declare function codePointWidth(cp: number): 0 | 1 | 2;
/**
 * Display width of a grapheme cluster (base + any combining marks / ZWJ
 * sequence). Width is the widest code point in the cluster, so an emoji ZWJ
 * sequence stays 2 and a base+diacritic stays at the base's width.
 */
export declare function clusterWidth(cluster: string): 0 | 1 | 2;
/** Total display width of a string, in monospace cells. */
export declare function stringWidth(text: string): number;
export interface DisplayCell {
    /** The grapheme cluster occupying this cell. */
    text: string;
    /** Number of monospace cells the grapheme occupies (0, 1, or 2). */
    width: 0 | 1 | 2;
}
/**
 * Split text into display cells, one per grapheme cluster. Uses
 * `Intl.Segmenter` for proper cluster boundaries (so combining marks fold into
 * their base), falling back to per-code-point iteration where it is missing.
 */
export declare function segmentCells(text: string): DisplayCell[];
/** Fast check: pure printable ASCII renders at exactly 1 cell with no boxing. */
export declare function isPlainAscii(text: string): boolean;
