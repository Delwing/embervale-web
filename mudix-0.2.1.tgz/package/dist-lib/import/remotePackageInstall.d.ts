/**
 * Fetch a package file from a remote URL, falling back through the configured
 * proxy on CORS / network failures. Mirrors the proxy logic in HttpService and
 * packageRepository — duplicated rather than imported to keep this module
 * focused on the small concern of "download bytes for a package install".
 */
export declare function downloadFromUrl(url: string, proxyUrlRaw?: string): Promise<Uint8Array>;
/** Pull the trailing path segment out of a URL, falling back when the URL is malformed. */
export declare function filenameFromUrl(url: string): string;
export interface ClientGuiPayload {
    url: string;
    version?: string;
}
/**
 * Decode a `Client.GUI` GMCP payload. Mudlet historically supports two shapes:
 *   - a `{ url, version }` JSON object (current MMP-style format)
 *   - a string `"<url>\n<version>"` (legacy)
 * Returns null when neither shape applies or the URL is empty.
 */
export declare function parseClientGuiPayload(value: unknown): ClientGuiPayload | null;
