import type { MapState, SceneOverlay, SceneOverlayContext, Shape, ViewportBounds } from 'mudlet-map-renderer';
import type { MapStore } from './MapStore';
import type { MudixMapReader } from './MudixMapReader';
export declare class MudletHighlightOverlay implements SceneOverlay {
    private readonly mapStore;
    private readonly reader;
    private ctx?;
    private mapStoreUnsub?;
    private areaHandler?;
    constructor(mapStore: MapStore, reader: MudixMapReader);
    attach(ctx: SceneOverlayContext): void;
    detach(): void;
    /** Force a re-render from outside. The renderer's `refresh()` doesn't
     *  emit any state event we listen to, but a change to settings.roomSize
     *  moves every highlight circle's radius. */
    refresh(): void;
    render(state: MapState, _bounds: ViewportBounds): Shape[] | void;
}
