interface Props {
    onClose: () => void;
    onHostYourOwn: () => void;
}
export declare function ProxyWhyModal({ onClose, onHostYourOwn }: Props): import("react/jsx-runtime").JSX.Element;
export {};
