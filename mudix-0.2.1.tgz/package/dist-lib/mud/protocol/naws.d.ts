/**
 * Frame an `IAC SB NAWS <width> <height> IAC SE` subnegotiation (telnet option
 * 31, RFC 1073) reporting the client window size as character columns × rows.
 * Both dimensions are 16-bit big-endian, clamped to [0, 65535], with IAC bytes
 * escaped. The returned string is a Latin-1 byte-string ready for sendRaw.
 */
export declare function encodeNaws(cols: number, rows: number): string;
