export type MspKind = "sound" | "music";
/** Parsed `!!SOUND` / `!!MUSIC` command. Numeric fields fall back to undefined
 *  when the server omits the key — the consumer (SoundManager) substitutes its
 *  own defaults rather than having parser-level defaults bleed downstream. */
export interface MspCommand {
    kind: MspKind;
    /** Filename or the literal `Off` (case-sensitive per spec) to stop playback. */
    file: string;
    /** U= field — explicit URL the file can be downloaded from. */
    url?: string;
    /** V= field — volume 0..100 on the MSP scale. */
    volume?: number;
    /** L= field — loop count. -1 = forever, otherwise positive integer. */
    loops?: number;
    /** P= field — priority 0..100. Only meaningful for `!!SOUND`. */
    priority?: number;
    /** C= field — `1` = if same is already playing, keep it (no restart). */
    continueIfPlaying?: boolean;
    /** T= field — channel / tag string. */
    type?: string;
}
/**
 * Stateful MSP parser. Feed each post-telnet-strip chunk through `feed()` and
 * render the returned `text` instead of the raw input. Parsed commands are
 * delivered as `commands`. The parser holds back a partial tag (`!!SOUND(...`
 * with no closing `)` yet) until the next chunk supplies the rest, so tags
 * split across WebSocket frames still parse correctly.
 */
export declare class MspParser {
    /** Partial tag carried over from the previous chunk, including the
     *  leading `!!`. Empty when no tag is in progress. */
    private pending;
    feed(input: string): {
        text: string;
        commands: MspCommand[];
    };
    /** Drop any partial-tag buffer. Called on disconnect / reconnect. */
    reset(): void;
    /** Parse the body of an `IAC SB MSP ... IAC SE` subnegotiation. The body
     *  byte[0] is the option code (90); the rest is the raw tag text (often
     *  `!!SOUND(...)`) per the spec, though some implementations send just the
     *  body inside the parens. We try both. A subnegotiation is framed as a
     *  whole unit by the time it reaches us, so we don't share parser state
     *  with the in-band stream — running `feed()` here would let a malformed
     *  subneg leak a partial-tag buffer into the next inline chunk. */
    feedSubneg(subneg: string): MspCommand[];
}
