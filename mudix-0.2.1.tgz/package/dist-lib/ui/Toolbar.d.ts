import { type BrandToolbarContext } from '../branding';
import type { SessionStatus } from '../mud/events';
interface ToolbarProps {
    connectionName: string;
    status: SessionStatus;
    ping: number | null;
    onDisconnect: () => void;
    onReconnect: () => void;
    onNewConnection: () => void;
    onOpenMap: () => void;
    onOpenScripts: () => void;
    onOpenFiles: () => void;
    onOpenLogs: () => void;
    onOpenDocs: () => void;
    onOpenSettings: () => void;
    onContextMenu?: (e: React.MouseEvent<HTMLDivElement>) => void;
    /** Capabilities handed to brand toolbar buttons (send / raiseEvent). */
    brandContext?: BrandToolbarContext;
}
export declare function Toolbar({ connectionName, status, ping, onDisconnect, onReconnect, onNewConnection, onOpenMap, onOpenScripts, onOpenFiles, onOpenLogs, onOpenDocs, onOpenSettings, onContextMenu, brandContext }: ToolbarProps): import("react/jsx-runtime").JSX.Element;
export {};
