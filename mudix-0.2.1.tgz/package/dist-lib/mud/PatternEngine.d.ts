type TempFn = (matches: RegExpMatchArray) => void;
type PatternItem = {
    id: string;
    name: string;
    pattern: string;
    code: string;
    language: 'lua' | 'js';
    enabled: boolean;
    isGroup: boolean;
    parentId: string | null;
};
export declare class PatternEngine<T extends PatternItem> {
    protected readonly temp: Map<number, {
        pattern: RegExp;
        fn: TempFn;
    }>;
    protected nextId: number;
    protected permCompiled: Array<{
        item: T;
        re: RegExp;
    }>;
    /** Number of live session-scoped temp items (Mudlet `getProfileStats` temp count). */
    get tempCount(): number;
    addTemp(pattern: string | RegExp, fn: TempFn): () => void;
    loadPerm(items: T[]): void;
    destroy(): void;
}
export {};
