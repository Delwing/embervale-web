import { AnsiAwareBuffer } from "../../mud/text/FormatState";
export declare const elementBuffers: WeakMap<Element, AnsiAwareBuffer>;
type MessageListener = (message?: string | AnsiAwareBuffer, type?: string, timestamp?: number, isPrompt?: boolean) => void;
export type MessageSource = {
    on(event: 'message', listener: MessageListener): () => void;
    on(event: 'script.deleteline', listener: () => void): () => void;
    on(event: 'script.clearwindow', listener: () => void): () => void;
    on(event: 'script.movecursorup', listener: () => void): () => void;
    on(event: 'script.movecursordown', listener: () => void): () => void;
};
export type CursorOps = {
    /** Plain text of the line at the current cursor position. */
    getLine: () => string;
    /** AnsiAwareBuffer of the line at the current cursor position, for in-place coloring. */
    getBuffer: () => AnsiAwareBuffer | null;
    /** Remove the line at the current cursor position. */
    deleteLine: () => void;
    /** Move the cursor one line toward older output. */
    moveUp: () => void;
    /** Move the cursor one line toward newer output. */
    moveDown: () => void;
    /** Move the cursor to an absolute line number (1 = oldest, getLineCount() = newest). */
    moveTo: (line: number) => void;
    /** 1-indexed line number of the cursor from the top of the buffer. */
    getLineNumber: () => number;
    /** Total number of lines currently in the output buffer. */
    getLineCount: () => number;
    /** Plain text of lines [from..to] (1-indexed, inclusive) as a JS string array. */
    getLines: (from: number, to: number) => string[];
};
/**
 * Creates cursor ops for a plain line container (text/miniconsole windows).
 * The container holds `div` line elements appended via appendChild — no sentinel.
 * Returns the ops plus an `onLineAppended` callback that must be called each
 * time a new line element is added, so the cursor resets to the latest line.
 */
export declare function createWindowCursorOps(container: HTMLElement): {
    ops: CursorOps;
    onLineAppended: (el: Element) => void;
};
type OutputHandlerOptions = {
    outputWrapper: HTMLElement;
    sentinel: HTMLElement;
    stickyArea: HTMLElement;
    isSplitView: () => boolean;
    stickyLines: number;
    maxElements?: number | (() => number);
    trimSlack?: number;
    suppressSplitView?: (durationMs: number) => void;
    /** Called once the cursor ops are ready; wire them to ScriptingAPI/session. */
    onCursorReady?: (ops: CursorOps) => void;
};
export type OutputRendererControls = {
    teardown: () => void;
    areTimestampsVisible: () => boolean;
    setTimestampVisibility: (visible: boolean) => void;
    toggleTimestampVisibility: () => void;
    populateStickyArea: () => void;
    clearStickyArea: () => void;
    push: (message: string | AnsiAwareBuffer, type?: string, timestamp?: number) => void;
    clear: () => void;
};
export declare function setupOutputRenderer(source: MessageSource | null, { outputWrapper, sentinel, stickyArea, isSplitView, stickyLines, maxElements, trimSlack, suppressSplitView, onCursorReady, }: OutputHandlerOptions): OutputRendererControls;
export {};
