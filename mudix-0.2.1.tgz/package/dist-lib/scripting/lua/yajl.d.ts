import type { Lua } from 'wasmoon-lua5.1';
export type LuaValueTransform = (v: unknown) => unknown;
export declare function setupYajl(lua: Lua): {
    transform: LuaValueTransform;
};
