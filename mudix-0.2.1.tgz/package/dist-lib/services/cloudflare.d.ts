/**
 * Minimal Cloudflare API client for the proxy-deploy wizard.
 *
 * The wizard uses the user's API token to:
 *   1. List accounts the token has access to (verifyToken / listAccounts)
 *   2. Upload the proxy worker script (deployWorker)
 *   3. Enable the *.workers.dev route on it (enableWorkersDevRoute)
 *   4. Look up the account's workers.dev subdomain (getWorkersSubdomain)
 *
 * Cloudflare's API rejects cross-origin browser requests, so every call is
 * tunneled through a relay Worker's HTTP-forward mode (`?url=<target>`). The
 * relay adds CORS headers and strips Origin/Referer/Cookie before forwarding;
 * the Authorization header is preserved.
 *
 * The token never leaves component state — it's consumed once per deploy and
 * never persisted.
 */
export interface CloudflareAccount {
    id: string;
    name: string;
}
export declare class CloudflareApiError extends Error {
    readonly status: number;
    readonly cfErrors?: {
        code: number;
        message: string;
    }[];
    constructor(message: string, status: number, cfErrors?: {
        code: number;
        message: string;
    }[]);
}
/**
 * Lists accounts visible to the token. Doubles as a token-validity check:
 * an invalid token returns a Cloudflare error envelope which we surface.
 */
export declare function listAccounts(token: string, proxyBase?: string): Promise<CloudflareAccount[]>;
/**
 * Uploads a Worker script via the multipart "modules" format. The script is
 * sent as an ES module so `import { connect } from 'cloudflare:sockets'` works.
 */
export declare function deployWorker(token: string, accountId: string, scriptName: string, scriptSource: string, proxyBase?: string): Promise<void>;
/**
 * Enables (or disables) the auto-assigned *.workers.dev route for a script.
 * Without this the script is uploaded but not reachable.
 */
export declare function enableWorkersDevRoute(token: string, accountId: string, scriptName: string, proxyBase?: string): Promise<void>;
/**
 * Returns the account's workers.dev subdomain (e.g. "yourname" → "*.yourname.workers.dev").
 * If the user has never created one, the API returns an empty string and the
 * wizard surfaces a friendlier error.
 */
export declare function getWorkersSubdomain(token: string, accountId: string, proxyBase?: string): Promise<string>;
export declare function buildWorkerWssUrl(scriptName: string, subdomain: string): string;
