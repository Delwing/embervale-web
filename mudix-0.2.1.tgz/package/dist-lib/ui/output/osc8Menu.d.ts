/**
 * Right-click context menu for OSC 8 hyperlinks (Mudlet's `config.menu`).
 *
 * Pure DOM — no scripting/session dependencies — so the renderer can build and
 * show it and tests can exercise it without the full engine. `run` executes a
 * selected item's action URI (the caller maps it to send/prompt/openUrl).
 */
import type { MenuItem, LinkTitle } from "../../mud/text/hyperlinkConfig";
/**
 * Open the link's context menu at the event position. `menu` entries are either
 * separators (`{ separator: true }`) or `{ label, action }` pairs; `title`, when
 * present, is shown as an (optionally styled) header. Selecting an item runs its
 * action via `run` and closes the menu. Any open menu is replaced; clicking
 * outside dismisses it.
 */
export declare function openOsc8Menu(ev: MouseEvent, menu: MenuItem[], title: LinkTitle | undefined, run: (uri: string) => void): void;
