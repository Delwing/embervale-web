import type { WindowManager } from '../WindowManager';
interface MapPanelProps {
    id: string;
    manager: WindowManager;
    connectionId: string;
}
export declare function MapPanel({ id, manager, connectionId }: MapPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
