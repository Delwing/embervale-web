interface Props {
    name: string;
    /** true = another tab owns the profile and we're queued behind it;
     *  false = we're just acquiring a free lock (a brief, usually invisible moment). */
    waiting: boolean;
    onBack: () => void;
}
/** Shown while a profile can't yet be mounted because another browser tab holds
 *  its single-owner lock. Auto-dismisses (the parent swaps in the session) the
 *  moment the other tab releases it. */
export declare function ProfileBusyScreen({ name, waiting, onBack }: Props): import("react/jsx-runtime").JSX.Element;
export {};
