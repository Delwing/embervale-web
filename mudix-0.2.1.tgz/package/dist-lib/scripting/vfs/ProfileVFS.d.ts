export type VFSSource = 'folder' | 'idb';
export declare class ProfileVFS {
    readonly connectionId: string;
    readonly profilePath: string;
    private _cwd;
    private _fs;
    private _handle?;
    readonly source: VFSSource;
    readonly folderName?: string;
    private constructor();
    static mount(connectionId: string): Promise<ProfileVFS>;
    private static doMount;
    get cwd(): string;
    resolvePath(path: string): string;
    exists(path: string): boolean;
    readFile(path: string): string;
    readBinaryFile(path: string): Uint8Array;
    writeFile(path: string, content: string): void;
    writeBinaryFile(path: string, data: Uint8Array): void;
    /**
     * The linked-folder (WebAccess / FileSystemDirectoryHandle) backend overwrites
     * a file from offset 0 but does NOT shrink it, so writing shorter content over
     * longer leaves stale tail bytes — silently corrupting Lua `table.save` data,
     * JSON, and the profile XML. Removing the file first forces a fresh,
     * correctly-sized write. IndexedDB truncates on the `w` flag correctly, so it's
     * left untouched (no extra op per save).
     */
    private clearForOverwrite;
    appendFile(path: string, content: string): void;
    deleteFile(path: string): void;
    rename(oldPath: string, newPath: string): void;
    mkdir(path: string): void;
    rmdir(path: string): void;
    readdir(path: string): string[];
    stat(path: string): {
        type: 'file' | 'dir';
        size: number;
        mtime: Date;
        atime: Date;
    } | null;
    chdir(path: string): string | null;
    /**
     * Drain queued async writes to the underlying backend. For folder-backed
     * mounts this writes RAM-cached changes through to disk; for IDB mounts
     * it persists to IndexedDB. Safe to call on any source.
     */
    flush(): Promise<void>;
    /**
     * Re-walk the linked directory and rebuild the in-memory cache. Use after
     * external edits (file added/changed in the OS file manager). No-op for
     * IDB-backed profiles since their state is owned by the browser.
     *
     * Any Lua file handles opened before resync become invalid: ZenFS replaces
     * the underlying FS instance, so subsequent reads on those handles will
     * error. New `io.open` calls work normally.
     */
    resync(): Promise<void>;
    unmount(): void;
}
