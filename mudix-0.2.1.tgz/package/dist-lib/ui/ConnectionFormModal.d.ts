import { type MudConnection } from '../storage';
interface Props {
    /** The connection to edit, or null to add a new one. */
    connection: MudConnection | null;
    /** Whether this is the very first connection (drives the title copy). */
    firstConnection: boolean;
    busy: boolean;
    onAdd: (data: Omit<MudConnection, 'id'>) => string;
    onUpdate: (id: string, data: Omit<MudConnection, 'id'>) => void;
    onClose: () => void;
}
export declare function ConnectionFormModal({ connection, firstConnection, busy, onAdd, onUpdate, onClose }: Props): import("react/jsx-runtime").JSX.Element;
export {};
