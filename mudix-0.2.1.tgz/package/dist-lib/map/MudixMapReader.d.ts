import { MapReader } from 'mudlet-map-renderer';
import type { IArea, IMapReader } from 'mudlet-map-renderer';
import type { MapStore } from './MapStore';
type RoomShape = ReturnType<MapReader['getRoom']>;
/**
 * Live {@link IMapReader} backed by Mudix's {@link MapStore}.
 *
 * The renderer is constructed once on panel mount and held for the lifetime of
 * the panel. Whenever the store mutates (script-built rooms, binary load,
 * setRoomCoordinates, …) the panel calls {@link refresh}; this rebuilds the
 * inner concrete {@link MapReader} from the store's current snapshot. The
 * renderer's `MapState` notices the new `IArea` instance via reference
 * inequality and rebuilds the scene — no Konva stage / event listener
 * teardown.
 *
 * The renderer's wire format (`{mapData, colors}`) is produced via
 * `readerExport(store.toMudletMap())` — the same transformation Mudlet's own
 * binary-reader pipeline applies. Doing it inside the reader (instead of in
 * the panel) keeps `MapPanel` pure-view: it never sees the wire format.
 */
export declare class MudixMapReader implements IMapReader {
    private readonly store;
    private inner;
    private snapshotVersion;
    constructor(store: MapStore);
    /** Rebuild the inner reader from MapStore's current snapshot. Safe to
     *  call from a store-change subscriber — cheap when the store is empty
     *  and idempotent when no mutation has happened since the last refresh. */
    refresh(): void;
    /**
     * Stale-check before every public read. The renderer can ask for a room
     * synchronously after a script mutation (e.g. addRoom → centerview),
     * before MapStore's microtask-delayed notify fires. Running the version
     * check on every call is O(1); a real rebuild only happens when the
     * store has actually mutated since the last snapshot.
     */
    private ensureFresh;
    /** True once the store has at least one room; the panel's empty-state
     *  overlay stays up until this flips. */
    hasData(): boolean;
    private buildInner;
    getArea(areaId: number): IArea;
    getAreas(): IArea[];
    getRooms(): RoomShape[];
    getRoom(roomId: number): RoomShape;
    getColorValue(envId: number): string;
    getSymbolColor(envId: number, opacity?: number): string;
}
export {};
