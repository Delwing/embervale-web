import type { ProfileSettings } from '../storage/schema';
import { type SerializeInput } from './mudletXmlExport';
import { type MudletVariablePackage } from './mudletVariables';
/**
 * Produce the updated profile XML: the base save with its automation + variable
 * packages replaced by `trees` / `variables`, the modeled `<Host>` settings
 * updated in place from `settings`, and HostPackage's unmodeled fields (plus any
 * unknown element) carried over verbatim. Throws if the base XML is malformed.
 */
export declare function buildLinkedWriteback(baseXml: string, trees: SerializeInput, variables: MudletVariablePackage, settings?: Partial<ProfileSettings>): string;
/** Mudlet's profile-save filename stamp for `date`: `YYYY-MM-DD#HH-mm-ss`. */
export declare function mudletTimestamp(date: Date): string;
