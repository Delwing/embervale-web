import type React from 'react';
export declare function cssTextToStyle(css: string): React.CSSProperties;
export interface QtMargin {
    top: number;
    right: number;
    bottom: number;
    left: number;
}
export interface CssParts {
    inline: React.CSSProperties;
    scoped: Array<{
        pseudo: string;
        declarations: string;
    }>;
    margin?: QtMargin;
}
export declare function cssTextToParts(css: string): CssParts;
export declare function userWindowQssToScopedCss(qss: string, scope: string): string;
export declare function cmdLineQssToScopedCss(qss: string, scope: string): string;
export declare function cssEscape(s: string): string;
export declare function qtDeclarationsToCss(css: string): string;
