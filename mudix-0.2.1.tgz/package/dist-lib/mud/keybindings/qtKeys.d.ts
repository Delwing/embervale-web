/** Qt::KeypadModifier — set by Mudlet when a binding came from the numpad. */
export declare const QT_KEYPAD_MODIFIER = 536870912;
/**
 * Translate a Qt::Key integer (or already-translated DOM `KeyboardEvent.code`
 * string) into a DOM `KeyboardEvent.code`. Mudlet `tempKey` accepts both;
 * passing a string straight through lets users pre-resolve when they prefer.
 *
 * When `modifier` includes Qt::KeypadModifier, digit and symbol codes resolve
 * to their Numpad* DOM variants — DOM `KeyboardEvent.code` distinguishes
 * numpad keys from the main keyboard while Qt::Key alone does not.
 */
export declare function qtKeyToDomCode(key: string | number, modifier?: number): string;
/**
 * Translate a Qt::KeyboardModifier bitmask into an array of modifier names
 * that match the {ctrl,shift,alt,meta} strings KeyEngine compares against.
 *
 * Qt::ShiftModifier   = 0x02000000
 * Qt::ControlModifier = 0x04000000
 * Qt::AltModifier     = 0x08000000
 * Qt::MetaModifier    = 0x10000000
 * Qt::KeypadModifier  = 0x20000000  (ignored — DOM `code` already encodes "Numpad*")
 * Qt::GroupSwitchMod. = 0x40000000  (ignored — X11-only)
 */
export declare function qtModifiersToList(modifier: number): string[];
/** Inverse of qtModifiersToList — {ctrl,shift,alt,meta} names → Qt bitmask. */
export declare function listToQtModifiers(modifiers: string[]): number;
/**
 * Inverse of qtKeyToDomCode for the common case — a DOM `KeyboardEvent.code`
 * back to a Qt::Key integer. Used by getKeyCode() to report a permanent key
 * binding (stored as a DOM code) in Mudlet's Qt terms. Returns undefined for a
 * code with no Qt mapping.
 */
export declare function domCodeToQtKey(code: string): number | undefined;
