/** True when the current selection touches any line inside `container`. */
export declare function hasSelectionIn(container: HTMLElement): boolean;
/** Select every line in the container (Range over its contents). */
export declare function selectAll(container: HTMLElement): void;
/** Copy the native selection text verbatim (character-precise). */
export declare function copySelectionText(): Promise<void>;
/**
 * Copy the selected lines as a complete, self-contained HTML document. The full
 * document source goes on the clipboard as both `text/html` (so rich targets
 * paste it rendered) and `text/plain` (so plain targets paste the HTML markup
 * itself), with a `writeText` fallback for browsers without ClipboardItem.
 */
export declare function copySelectionAsHtml(container: HTMLElement): Promise<void>;
/** Copy the selected lines to the clipboard as a PNG image. */
export declare function copySelectionAsImage(container: HTMLElement): Promise<void>;
