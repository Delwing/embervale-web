import type { Lua } from 'wasmoon-lua5.1';
/** Register __rex_* JS helpers and put rex_pcre2 into package.loaded. */
export declare function setupRex(lua: Lua): Promise<void>;
