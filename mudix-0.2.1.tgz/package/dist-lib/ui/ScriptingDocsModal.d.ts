import './ScriptingDocsModal.css';
interface ScriptingDocsModalProps {
    connectionId: string;
    onClose: () => void;
}
/**
 * A read-only browser for the Lua scripting API, sourced from the same
 * REFERENCE_GROUPS catalogue that backs editor autocomplete — so the docs
 * never drift from what the runtime actually exposes.
 */
export declare function ScriptingDocsModal({ connectionId, onClose }: ScriptingDocsModalProps): import("react/jsx-runtime").JSX.Element;
export {};
