import type { ScrollBoxManager } from './ScrollBoxManager';
import type { LabelManager } from '../labels/LabelManager';
import type { CommandLineManager } from '../cmdline/CommandLineManager';
import './ScrollBoxOverlay.css';
interface ScrollBoxOverlayProps {
    manager: ScrollBoxManager;
    labels: LabelManager;
    cmdLines: CommandLineManager;
    /** Viewport whose scroll boxes this overlay renders ('main', a userwindow
     *  id, or — when nested — another scroll box's name). */
    parent: string;
}
/**
 * Renders the {@link ScrollBoxManager}'s boxes for a given parent viewport as
 * absolutely-positioned scrollable containers. Each box hosts the child overlays
 * (labels, command lines, and nested scroll boxes) scoped to the box's own name,
 * so widgets created with `parent = boxName` render inside it.
 *
 * Scrolling: the children are absolutely positioned and don't expand their
 * containers on their own, so each box wraps them in a content div sized to the
 * extent of its children (the furthest child edge). When that extent exceeds the
 * box, the box's `overflow:auto` produces real scrollbars.
 */
export declare function ScrollBoxOverlay({ manager, labels, cmdLines, parent }: ScrollBoxOverlayProps): import("react/jsx-runtime").JSX.Element | null;
export {};
