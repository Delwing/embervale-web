export interface CmdLineCreateOptions {
    /** Parent window id ('main' for the main viewport). */
    parent?: string;
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface CmdLineState {
    name: string;
    parent: string;
    x: number;
    y: number;
    width: number;
    height: number;
    visible: boolean;
    /** Last value pushed from script (printCmdLine / clearCmdLine / appendCmdLine).
     *  The React input owns its own typed state; this seed is only applied when
     *  `valueSeq` changes, mirroring the per-userwindow command-line pattern. */
    value: string;
    valueSeq: number;
    /** When false, the input is rendered with the `disabled` attribute so the
     *  user can't focus/type. Mudlet disableCommandLine(name). */
    enabled: boolean;
    /** Raw Qt-style CSS string from setCmdLineStyleSheet. Translated to scoped
     *  CSS at render time via {@link cmdLineQssToScopedCss}. */
    styleSheet?: string;
    /** z-index — bumped by raiseWindow/lowerWindow. */
    zIndex?: number;
    /** Lua-side Enter handler. Plain field; not part of the React snapshot. */
    action: ((text: string) => void) | null;
}
type Listener = (cmdLines: CmdLineState[]) => void;
/**
 * Registry for overlay command-line widgets (Mudlet createCommandLine). Mirrors
 * {@link LabelManager}'s shape: per-parent subscribers, one Map keyed by name.
 *
 * Distinct from {@link WindowManager}'s per-userwindow command lines — those are
 * dockview-panel inputs gated by enableCommandLine; these are absolutely-
 * positioned overlay `<input>` elements on top of a parent viewport, sibling to
 * createLabel.
 */
export declare class CommandLineManager {
    private readonly cmdLines;
    private readonly listeners;
    /** Per-cmdline live value probe registered by the React mount. Lets
     *  ScriptingAPI.getCmdLine read the current typed text without round-
     *  tripping through React state. */
    private readonly valueProbes;
    /** Per-cmdline imperative control registered by the React mount —
     *  selectAll() drives <input>.select() (Mudlet selectCmdLineText). */
    private readonly controls;
    private nextRaiseZ;
    private nextLowerZ;
    /** Mudlet createCommandLine(name, x, y, w, h) — false when a cmd line with
     *  that name already exists. */
    create(name: string, opts: CmdLineCreateOptions): boolean;
    has(name: string): boolean;
    destroy(name: string): boolean;
    move(name: string, x: number, y: number): boolean;
    resize(name: string, width: number, height: number): boolean;
    show(name: string): boolean;
    hide(name: string): boolean;
    raise(name: string): boolean;
    lower(name: string): boolean;
    enable(name: string): boolean;
    disable(name: string): boolean;
    setStyleSheet(name: string, css: string): boolean;
    /** Mudlet printCmdLine — replace contents, caret to end. */
    setValue(name: string, text: string): boolean;
    /** Mudlet appendCmdLine — push onto the end of the current contents. */
    appendValue(name: string, text: string): boolean;
    /** Mudlet clearCmdLine — wipe the contents. */
    clearValue(name: string): boolean;
    /** Mudlet getCmdLine — live value via the React-registered probe, falling
     *  back to the last seed when nothing has mounted yet. */
    getValue(name: string): string;
    setAction(name: string, cb: ((text: string) => void) | null): boolean;
    getAction(name: string): ((text: string) => void) | null;
    hasAction(name: string): boolean;
    /** Mudlet selectCmdLineText — highlight all text in the input. */
    selectAll(name: string): boolean;
    registerValueProbe(name: string, probe: () => string): () => void;
    registerControl(name: string, ctrl: {
        selectAll: () => void;
    }): () => void;
    list(parent: string): CmdLineState[];
    subscribe(parent: string, fn: Listener): () => void;
    clearAll(): void;
    private notify;
}
export {};
