/** One recorded gameplay session (a single profile open). */
export interface LogSession {
    /** UUID; also the foreign key on every {@link LogEntry}. */
    id: string;
    connectionId: string;
    /** Display name captured at record time, so the browser can label the
     *  session even after the connection is renamed or deleted. */
    connectionName: string;
    startedAt: number;
    /** Updated on every flush; the wall-clock time of the last logged line. */
    endedAt: number;
    entryCount: number;
}
/** One captured output line. `html` is the styled, HTML-escaped render
 *  (snapshotted at emit time); `plain` is the unstyled text used for search. */
export interface LogEntry {
    /** Auto-increment key, assigned by IndexedDB on insert. */
    id?: number;
    sessionId: string;
    /** Monotonic ordering within the session (guards against equal timestamps). */
    seq: number;
    timestamp: number;
    /** Mirrors the `message` event type: 'mud' | 'echo' | 'script' | 'info' | … */
    type: string;
    html: string;
    plain: string;
}
/** Insert a session record (call once, on the first flush that has entries). */
export declare function createSession(session: LogSession): Promise<void>;
/** Merge a partial update into an existing session record (endedAt/entryCount). */
export declare function updateSession(id: string, patch: Partial<LogSession>): Promise<void>;
/** Append a batch of entries in a single transaction. */
export declare function appendEntries(entries: LogEntry[]): Promise<void>;
/** All sessions, newest first. Optionally filtered to one connection. */
export declare function listSessions(connectionId?: string): Promise<LogSession[]>;
/** All entries for a session, in capture order. */
export declare function getSessionEntries(sessionId: string): Promise<LogEntry[]>;
/** Delete a session and every entry that belongs to it. */
export declare function deleteSession(id: string): Promise<void>;
/** Delete several sessions (and their entries). */
export declare function deleteSessions(ids: string[]): Promise<void>;
/** Remove every log for a connection — called when the connection is deleted. */
export declare function deleteSessionsForConnection(connectionId: string): Promise<void>;
/** Wipe all recorded logs across every connection. */
export declare function clearAllLogs(): Promise<void>;
