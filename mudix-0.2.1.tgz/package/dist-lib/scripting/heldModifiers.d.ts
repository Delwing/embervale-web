/** Current held-modifier bitmask in Qt::KeyboardModifier units (matches
 *  `mudlet.keymodifier`). Installs the global listeners on first call. */
export declare function getHeldModifiers(): number;
