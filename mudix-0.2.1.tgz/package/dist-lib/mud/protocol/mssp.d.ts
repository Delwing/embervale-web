export interface MsspEnvelope {
    /** MSSP variable name (e.g. "PLAYERS", "UPTIME", "HOSTNAME"). */
    name: string;
    /** The reported value. Always a string — Mudlet treats MSSP values as
     *  scalars (the multi-value list form, rare in practice, is collapsed to
     *  the first value). */
    value: string;
}
/**
 * Parse an MSSP subnegotiation body (the `IAC SB MSSP … IAC SE` payload with
 * the leading option byte already stripped). The grammar is a flat run of
 * `MSSP_VAR <name> MSSP_VAL <value>` pairs; names/values are scalar byte runs
 * terminated by the next control byte. Tolerant of truncation and stray bytes.
 *
 * Mirrors Mudlet's TLuaInterpreter::parseMSSP: scalar string values, and a
 * variable with extra `MSSP_VAL` runs keeps only its first value.
 */
export declare function parseMssp(body: string): MsspEnvelope[];
export interface MsspStreamOptions {
    onEnvelope: (payload: MsspEnvelope) => void;
}
/** Mirror of createMsdpStream for MSSP subnegotiations. The handler receives a
 *  subnegotiation body whose first byte is the MSSP option code (70); each
 *  variable is emitted as its own envelope. */
export declare const createMsspStream: ({ onEnvelope }: MsspStreamOptions) => (data: string) => void;
