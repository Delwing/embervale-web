export declare const TELNET_OPTION_REGEX: RegExp;
export declare const TELNET_GA = "\u00FF\u00F9";
export declare const TELNET_EOR = "\u00FF\u00EF";
export declare const TELOPT_EOR = "\u0019";
export declare const EOR_WILL = "\u00FF\u00FB\u0019";
export declare const EOR_DO = "\u00FF\u00FD\u0019";
export declare const TELOPT_SGA = "\u0003";
export declare const SGA_WILL = "\u00FF\u00FB\u0003";
export declare const SGA_DO = "\u00FF\u00FD\u0003";
export declare const GMCP_COMMAND_CODE = 201;
export declare const GMCP_IAC = "\u00FF";
export declare const GMCP_SB = "\u00FA";
export declare const GMCP_SE = "\u00F0";
export declare const MCCP2_OPTION = 86;
export declare const MSDP_COMMAND_CODE = 69;
export declare const OPT_MSDP = "E";
export declare const MSDP_VAR = "\u0001";
export declare const MSDP_VAL = "\u0002";
export declare const MSDP_TABLE_OPEN = "\u0003";
export declare const MSDP_TABLE_CLOSE = "\u0004";
export declare const MSDP_ARRAY_OPEN = "\u0005";
export declare const MSDP_ARRAY_CLOSE = "\u0006";
export declare const MSDP_WILL = "\u00FF\u00FBE";
export declare const MSDP_DO = "\u00FF\u00FDE";
export declare const MSSP_COMMAND_CODE = 70;
export declare const OPT_MSSP = "F";
export declare const MSSP_VAR = "\u0001";
export declare const MSSP_VAL = "\u0002";
export declare const MSSP_WILL = "\u00FF\u00FBF";
export declare const MSSP_DO = "\u00FF\u00FDF";
export declare const GMCP_WILL = "\u00FF\u00FB\u00C9";
export declare const GMCP_DO = "\u00FF\u00FD\u00C9";
export declare const ATCP_COMMAND_CODE = 200;
export declare const OPT_ATCP = "\u00C8";
export declare const TELNET_102_COMMAND_CODE = 102;
export declare const OPT_TELNET_102 = "f";
export declare const TTYPE_COMMAND_CODE = 24;
export declare const OPT_TTYPE = "\u0018";
export declare const TTYPE_IS = "\0";
export declare const TTYPE_SEND = "\u0001";
export declare const TTYPE_DO = "\u00FF\u00FD\u0018";
export declare const TTYPE_WILL = "\u00FF\u00FB\u0018";
export declare const ECHO_WILL = "\u00FF\u00FB\u0001";
export declare const ECHO_WONT = "\u00FF\u00FC\u0001";
export declare const ECHO_DO = "\u00FF\u00FD\u0001";
export declare const ECHO_DONT = "\u00FF\u00FE\u0001";
export declare const MSP_COMMAND_CODE = 90;
export declare const OPT_MSP = "Z";
export declare const MSP_WILL = "\u00FF\u00FBZ";
export declare const MSP_DO = "\u00FF\u00FDZ";
export declare const MXP_COMMAND_CODE = 91;
export declare const OPT_MXP = "[";
export declare const MXP_WILL = "\u00FF\u00FB[";
export declare const MXP_DO = "\u00FF\u00FD[";
export declare const NEW_ENVIRON_COMMAND_CODE = 39;
export declare const OPT_NEW_ENVIRON = "'";
export declare const NEW_ENVIRON_IS = "\0";
export declare const NEW_ENVIRON_SEND = "\u0001";
export declare const NEW_ENVIRON_INFO = "\u0002";
export declare const NEW_ENVIRON_VAR = "\0";
export declare const NEW_ENVIRON_VALUE = "\u0001";
export declare const NEW_ENVIRON_ESC = "\u0002";
export declare const NEW_ENVIRON_USERVAR = "\u0003";
export declare const NEW_ENVIRON_DO = "\u00FF\u00FD'";
export declare const NEW_ENVIRON_WILL = "\u00FF\u00FB'";
export declare const NEW_ENVIRON_WONT = "\u00FF\u00FC'";
export declare const MTTS_ANSI = 1;
export declare const MTTS_VT100 = 2;
export declare const MTTS_UTF8 = 4;
export declare const MTTS_256_COLORS = 8;
export declare const MTTS_MOUSE_TRACKING = 16;
export declare const MTTS_OSC_COLOR_PALETTE = 32;
export declare const MTTS_SCREEN_READER = 64;
export declare const MTTS_PROXY = 128;
export declare const MTTS_TRUECOLOR = 256;
export declare const MTTS_MNES = 512;
export declare const MTTS_MSLP = 1024;
export declare const MTTS_SSL = 2048;
/** Live capabilities that toggle the dynamic MTTS bits. The static bits (ANSI,
 *  256 colours, OSC colour palette, truecolour) are always on. */
export interface MttsCapabilities {
    /** UTF-8 is the active encoding (sets the UTF-8 bit). */
    utf8?: boolean;
    /** The game-facing transport is TLS-encrypted (sets the SSL bit). */
    tls?: boolean;
    /** MNES is negotiated (sets the MNES bit). */
    mnes?: boolean;
    /** A screen reader is being advertised (sets the SCREEN READER bit). */
    screenReader?: boolean;
}
/**
 * Compose the MTTS bitvector mudix advertises. Mirrors Mudlet's
 * `getNewEnvironMTTS`: ANSI + 256 COLORS + OSC COLOR PALETTE + TRUECOLOR are
 * always present (mudix's static terminal capabilities); UTF-8, SSL/TLS, MNES
 * and SCREEN READER are added from live state. With UTF-8 + TLS this yields
 * 2349, matching a default Mudlet connection.
 */
export declare function computeMtts(caps?: MttsCapabilities): number;
export declare const NAWS_COMMAND_CODE = 31;
export declare const OPT_NAWS = "\u001F";
export declare const NAWS_WILL = "\u00FF\u00FB\u001F";
export declare const NAWS_DO = "\u00FF\u00FD\u001F";
export declare const NAWS_DONT = "\u00FF\u00FE\u001F";
export declare const CHARSET_COMMAND_CODE = 42;
export declare const OPT_CHARSET = "*";
export declare const CHARSET_REQUEST = "\u0001";
export declare const CHARSET_ACCEPTED = "\u0002";
export declare const CHARSET_REJECTED = "\u0003";
export declare const CHARSET_WILL = "\u00FF\u00FB*";
export declare const CHARSET_DO = "\u00FF\u00FD*";
