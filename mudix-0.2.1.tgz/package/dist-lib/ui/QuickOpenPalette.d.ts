import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
interface QuickOpenPaletteProps {
    vfs: ProfileVFS;
    onPick: (path: string) => void;
    onClose: () => void;
}
export declare function QuickOpenPalette({ vfs, onPick, onClose }: QuickOpenPaletteProps): import("react/jsx-runtime").JSX.Element;
export {};
