import { readFileSync, statSync } from '@zenfs/core';
import type { ProfileVFS } from './ProfileVFS';
export type SideKind = 'local' | 'folder';
export interface FileEntry {
    /** Relative path from the profile root, e.g. "scripts/foo.lua". No leading slash. */
    path: string;
    size: number;
    mtimeMs: number;
}
export interface DiffResult {
    /** Files present only in the local (IDB) side. */
    onlyLocal: FileEntry[];
    /** Files present only in the linked folder. */
    onlyFolder: FileEntry[];
    /** Files at the same path on both sides (need user resolution). */
    conflicts: {
        path: string;
        local: FileEntry;
        folder: FileEntry;
    }[];
}
export declare function walkFolderHandle(root: FileSystemDirectoryHandle): Promise<FileEntry[]>;
/** Walk every file under the mounted profile, returning paths relative to the profile root. */
export declare function walkVfsTree(vfs: ProfileVFS): FileEntry[];
/**
 * A file is considered "conflicting" if it exists at the same relative path on
 * both sides, regardless of whether the bytes match. Comparing mtime/size is
 * unreliable across filesystems (folder-backed mtime comes from disk,
 * IDB-backed mtime comes from the inode index), so we let the user resolve.
 */
export declare function diffSides(local: FileEntry[], folder: FileEntry[]): DiffResult;
/**
 * Copy the listed relative paths from the mounted profile into the linked
 * folder. Used on link to materialize IDB-only files (and "use local"
 * resolutions) before the next mount picks up the folder as the source.
 */
export declare function copyVfsToFolder(vfs: ProfileVFS, handle: FileSystemDirectoryHandle, relPaths: string[]): Promise<{
    copied: number;
    failed: {
        path: string;
        reason: string;
    }[];
}>;
/**
 * Side-mount a fresh IDB backend for the given connection at a temporary
 * profile path, copy every file from the linked folder into it, then unmount.
 * Used on unlink so the user's next mount (now IDB-backed because the handle
 * is cleared) sees the folder's content. Idempotent: any prior data in the
 * IDB store gets overwritten when paths collide.
 */
export declare function copyFolderToIdb(handle: FileSystemDirectoryHandle, connectionId: string): Promise<{
    copied: number;
    failed: {
        path: string;
        reason: string;
    }[];
}>;
export declare function hasAnyFile(entries: FileEntry[]): boolean;
export { readFileSync, statSync };
