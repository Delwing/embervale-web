export type TtsState = 'ttsSpeechReady' | 'ttsSpeechStarted' | 'ttsSpeechPaused' | 'ttsSpeechError' | 'ttsUnknownState';
type EmitFn = (event: string, args: unknown[]) => void;
export declare class TtsManager {
    private readonly emit;
    private readonly synth;
    private pending;
    private current;
    private state;
    private rate;
    private pitch;
    private volume;
    private voiceName;
    private gen;
    private destroyed;
    private readonly onVoicesChanged;
    constructor(emit: EmitFn);
    /** Mudlet ttsSpeak — speak `text` immediately, interrupting anything in
     *  progress. The queue is untouched and resumes once `text` finishes. */
    speak(text: string): void;
    /** Mudlet ttsQueue — append `text` to the queue (or insert at 1-based
     *  `index`). Starts playback if nothing is currently speaking. */
    queue(text: string, index?: number): void;
    /** Mudlet ttsSkip — stop the current utterance and move on to the next
     *  queued one (if any). */
    skip(): void;
    /** Mudlet ttsPause — pause the current utterance. */
    pause(): void;
    /** Mudlet ttsResume — resume a paused utterance. */
    resume(): void;
    /** Mudlet ttsClearQueue — drop the whole pending queue, or just the item at
     *  1-based `index`. Returns false when `index` is out of bounds (the
     *  currently-speaking utterance is never in the queue and is unaffected). */
    clearQueue(index?: number): boolean;
    /** Mudlet ttsGetQueue — the pending texts (1-based index returns one item,
     *  or false if out of bounds; no index returns the whole list). */
    getQueue(): string[];
    getQueue(index: number): string | false;
    /** Mudlet ttsGetState — one of the tts* state strings. */
    getState(): TtsState;
    /** Mudlet ttsGetCurrentLine — the text being spoken, or null when idle
     *  (Ready) / errored. The Lua wrapper maps null to (nil, reason). */
    getCurrentLine(): string | null;
    /** Mudlet ttsGetVoices — the available voice names. */
    getVoices(): string[];
    /** Mudlet ttsGetCurrentVoice — the selected voice name, falling back to the
     *  engine's first available voice when none was set. */
    getCurrentVoice(): string;
    getRate(): number;
    getPitch(): number;
    getVolume(): number;
    /** Mudlet ttsSetRate — clamps to -1..1, stores it, raises ttsRateChanged. */
    setRate(rate: number): void;
    /** Mudlet ttsSetPitch — clamps to -1..1, stores it, raises ttsPitchChanged. */
    setPitch(pitch: number): void;
    /** Mudlet ttsSetVolume — clamps to 0..1, stores it, raises ttsVolumeChanged. */
    setVolume(volume: number): void;
    /** Mudlet ttsSetVoiceByName — selects a voice by name. Returns false when no
     *  voice matches; otherwise stores it and raises ttsVoiceChanged. */
    setVoiceByName(name: string): boolean;
    /** Mudlet ttsSetVoiceByIndex — selects a voice by 1-based index. Returns
     *  false when out of bounds. */
    setVoiceByIndex(index: number): boolean;
    destroy(): void;
    private advance;
    private beginUtterance;
    private setState;
}
export {};
