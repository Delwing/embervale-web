export declare function installPinchZoomGuard(): void;
