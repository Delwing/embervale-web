/**
 * Mudlet OSC 8 hyperlink extension — configuration parsing.
 *
 * Mudlet extends the bare OSC 8 sequence (`ESC ] 8 ; params ; URI ST`) with a
 * rich config carried in the URI's query string:
 *
 *   send:attack?config={"style":{"color":"red","bold":true},"tooltip":"…"}
 *   send:p1?preset=btn&config={"s":{"c":"yellow"}}
 *   preset:btn?config={"s":{"bg":"#07f","c":"white","b":true}}   (definition only)
 *
 * The config is a JSON object whose keys may use a compact shorthand (`s`→`style`,
 * `c`→`color`, …). Presets are named, reusable config templates: a `preset:NAME`
 * link registers one (and renders nothing); later links reference it with
 * `?preset=NAME`, optionally layering an override `config=` on top (deep merge,
 * override wins).
 *
 * This module is the pure, side-effect-free parsing layer (plus a small preset
 * registry). It turns a URI into a normalised {@link HyperlinkConfig}; the
 * render/interaction layers consume that. Mirrors Mudlet's
 * `parseHyperlinkConfig` / `parseJsonHyperlinkConfig` / `expandJsonShorthands`
 * (src/TBuffer.cpp) and the shorthand table registered in src/TConsole.cpp.
 */
import type { FormatColor } from "./FormatState";
export type UnderlineStyle = "solid" | "wavy" | "dotted" | "dashed";
/** Visual styling for a link in one state. Mirrors the SGR-style attributes a
 *  run can carry, expressed as already-resolved colours. */
export interface LinkStateStyle {
    foreground?: FormatColor;
    background?: FormatColor;
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
    underlineStyle?: UnderlineStyle;
    overline?: boolean;
    strikethrough?: boolean;
    /** `text-decoration-color` — the colour of the underline/overline/strike. */
    decorationColor?: FormatColor;
}
/** CSS-like pseudo-class states a link style can target. */
export type LinkState = "hover" | "active" | "focus" | "focus-visible" | "visited" | "link" | "any-link" | "selected" | "disabled";
export declare const LINK_STATES: readonly LinkState[];
/** The base style plus any per-state overrides. */
export interface HyperlinkStyling extends LinkStateStyle {
    states?: Partial<Record<LinkState, LinkStateStyle>>;
}
/** One entry in a right-click menu: either a separator or a labelled action. */
export interface MenuItem {
    separator?: boolean;
    label?: string;
    /** A command URI like `send:strike` / `prompt:cast` / `https://…`. */
    action?: string;
}
/** A menu's header line (shown above the items). */
export interface LinkTitle {
    text?: string;
    style?: LinkStateStyle;
}
export type VisibilityAction = "conceal" | "reveal" | "reveal-then-conceal";
export interface VisibilitySettings {
    action?: VisibilityAction;
    /** Delay before the action fires, in milliseconds. */
    delayMs?: number;
    deletesEntireLine?: boolean;
    expireOnInput?: boolean;
    expireOnPrompt?: boolean;
    expireOnOutput?: boolean;
    outputDelayMs?: number;
}
export interface SelectionSettings {
    group?: string;
    value?: string;
    /** Clicking toggles the selected state (default true). */
    toggle?: boolean;
    selected?: boolean;
    /** Radio-button behaviour within the group (default true); false = checkbox. */
    exclusive?: boolean;
}
/** The fully-parsed OSC 8 link configuration. Every field is optional — a bare
 *  `send:look` link parses to an empty config. */
export interface HyperlinkConfig {
    style?: HyperlinkStyling;
    tooltip?: string;
    menu?: MenuItem[];
    title?: LinkTitle;
    spoiler?: boolean;
    disabled?: boolean;
    visibility?: VisibilitySettings;
    selection?: SelectionSettings;
}
/** Shorthand key → full property name. Mirrors the table registered in
 *  Mudlet's TConsole.cpp. Applied recursively to every key in a config object,
 *  so `{"s":{"c":"red","h":{"u":true}}}` becomes
 *  `{"style":{"color":"red","hover":{"underline":true}}}`. */
export declare const HYPERLINK_SHORTHANDS: Readonly<Record<string, string>>;
type JsonObject = Record<string, unknown>;
/**
 * Recursively expand shorthand keys to their full names. When both a shorthand
 * and its full form are present on the same object (e.g. `s` and `style`), their
 * object values are deep-merged with the shorthand taking precedence — matching
 * Mudlet's `expandJsonShorthands`.
 */
export declare function expandShorthands(value: unknown): unknown;
/** Deep-merge two raw JSON objects; `override` wins on scalar/array collisions,
 *  objects merge recursively. Mirrors Mudlet's `mergeConfigs`. */
export declare function deepMerge(base: JsonObject, override: JsonObject): JsonObject;
/**
 * Normalise an already-shorthand-expanded config object into a
 * {@link HyperlinkConfig}. Unknown keys are ignored; malformed values are
 * skipped rather than throwing (a partially-valid config still applies).
 */
export declare function normaliseHyperlinkConfig(root: JsonObject): HyperlinkConfig;
/** Parse a raw config JSON string (shorthand-allowed) into a normalised config,
 *  or null if the JSON is invalid / not an object. */
export declare function parseConfigJson(json: string): HyperlinkConfig | null;
interface ExtractedQuery {
    /** The URI up to (not including) the first `?`. */
    base: string;
    /** The raw `config={…}` JSON body, if present. */
    configJson?: string;
    /** The `preset=NAME` value, if present. */
    presetName?: string;
    /** Non-reserved query pairs, in original order/encoding (for http links). */
    userPairs: string[];
}
/**
 * Split a URI into its base and the reserved/user query parts. `config={…}` is
 * located by brace-matching (its JSON value may contain `&`), mirroring
 * Mudlet's hand-rolled scan; everything else is `&`-delimited `key=value`.
 */
export declare function extractQuery(uri: string): ExtractedQuery;
/** Session-scoped store of `preset:NAME` definitions. Holds raw config objects
 *  (shorthand un-expanded, as Mudlet does) so a later `?preset=NAME` can deep-
 *  merge an override before expansion. */
export declare class HyperlinkPresetRegistry {
    private presets;
    register(name: string, rawConfig: JsonObject): void;
    get(name: string): JsonObject | undefined;
    clear(): void;
}
export type Osc8UriResult = 
/** A `preset:NAME` definition was registered; renders nothing. */
{
    kind: "preset";
    name: string;
}
/** A normal link. `command` is the cleaned URI (reserved params stripped)
 *  to hand to scheme classification; `config` is the resolved config. */
 | {
    kind: "link";
    command: string;
    config: HyperlinkConfig;
};
/**
 * Parse a full OSC 8 URI (the part after the `8;params;` framing) into either a
 * preset definition or a resolved link. `registry` supplies/receives preset
 * definitions. Returns null for an empty/whitespace URI.
 *
 * - `preset:NAME?config={…}` registers NAME (raw) and returns a `preset` result.
 * - Otherwise the base command is cleaned: send:/prompt: drop all query params;
 *   http/https/ftp keep user params but strip `config`/`preset`. The config is
 *   resolved as `deepMerge(preset, override)` → expand shorthands → normalise.
 */
export declare function parseOsc8Uri(uri: string, registry: HyperlinkPresetRegistry): Osc8UriResult | null;
export {};
