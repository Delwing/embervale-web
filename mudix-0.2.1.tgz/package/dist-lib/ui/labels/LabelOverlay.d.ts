import type { LabelManager } from './LabelManager';
import './LabelOverlay.css';
export declare function domButtonToMudlet(type: string, domButton: number): string;
interface LabelOverlayProps {
    manager: LabelManager;
    parent: string;
}
export declare function LabelOverlay({ manager, parent }: LabelOverlayProps): import("react/jsx-runtime").JSX.Element | null;
export {};
