import type React from 'react';
import type { MudSession } from '../../mud/MudSession';
interface OutputAreaProps {
    session: MudSession;
    stickyLines?: number;
    commandInputRef?: React.RefObject<HTMLInputElement | HTMLTextAreaElement | null>;
}
export declare function OutputArea({ session, stickyLines, commandInputRef }: OutputAreaProps): import("react/jsx-runtime").JSX.Element;
export {};
