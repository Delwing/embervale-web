import type { WindowManager } from '../WindowManager';
import type { LabelManager } from '../../labels/LabelManager';
import type { CommandLineManager } from '../../cmdline/CommandLineManager';
import type { ScrollBoxManager } from '../../scrollbox/ScrollBoxManager';
interface HtmlPanelProps {
    id: string;
    manager: WindowManager;
    labels?: LabelManager;
    cmdLines?: CommandLineManager;
    scrollBoxes?: ScrollBoxManager;
    backgroundColor?: {
        r: number;
        g: number;
        b: number;
        a: number;
    };
    backgroundImage?: {
        url: string;
        mode: number;
    };
    cmdLineEnabled?: boolean;
    cmdLineStyleSheet?: string;
    cmdLineValue?: string;
    cmdLineValueSeq?: number;
}
export declare function HtmlPanel({ id, manager, labels, cmdLines, scrollBoxes, backgroundColor, backgroundImage, cmdLineEnabled, cmdLineStyleSheet, cmdLineValue, cmdLineValueSeq }: HtmlPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
