export interface VfsReader {
    exists(path: string): boolean;
    readdir(path: string): string[];
    stat(path: string): {
        mtime: Date;
    } | null;
    readFile(path: string): string;
}
/** current/*.xml paths (relative to the profile root) ordered newest-first.
 *  Order is by mtime; when mtimes are unavailable (all zero) autosave.xml comes
 *  first, then the latest timestamp filename. Empty when not a Mudlet profile. */
export declare function listCurrentXmlsByRecency(vfs: VfsReader): string[];
/** Path of the newest profile save in current/, or null if not a Mudlet profile. */
export declare function findNewestCurrentXml(vfs: VfsReader): string | null;
/** Whether a mounted VFS looks like a linked Mudlet profile (has current/*.xml). */
export declare function isMudletProfileVfs(vfs: VfsReader): boolean;
/**
 * The newest current/*.xml whose content actually parses as a Mudlet profile,
 * with its text. Skips a corrupt newest save (e.g. a truncated/garbage autosave
 * from the write bug) and falls back to older saves — so a linked profile still
 * opens, and write-back can re-heal the bad file from a good base. Null if none
 * parse.
 */
export declare function readNewestParseableXml(vfs: VfsReader): {
    path: string;
    xml: string;
} | null;
/**
 * Hydrate the store for a Mudlet-linked profile from the newest current/*.xml,
 * layering the .mudix sidecar's mudix-only slices on top. Returns false if the
 * VFS isn't a Mudlet profile (caller falls back to the normal profile.json load).
 * `installedAt` stamps the package manifests (pass an ISO timestamp).
 */
export declare function loadMudletLinkedProfile(vfs: VfsReader, connectionId: string, installedAt: string): boolean;
