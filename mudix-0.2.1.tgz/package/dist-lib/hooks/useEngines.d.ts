import type { MudSession } from '../mud/MudSession';
import { type MudConnection } from '../storage';
import { ScriptingEngine } from '../scripting/ScriptingEngine';
import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
/**
 * Creates and tears down all scripting engines tied to a session lifetime.
 * Only ScriptingEngine is exposed — it owns the alias/trigger/timer/key
 * engines internally and subscribes to the appStore to keep them in sync.
 */
export declare function useEngines(session: MudSession, active: boolean, connection: MudConnection | null, vfs: ProfileVFS | null): {
    engineRef: import("react").RefObject<ScriptingEngine | null>;
};
