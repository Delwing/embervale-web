/**
 * Registry for Mudlet `createTextEdit` widgets — a multi-line text editor pane.
 *
 * This is the data model behind the `*TextEdit*` Lua API (text content, the
 * editor properties scripts set, and geometry/visibility). The on-screen
 * QPlainTextEdit-equivalent rendering is not wired yet; scripts can create
 * editors and round-trip their text/properties, which is what the Mudlet API
 * surface (and the busted TextEdit spec) exercises.
 */
export interface TextEditState {
    parent: string;
    x: number;
    y: number;
    width: number;
    height: number;
    text: string;
    readOnly: boolean;
    placeholder: string;
    styleSheet: string;
    font: string;
    fontSize: number;
    tabMovesFocus: boolean;
    visible: boolean;
}
export declare class TextEditManager {
    private edits;
    has(name: string): boolean;
    /** Create (or replace) a text edit. Returns true (Mudlet always succeeds). */
    create(name: string, opts: {
        parent: string;
        x: number;
        y: number;
        width: number;
        height: number;
    }): boolean;
    destroy(name: string): boolean;
    /** Returns the editor's text, or null when no editor of that name exists. */
    getText(name: string): string | null;
    setText(name: string, text: string): boolean;
    clear(name: string): boolean;
    setReadOnly(name: string, value: boolean): boolean;
    setPlaceholder(name: string, text: string): boolean;
    setStyleSheet(name: string, css: string): boolean;
    setFont(name: string, font: string): boolean;
    setFontSize(name: string, size: number): boolean;
    setTabMovesFocus(name: string, value: boolean): boolean;
    show(name: string): boolean;
    hide(name: string): boolean;
    move(name: string, x: number, y: number): boolean;
    resize(name: string, width: number, height: number): boolean;
}
