import type { WindowManager } from './windows/WindowManager';
interface MapEditorModalProps {
    connectionId: string;
    connectionName: string;
    manager: WindowManager;
    onClose: () => void;
}
export declare function MapEditorModal({ connectionId, connectionName, manager, onClose }: MapEditorModalProps): import("react/jsx-runtime").JSX.Element;
export {};
