import type { AliasNode, ButtonNode, KeyNode, ScriptNode, TimerNode, TriggerNode } from '../storage/schema';
export interface MudletImportResult {
    scripts: ScriptNode[];
    aliases: AliasNode[];
    triggers: TriggerNode[];
    timers: TimerNode[];
    keys: KeyNode[];
    buttons: ButtonNode[];
    warnings: string[];
}
export interface ParseOptions {
    /**
     * When set, every parsed node is tagged with this packageName, and a
     * top-level group of the same name is prepended to each non-empty
     * category as a parent for the imported tree. This mirrors Mudlet's
     * .mpackage import behaviour: items are organisationally grouped and
     * cleanly removable by tag.
     */
    packageName?: string;
}
export declare function parseMudletXml(xml: string, opts?: ParseOptions): MudletImportResult;
