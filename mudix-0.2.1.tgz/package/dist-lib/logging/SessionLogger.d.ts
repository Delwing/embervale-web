import type { MudSession } from '../mud/MudSession';
/**
 * Records one gameplay session to IndexedDB. Subscribes to the session's
 * `message` event — the single choke point every line of output passes
 * through, including the player's own echoed commands (type 'echo') — and
 * snapshots each line's rendered HTML at emit time (before later trigger
 * gagging/recolouring can mutate the live buffer). Lines are buffered and
 * written in batches to keep IndexedDB traffic off the hot path.
 *
 * The session record is created lazily on the first flush that carries
 * entries, so opening a profile you never receive output in leaves no trace.
 */
export declare class SessionLogger {
    private readonly session;
    private readonly connectionId;
    private readonly connectionName;
    private readonly sessionId;
    private readonly startedAt;
    private buffer;
    private seq;
    private totalCount;
    private flushTimer;
    private unsubscribe;
    private sessionCreated;
    /** Serializes flushes so a size-triggered flush can't race the timer. */
    private flushing;
    constructor(session: MudSession, connectionId: string, connectionName: string);
    start(): void;
    private capture;
    /**
     * Mudlet `appendLog(text)` — append an arbitrary line to the current log,
     * outside the normal output stream. Recorded with type 'appendLog'; any
     * embedded ANSI is parsed for the HTML snapshot.
     */
    appendLine(text: string): void;
    /** Persist any buffered lines and bump the session's end time/count. */
    flush(): Promise<void>;
    private doFlush;
    /** Detach the listener and write out whatever is buffered. */
    stop(): Promise<void>;
}
