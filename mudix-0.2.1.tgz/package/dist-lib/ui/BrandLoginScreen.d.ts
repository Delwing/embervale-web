import { type LandingProps } from '../branding';
/**
 * Built-in landing for branded builds: no profile creation or selection —
 * just a login form for the brand's MUD. Used when the brand doesn't supply
 * its own `Landing` component. Credentials are held in memory only (never
 * persisted): they feed the same auto-login path as the connection editor
 * (GMCP Char.Login, or typed at text-login prompts) for this page's lifetime,
 * so a reload starts back at an empty form.
 */
export declare function BrandLoginScreen({ openProfile, ensureBrandProfile, openSettings }: LandingProps): import("react/jsx-runtime").JSX.Element;
