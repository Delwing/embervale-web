export interface MouseEventEntry {
    /** Stable id used by removeMouseEvent and as the map key for getMouseEvents. */
    uniqueName: string;
    /** Event raised (via raiseEvent) when the menu item is clicked. */
    eventName: string;
    /** Label rendered in the context menu. Defaults to uniqueName. */
    displayName: string;
    /** Tooltip shown on hover. Empty string when none was given. */
    tooltip: string;
}
/**
 * Backs Mudlet's addMouseEvent / removeMouseEvent / getMouseEvents
 * (Host::mConsoleActions). Right-clicking the main output area shows entries
 * from this registry; clicking one raises the registered event. addMouseEvent
 * refuses a duplicate uniqueName (matching Mudlet's warn-and-return-nil).
 */
export declare class MouseEventRegistry {
    private entries;
    private subscribers;
    private dispatcher;
    subscribe(cb: () => void): () => void;
    private notify;
    setDispatcher(fn: ((eventName: string, args: unknown[]) => void) | null): void;
    /** Mudlet addMouseEvent — false when uniqueName/eventName is empty or the
     *  uniqueName is already registered. */
    add(uniqueName: string, eventName: string, displayName?: string, tooltip?: string): boolean;
    remove(uniqueName: string): boolean;
    list(): MouseEventEntry[];
    /** Raise the entry's event. Mudlet passes the originating window name. */
    dispatch(uniqueName: string): void;
}
