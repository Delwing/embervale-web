export declare const QT_CURSOR_TO_CSS: Record<number, string>;
/** Reverse map of Mudlet's `mudlet.cursor` table (CursorShapes.lua). Used so
 *  setLabelCursor accepts the string name directly without requiring the
 *  bundled GUIUtils.lua wrapper to be loaded. -1 ('Reset') clears the cursor.
 */
export declare const QT_CURSOR_NAME_TO_INT: Record<string, number>;
