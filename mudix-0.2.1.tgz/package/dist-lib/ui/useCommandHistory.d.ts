/** Reactive MRU command history wrapper around localStorage. History is scoped
 *  to `connectionId` so each profile keeps its own. `saveSize` caps how many
 *  entries are persisted (Mudlet's `commandLineHistorySaveSize`). */
export declare function useCommandHistory(connectionId: string | null, saveSize?: number): {
    history: string[];
    add: (item: string) => void;
};
