/**
 * Some keyboard shortcuts are owned by the browser (or the OS) and are handled
 * *above* the web page — Ctrl+T opens a new tab, Ctrl+W closes it, F12 opens
 * devtools. The page never receives the keydown (or can't suppress it), so a MUD
 * keybinding on one of these can never fire in mudix.
 *
 * Real Mudlet runs natively and binds these freely; opened in a browser they
 * silently do nothing, which is baffling. We scan the loaded keybindings on
 * profile open (and temp keys as scripts register them) and warn about the ones
 * the browser intercepts.
 *
 * We deliberately do NOT warn about page-level shortcuts the browser owns but a
 * page can still capture with preventDefault — Ctrl+R (reload), Ctrl+S (save),
 * Ctrl+P (print), Ctrl+F (find), F5, Ctrl+L, etc. mudix intercepts those, so they
 * work exactly like they do in Mudlet: while the client has keyboard focus.
 *
 * Keys are stored as DOM `KeyboardEvent.code` strings (see {@link KeyNode}), so we
 * match against codes like `KeyT`, `Digit1`, `F12`.
 */
import type { KeyNode } from '../../storage/schema';
export interface ReservedKeyWarning {
    node: KeyNode;
    combo: string;
    action: string;
}
/** Platform accelerator — browser shortcuts use Cmd (meta) on macOS, Ctrl elsewhere. */
export type Accel = 'ctrl' | 'meta';
/** Detect the platform accelerator modifier. Falls back to Ctrl off-browser (tests). */
export declare function detectAccel(): Accel;
/** Render a keybinding as a display combo like "Ctrl+Shift+I". */
export declare function formatKeyCombo(node: Pick<KeyNode, 'key' | 'modifiers'>): string;
/** Explanation appended to each warning line. */
export declare function reservedKeyNote(action: string): string;
/**
 * Classify a single keybinding against the browser-reserved set. Returns the
 * browser action it collides with, or null when the combo is safe to bind.
 */
export declare function classifyReservedKey(node: Pick<KeyNode, 'key' | 'modifiers'>, accel?: Accel): string | null;
/**
 * Scan a list of keybindings and return a warning for each one the browser
 * intercepts. Group nodes and keyless nodes are skipped; the caller is expected
 * to pass the effectively-enabled bindings (disabled binds never fire, so
 * warning about them would be noise).
 */
export declare function findReservedKeybindings(keys: KeyNode[], accel?: Accel): ReservedKeyWarning[];
