import { type MudConnection } from '../storage';
interface Props {
    connections: MudConnection[];
    connecting: boolean;
    connectingId: string | null;
    editingId: string | null;
    onConnect: (c: MudConnection) => void;
    onOpen: (c: MudConnection) => void;
    onEdit: (c: MudConnection) => void;
    onDelete: (c: MudConnection) => void;
    onReorder: (orderedIds: string[]) => void;
    onAddClick: () => void;
}
/** Draggable, animated grid of profile cards. Reordering lifts the dragged tile
 *  into a floating clone, opens a dashed placeholder at the target slot, and
 *  slides the remaining tiles into their new positions with a FLIP animation. */
export declare function ConnectionGrid({ connections, connecting, connectingId, editingId, onConnect, onOpen, onEdit, onDelete, onReorder, onAddClick, }: Props): import("react/jsx-runtime").JSX.Element;
export {};
