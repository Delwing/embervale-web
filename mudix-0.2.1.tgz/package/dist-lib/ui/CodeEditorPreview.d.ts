import type { ProfileVFS } from '../scripting/vfs/ProfileVFS';
export declare const EDITABLE_EXTENSIONS: Set<string>;
interface Props {
    content: string;
    filename: string;
    path: string;
    vfs: ProfileVFS;
    onDirtyChange?: (dirty: boolean) => void;
    onSaved?: () => void;
    /** Jump request. Bump `revision` to re-trigger on the same line. */
    gotoLine?: {
        line: number;
        revision: number;
    } | null;
    /** Extra controls rendered inside the toolbar actions area (left of Revert/Save). */
    toolbarExtra?: React.ReactNode;
}
export declare function CodeEditorPreview({ content, filename, path, vfs, onDirtyChange, onSaved, gotoLine, toolbarExtra }: Props): import("react/jsx-runtime").JSX.Element;
export {};
