/** A single MNES variable the client reports back, e.g. `{ name: "CHARSET",
 *  value: "UTF-8" }`. */
export interface MnesVar {
    name: string;
    value: string;
}
/** Result of parsing an `IAC SB NEW-ENVIRON SEND … IAC SE` request body. */
export interface MnesRequest {
    /** True when the body is a well-formed SEND command (the only request kind
     *  a client answers). */
    isSend: boolean;
    /** Variable names the server explicitly asked for, in request order. Empty
     *  means a bare SEND — the server wants every variable we report. */
    requested: string[];
}
/**
 * Parse an `IAC SB NEW-ENVIRON SEND …` request. `subneg` is the subnegotiation
 * body with the leading option code (39) still attached (matching how the
 * telnet option parser hands bodies to the other protocol streams). The byte
 * after the option code is the command; for a server→client request it's SEND.
 * After SEND comes an optional list of `VAR <name>` / `USERVAR <name>` entries,
 * each name running until the next marker (ESC-escaped bytes pass through).
 * A bare SEND with no entries — or only empty names — means "send everything".
 */
export declare function parseMnesRequest(subneg: string): MnesRequest;
/**
 * Frame an `IAC SB NEW-ENVIRON IS <marker> <name> VALUE <value> … IAC SE` reply
 * for the given variables. The returned string is a Latin-1 byte-string ready
 * for sendBytes (names/values are ASCII; control bytes are escaped per RFC
 * 1572). `marker` selects how each variable name is tagged: `NEW_ENVIRON_VAR`
 * (the default — MNES frames every variable as a standard VAR) or
 * `NEW_ENVIRON_USERVAR` (plain NEW-ENVIRON frames its client-defined variables
 * as USERVAR, matching Mudlet). The two never mix within one reply because the
 * client reports a single coherent set per negotiated mode.
 */
export declare function encodeMnesIs(vars: ReadonlyArray<MnesVar>, marker?: string): string;
/** Live client state the NEW-ENVIRON variable set is derived from. Everything
 *  here is something the server can't know on its own — the negotiated encoding,
 *  the transport's TLS status, the output window's wrap column. */
export interface NewEnvironState {
    /** The active byte→char codec label as reported for the CHARSET variable,
     *  e.g. "UTF-8" or "LATIN-1". */
    charset: string;
    /** Whether the live encoding is UTF-8 (drives the UTF-8 capability flag). */
    utf8: boolean;
    /** Whether the link to the game server is TLS-encrypted. True for a direct
     *  `wss://` connection; false in proxy mode (plaintext upstream telnet). */
    tls: boolean;
    /** Output window wrap column, or 0 when the grid hasn't been measured yet. */
    wrapColumns: number;
}
/** Client version reported as the CLIENT_VERSION variable. Exported because the
 *  GMCP `Core.Hello` handshake reports the same version — one source of truth. */
export declare const CLIENT_VERSION = "0.1.0";
/**
 * Build the variable set the client reports for option 39. The five MNES core
 * variables (CHARSET, CLIENT_NAME, CLIENT_VERSION, MTTS, TERMINAL_TYPE) are
 * always present; when `extended` is true the broader NEW-ENVIRON capability
 * set is appended (mirroring Mudlet's `getNewEnvironDataMap`): terminal
 * capabilities (ANSI, 256_COLORS, TRUECOLOR, UTF-8), transport/security (TLS),
 * and layout/accessibility hints (WORD_WRAP, SCREEN_READER). Capabilities mudix
 * doesn't implement are reported honestly as "0" rather than omitted, so a
 * server gets a definite answer instead of inferring absence. The caller frames
 * the result with VAR (MNES) or USERVAR (NEW-ENVIRON) via encodeMnesIs.
 */
export declare function buildNewEnvironVars(state: NewEnvironState, extended: boolean): MnesVar[];
/**
 * Pick which of the client's `available` MNES variables to report in response
 * to a parsed request. A bare SEND (no specific names) returns everything;
 * otherwise the requested names are returned in request order, filtered to the
 * ones we actually know. If the server asked only for names we don't report,
 * we fall back to sending everything rather than an empty reply — the server
 * still learns who we are.
 */
export declare function selectMnesVars(request: MnesRequest, available: ReadonlyArray<MnesVar>): MnesVar[];
