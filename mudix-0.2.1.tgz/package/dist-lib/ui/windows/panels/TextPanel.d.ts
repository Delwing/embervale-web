import type { WindowManager } from '../WindowManager';
import type { LabelManager } from '../../labels/LabelManager';
import type { CommandLineManager } from '../../cmdline/CommandLineManager';
import type { ScrollBoxManager } from '../../scrollbox/ScrollBoxManager';
interface TextPanelProps {
    id: string;
    /** Human-readable window title (defaults to the id), used as the accessible
     *  name so a screen reader can identify and navigate to this user window. */
    title?: string;
    manager: WindowManager;
    labels?: LabelManager;
    cmdLines?: CommandLineManager;
    scrollBoxes?: ScrollBoxManager;
    fontSize?: number;
    fontFamily?: string;
    wrapAt?: number;
    wrapIndent?: number;
    wrapHangingIndent?: number;
    backgroundColor?: {
        r: number;
        g: number;
        b: number;
        a: number;
    };
    backgroundImage?: {
        url: string;
        mode: number;
    };
    cmdLineEnabled?: boolean;
    cmdLineStyleSheet?: string;
    cmdLineValue?: string;
    cmdLineValueSeq?: number;
}
export declare function TextPanel({ id, title, manager, labels, cmdLines, scrollBoxes, fontSize, fontFamily, wrapAt, wrapIndent, wrapHangingIndent, backgroundColor, backgroundImage, cmdLineEnabled, cmdLineStyleSheet, cmdLineValue, cmdLineValueSeq }: TextPanelProps): import("react/jsx-runtime").JSX.Element;
export {};
